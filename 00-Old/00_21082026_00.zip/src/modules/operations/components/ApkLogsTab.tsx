'use client';

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { 
    Calendar, 
    Search, 
    RefreshCw, 
    Smartphone, 
    User, 
    Truck, 
    MapPin, 
    AlertTriangle, 
    Info, 
    AlertCircle, 
    Clock, 
    Phone
} from 'lucide-react';
import { getApkDriverLogsAction } from '@/modules/operations/lib/actions';
import { formatFechaEntrega } from '@/modules/operations/lib/utils';

interface ApkLogsTabProps {
    tvMode?: boolean;
}

const ITEMS_PER_PAGE = 15;

export function ApkLogsTab({ tvMode = false }: ApkLogsTabProps) {
    const getLocalDateStr = () => {
        const d = new Date();
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    };

    const [apkDate, setApkDate] = useState<string>(getLocalDateStr());
    const [apkLogs, setApkLogs] = useState<any[]>([]);
    const [apkLogsLoading, setApkLogsLoading] = useState(false);
    const [filterLevel, setFilterLevel] = useState<string>('all');
    const [searchTerm, setSearchTerm] = useState<string>('');
    const [apkPage, setApkPage] = useState(1);

    const fetchLogs = useCallback(async (dateToQuery?: string) => {
        setApkLogsLoading(true);
        try {
            const queryDate = dateToQuery || apkDate;
            const logs = await getApkDriverLogsAction(queryDate);
            setApkLogs(logs || []);
            setApkPage(1);
        } catch (error) {
            console.error("Error fetching APK driver logs:", error);
        } finally {
            setApkLogsLoading(false);
        }
    }, [apkDate]);

    useEffect(() => {
        fetchLogs();
    }, [fetchLogs]);

    const filteredLogs = useMemo(() => {
        return apkLogs.filter((log: any) => {
            if (filterLevel !== 'all') {
                const logLvl = (log.level || 'INFO').toUpperCase();
                if (filterLevel === 'ERROR' && logLvl !== 'ERROR' && logLvl !== 'CRITICAL') return false;
                if (filterLevel === 'WARN' && logLvl !== 'WARN' && logLvl !== 'WARNING') return false;
                if (filterLevel === 'INFO' && logLvl !== 'INFO') return false;
            }

            if (searchTerm.trim()) {
                const term = searchTerm.toLowerCase();
                const matchMsg = (log.message || '').toLowerCase().includes(term);
                const matchUser = (log.chofer_nombre || log.user_name || '').toLowerCase().includes(term);
                const matchPlate = (log.placa_vehiculo || '').toLowerCase().includes(term);
                const matchRoute = (log.ruta_nombre || '').toLowerCase().includes(term);
                const matchCategory = (log.category || '').toLowerCase().includes(term);
                if (!matchMsg && !matchUser && !matchPlate && !matchRoute && !matchCategory) return false;
            }

            return true;
        });
    }, [apkLogs, filterLevel, searchTerm]);

    const paginatedLogs = useMemo(() => {
        const startIndex = (apkPage - 1) * ITEMS_PER_PAGE;
        return filteredLogs.slice(startIndex, startIndex + ITEMS_PER_PAGE);
    }, [filteredLogs, apkPage]);

    const totalPages = Math.ceil(filteredLogs.length / ITEMS_PER_PAGE) || 1;

    const getLevelBadge = (level: string) => {
        const lvl = (level || 'INFO').toUpperCase();
        if (lvl === 'ERROR' || lvl === 'CRITICAL') {
            return (
                <Badge variant="outline" className="bg-rose-500/10 text-rose-600 border-rose-500/30 gap-1 font-bold text-[10px]">
                    <AlertCircle className="w-3 h-3" /> ERROR
                </Badge>
            );
        }
        if (lvl === 'WARN' || lvl === 'WARNING') {
            return (
                <Badge variant="outline" className="bg-amber-500/10 text-amber-600 border-amber-500/30 gap-1 font-bold text-[10px]">
                    <AlertTriangle className="w-3 h-3" /> ALERTA
                </Badge>
            );
        }
        return (
            <Badge variant="outline" className="bg-emerald-500/10 text-emerald-600 border-emerald-500/30 gap-1 font-bold text-[10px]">
                <Info className="w-3 h-3" /> INFO
            </Badge>
        );
    };

    return (
        <div className="space-y-6 animate-in fade-in duration-300">
            {/* Header and Controls */}
            <div className={`p-4 border rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 ${
                tvMode ? 'bg-slate-900/60 border-slate-800' : 'bg-card'
            }`}>
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-600 dark:text-purple-400">
                        <Smartphone className="w-5 h-5" />
                    </div>
                    <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                            <h3 className="text-sm font-bold">Bitácora de Eventos APK Nativa</h3>
                            <Badge className="bg-purple-600 text-white font-mono text-[10px]">Clic Driver</Badge>
                        </div>
                        <p className="text-[11px] text-muted-foreground font-medium">
                            Diagnóstico y registro de sincronización, inicios de ruta, impresiones y eventos reportados por los celulares.
                        </p>
                    </div>
                </div>

                <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto justify-start md:justify-end">
                    {/* Level Filter */}
                    <div className="flex items-center gap-1 bg-muted/30 p-1 rounded-xl border border-muted/50 text-xs">
                        <button
                            onClick={() => { setFilterLevel('all'); setApkPage(1); }}
                            className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                                filterLevel === 'all' ? 'bg-background shadow-sm text-foreground' : 'text-muted-foreground hover:text-foreground'
                            }`}
                        >
                            Todos ({apkLogs.length})
                        </button>
                        <button
                            onClick={() => { setFilterLevel('INFO'); setApkPage(1); }}
                            className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                                filterLevel === 'INFO' ? 'bg-emerald-600 text-white shadow-sm' : 'text-muted-foreground hover:text-foreground'
                            }`}
                        >
                            Info
                        </button>
                        <button
                            onClick={() => { setFilterLevel('WARN'); setApkPage(1); }}
                            className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                                filterLevel === 'WARN' ? 'bg-amber-600 text-white shadow-sm' : 'text-muted-foreground hover:text-foreground'
                            }`}
                        >
                            Alertas
                        </button>
                        <button
                            onClick={() => { setFilterLevel('ERROR'); setApkPage(1); }}
                            className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                                filterLevel === 'ERROR' ? 'bg-rose-600 text-white shadow-sm' : 'text-muted-foreground hover:text-foreground'
                            }`}
                        >
                            Errores
                        </button>
                    </div>

                    {/* Date Input */}
                    <Input
                        type="date"
                        value={apkDate}
                        onChange={(e) => setApkDate(e.target.value)}
                        className={`h-9 w-36 rounded-xl font-bold text-xs ${
                            tvMode ? 'bg-slate-950 border-slate-800 text-white' : ''
                        }`}
                    />

                    <Button
                        size="sm"
                        onClick={() => fetchLogs(apkDate)}
                        className="rounded-xl font-bold text-xs bg-purple-600 hover:bg-purple-700 text-white gap-1.5 h-9"
                        disabled={apkLogsLoading}
                    >
                        <RefreshCw className={`w-3.5 h-3.5 ${apkLogsLoading ? 'animate-spin' : ''}`} />
                        Buscar
                    </Button>
                </div>
            </div>

            {/* Search Input Filter */}
            <div className="relative">
                <Search className="w-4 h-4 text-muted-foreground absolute left-3.5 top-1/2 -translate-y-1/2" />
                <Input
                    type="text"
                    placeholder="Filtrar por chofer, placa, ruta o palabra clave en el mensaje..."
                    value={searchTerm}
                    onChange={(e) => { setSearchTerm(e.target.value); setApkPage(1); }}
                    className="pl-9 h-10 rounded-xl bg-card border-muted font-medium text-xs shadow-sm"
                />
            </div>

            {apkLogsLoading ? (
                <div className="flex items-center justify-center p-12 bg-card rounded-2xl border border-muted animate-pulse">
                    <div className="text-center space-y-4">
                        <RefreshCw className="w-8 h-8 animate-spin mx-auto text-purple-500" />
                        <p className="text-muted-foreground font-medium text-xs">Cargando registros de Clic Driver APK...</p>
                    </div>
                </div>
            ) : filteredLogs.length === 0 ? (
                <div className="p-12 text-center bg-card rounded-2xl border border-muted/50 space-y-3">
                    <Smartphone className="w-10 h-10 text-muted-foreground/40 mx-auto" />
                    <h4 className="text-sm font-bold text-foreground">No se encontraron eventos para esta fecha</h4>
                    <p className="text-xs text-muted-foreground max-w-md mx-auto">
                        No hay registros reportados por los celulares de los choferes para el día seleccionado o con los filtros actuales.
                    </p>
                </div>
            ) : (
                <div className="space-y-3">
                    {paginatedLogs.map((log: any) => {
                        return (
                            <div 
                                key={log.id || Math.random()} 
                                className={`p-4 rounded-2xl border transition-all duration-200 hover:shadow-sm ${
                                    tvMode ? 'bg-slate-900/40 border-slate-800/80 hover:border-slate-700' : 'bg-card border-muted/50 hover:border-border'
                                }`}
                            >
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 mb-2 border-b border-muted/30">
                                    <div className="flex items-center gap-2 flex-wrap">
                                        {getLevelBadge(log.level)}
                                        {log.category && (
                                            <Badge variant="secondary" className="font-mono text-[10px] capitalize">
                                                {log.category}
                                            </Badge>
                                        )}
                                        <div className="flex items-center gap-1 text-xs font-bold text-foreground">
                                            <User className="w-3.5 h-3.5 text-muted-foreground" />
                                            <span>{log.chofer_nombre || log.user_name || 'Chofer Desconocido'}</span>
                                        </div>
                                        {log.chofer_telefono && (
                                            <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
                                                <Phone className="w-3 h-3 text-emerald-500" />
                                                <span>{log.chofer_telefono}</span>
                                            </div>
                                        )}
                                    </div>

                                    <div className="flex items-center gap-3 text-xs text-muted-foreground font-medium shrink-0">
                                        {log.placa_vehiculo && (
                                            <div className="flex items-center gap-1 bg-muted/40 px-2 py-0.5 rounded-md font-mono text-[10px] font-bold">
                                                <Truck className="w-3 h-3 text-sky-500" />
                                                {log.placa_vehiculo}
                                            </div>
                                        )}
                                        {log.ruta_nombre && (
                                            <div className="flex items-center gap-1 text-[11px]">
                                                <MapPin className="w-3 h-3 text-amber-500" />
                                                {log.ruta_nombre}
                                            </div>
                                        )}
                                        <div className="flex items-center gap-1 font-mono text-[11px]">
                                            <Clock className="w-3 h-3 text-muted-foreground" />
                                            {formatFechaEntrega(log.timestamp)}
                                        </div>
                                    </div>
                                </div>

                                <div className="text-xs text-foreground font-mono bg-muted/15 p-3 rounded-xl border border-muted/20 break-words leading-relaxed whitespace-pre-wrap">
                                    {log.message}
                                </div>
                            </div>
                        );
                    })}

                    {/* Pagination */}
                    {totalPages > 1 && (
                        <div className="flex items-center justify-between pt-2 px-1 text-xs text-muted-foreground">
                            <span>
                                Mostrando página <strong>{apkPage}</strong> de <strong>{totalPages}</strong> ({filteredLogs.length} eventos)
                            </span>
                            <div className="flex items-center gap-2">
                                <Button
                                    size="sm"
                                    variant="outline"
                                    disabled={apkPage <= 1}
                                    onClick={() => setApkPage(p => Math.max(1, p - 1))}
                                    className="rounded-xl h-8 text-xs font-bold"
                                >
                                    Anterior
                                </Button>
                                <Button
                                    size="sm"
                                    variant="outline"
                                    disabled={apkPage >= totalPages}
                                    onClick={() => setApkPage(p => Math.min(totalPages, p + 1))}
                                    className="rounded-xl h-8 text-xs font-bold"
                                >
                                    Siguiente
                                </Button>
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}
