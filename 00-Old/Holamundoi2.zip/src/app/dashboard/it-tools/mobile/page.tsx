'use client';

import React, { useState, useEffect, useTransition } from 'react';
import { usePageTitle } from '@/modules/core/hooks/usePageTitle';
import { useAuthorization } from '@/modules/core/hooks/useAuthorization';
import { useToast } from '@/modules/core/hooks/use-toast';
import { 
    getMobileFleetData, 
    saveMobileDeviceAssignment, 
    deleteMobileDeviceAction,
    publishAppVersion, 
    toggleOtaPause, 
    resetDeviceOtaFailures,
    getSystemUsersList,
    saveDeviceMdmPolicy
} from '@/modules/it-tools/lib/actions';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { 
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
} from '@/components/ui/dialog';
import { 
    Select, 
    SelectContent, 
    SelectItem, 
    SelectTrigger, 
    SelectValue 
} from '@/components/ui/select';
import { 
    Smartphone, 
    RefreshCw, 
    CheckCircle2, 
    AlertTriangle, 
    PauseCircle, 
    PlayCircle, 
    Battery, 
    UserCheck, 
    Phone, 
    UploadCloud, 
    RotateCcw, 
    ShieldAlert, 
    ArrowLeft,
    MapPin,
    AppWindow,
    Check,
    X,
    Edit2,
    Trash2,
    Zap,
    Cpu,
    HardDrive,
    Volume2
} from 'lucide-react';
import Link from 'next/link';

export default function MobileFleetPage() {
    const { setTitle } = usePageTitle();
    const { isAuthorized, isLoading: authLoading } = useAuthorization(['it-tools:access']);
    const { toast } = useToast();
    const [isPending, startTransition] = useTransition();

    const [loading, setLoading] = useState(true);
    const [versionSettings, setVersionSettings] = useState<any>(null);
    const [devices, setDevices] = useState<any[]>([]);
    const [usersList, setUsersList] = useState<any[]>([]);

    // Publish Version Form State
    const [versionName, setVersionName] = useState('1.1.4');
    const [versionCode, setVersionCode] = useState('13');
    const [apkUrl, setApkUrl] = useState('/downloads/apk/ClicDriver.apk');
    const [releaseNotes, setReleaseNotes] = useState('Actualización con Blindaje MDM, Lista Blanca de Apps y soporte Device Owner.');
    const [forceUpdate, setForceUpdate] = useState(false);

    // Edit Device Modal/Inline State
    const [editingHwid, setEditingHwid] = useState<string | null>(null);
    const [editPhone, setEditPhone] = useState('');
    const [editUserId, setEditUserId] = useState<string>('');
    const [editName, setEditName] = useState('');

    // Apps Modal State
    const [selectedAppsDevice, setSelectedAppsDevice] = useState<any | null>(null);
    const [whitelistedPkgs, setWhitelistedPkgs] = useState<string[]>([]);

    // MDM Hardening Modal State
    const [selectedMdmDevice, setSelectedMdmDevice] = useState<any | null>(null);
    const [mdmKioskEnabled, setMdmKioskEnabled] = useState(false);
    const [mdmForceGps, setMdmForceGps] = useState(true);
    const [mdmDisallowAirplaneMode, setMdmDisallowAirplaneMode] = useState(false);
    const [mdmDisallowMobileDataOff, setMdmDisallowMobileDataOff] = useState(false);
    const [mdmDisallowBatterySaver, setMdmDisallowBatterySaver] = useState(false);
    const [mdmBlockUninstall, setMdmBlockUninstall] = useState(true);
    const [mdmDisallowSettings, setMdmDisallowSettings] = useState(false);
    const [mdmDisallowTethering, setMdmDisallowTethering] = useState(false);
    const [mdmDisallowInstallApps, setMdmDisallowInstallApps] = useState(false);

    const handleOpenMdmModal = (device: any) => {
        setSelectedMdmDevice(device);
        setMdmKioskEnabled(device.mdm_kiosk_enabled === 1 || device.apk_kiosk_enabled === 'true');
        setMdmForceGps(device.mdm_force_gps !== 0);
        setMdmDisallowAirplaneMode(device.mdm_disallow_airplane_mode === 1);
        setMdmDisallowMobileDataOff(device.mdm_disallow_mobile_data_off === 1);
        setMdmDisallowBatterySaver(device.mdm_disallow_battery_saver === 1);
        setMdmBlockUninstall(device.mdm_block_uninstall !== 0);
        setMdmDisallowSettings(device.mdm_disallow_settings === 1);
        setMdmDisallowTethering(device.mdm_disallow_tethering === 1);
        setMdmDisallowInstallApps(device.mdm_disallow_install_apps === 1);
    };

    const handleSaveMdmPolicy = () => {
        if (!selectedMdmDevice) return;
        startTransition(async () => {
            try {
                const res = await saveDeviceMdmPolicy(selectedMdmDevice.hardware_id, {
                    mdm_force_gps: mdmForceGps ? 1 : 0,
                    mdm_disallow_airplane_mode: mdmDisallowAirplaneMode ? 1 : 0,
                    mdm_disallow_mobile_data_off: mdmDisallowMobileDataOff ? 1 : 0,
                    mdm_disallow_battery_saver: mdmDisallowBatterySaver ? 1 : 0,
                    mdm_block_uninstall: mdmBlockUninstall ? 1 : 0,
                    mdm_disallow_settings: mdmDisallowSettings ? 1 : 0,
                    mdm_disallow_tethering: mdmDisallowTethering ? 1 : 0,
                    mdm_disallow_install_apps: mdmDisallowInstallApps ? 1 : 0,
                });
                if (res?.success) {
                    toast({
                        title: "Políticas MDM Guardadas 🛡️",
                        description: `Restricciones actualizadas para ${selectedMdmDevice.device_name || selectedMdmDevice.hardware_id}.`
                    });
                    setSelectedMdmDevice(null);
                    loadData(true);
                }
            } catch (err: any) {
                toast({
                    title: "Error guardando políticas MDM",
                    description: err?.message,
                    variant: "destructive"
                });
            }
        });
    };

    const handleOpenAppsModal = (device: any) => {
        setSelectedAppsDevice(device);
        let currentWhitelist: string[] = [];
        if (device.mdm_whitelisted_packages) {
            try {
                currentWhitelist = JSON.parse(device.mdm_whitelisted_packages);
            } catch (_) {}
        }
        setWhitelistedPkgs(currentWhitelist);
    };

    const handleToggleAppWhitelist = (packageName: string, isAllowed: boolean) => {
        setWhitelistedPkgs(prev => {
            let currentList = prev;
            // Si la lista actual está vacía (todas permitidas por defecto), poblarla con todas las apps del celular
            if (currentList.length === 0 && modalAppsList.length > 0) {
                currentList = modalAppsList.map((a: any) => a.packageName).filter(Boolean);
            }

            if (isAllowed) {
                if (!currentList.includes(packageName)) return [...currentList, packageName];
                return currentList;
            } else {
                return currentList.filter(p => p !== packageName);
            }
        });
    };

    const handleSaveAppWhitelist = () => {
        if (!selectedAppsDevice) return;
        startTransition(async () => {
            try {
                const res = await saveDeviceMdmPolicy(selectedAppsDevice.hardware_id, {
                    mdm_whitelisted_packages: JSON.stringify(whitelistedPkgs)
                });
                if (res?.success) {
                    toast({
                        title: "Lista Blanca de Apps Guardada 📱",
                        description: `Políticas de aplicaciones actualizadas.`
                    });
                    setSelectedAppsDevice(null);
                    loadData(true);
                }
            } catch (err: any) {
                toast({
                    title: "Error guardando lista blanca",
                    description: err?.message,
                    variant: "destructive"
                });
            }
        });
    };

    useEffect(() => {
        setTitle("Gestión de Flota Móvil, MDM y APK OTA");
    }, [setTitle]);

    const loadData = React.useCallback((silentParam?: boolean | React.MouseEvent) => {
        const isSilent = silentParam === true;
        if (!isSilent) setLoading(true);
        
        Promise.all([
            getMobileFleetData(),
            getSystemUsersList()
        ])
        .then(([fleetRes, usersRes]) => {
            if (fleetRes) {
                setVersionSettings(fleetRes.versionSettings);
                setDevices(fleetRes.devices || []);
                if (fleetRes.versionSettings && !isSilent) {
                    setVersionName(fleetRes.versionSettings.version_name || '1.1.4');
                    setVersionCode(String(fleetRes.versionSettings.version_code || '13'));
                    setApkUrl(fleetRes.versionSettings.apk_url || '/downloads/apk/ClicDriver.apk');
                    setReleaseNotes(fleetRes.versionSettings.release_notes || '');
                    setForceUpdate(fleetRes.versionSettings.force_update === 1);
                }
            }
            if (usersRes) {
                setUsersList(usersRes);
            }
        })
        .catch((err) => {
            toast({
                title: "Error cargando datos de flota",
                description: err?.message || "No se pudieron obtener los dispositivos",
                variant: "destructive"
            });
        })
        .finally(() => {
            if (!isSilent) setLoading(false);
        });
    }, [toast]);

    useEffect(() => {
        if (isAuthorized) {
            loadData();
        }
    }, [isAuthorized, loadData]);

    const handlePublishVersion = (e: React.FormEvent) => {
        e.preventDefault();
        startTransition(async () => {
            try {
                const res = await publishAppVersion({
                    versionName,
                    versionCode: parseInt(versionCode, 10),
                    apkUrl,
                    releaseNotes,
                    forceUpdate
                });
                if (res?.success) {
                    toast({
                        title: "Versión Oficial Publicada 🚀",
                        description: `La versión v${versionName} (Build ${versionCode}) ya está lista para distribución OTA.`
                    });
                    loadData(true);
                } else {
                    toast({
                        title: "Error publicando versión",
                        description: res?.error || "Ocurrió un problema",
                        variant: "destructive"
                    });
                }
            } catch (err: any) {
                toast({
                    title: "Error de servidor",
                    description: err?.message,
                    variant: "destructive"
                });
            }
        });
    };

    const handleToggleGlobalPause = () => {
        startTransition(async () => {
            try {
                const res = await toggleOtaPause({ target: 'global' });
                if (res?.success) {
                    toast({
                        title: res.isPaused ? "Distribución OTA Pausada ⏸️" : "Distribución OTA Reanudada 🟢",
                        description: res.isPaused ? "Ningún equipo descargará actualizaciones hasta reanudar." : "Los equipos pendientes continuarán descargando la versión objetivo."
                    });
                    loadData(true);
                }
            } catch (err: any) {
                toast({
                    title: "Error alternando pausa global",
                    description: err?.message,
                    variant: "destructive"
                });
            }
        });
    };

    const handleToggleDevicePause = (hwid: string) => {
        startTransition(async () => {
            try {
                const res = await toggleOtaPause({ target: 'device', hwid });
                if (res?.success) {
                    toast({
                        title: res.isPaused ? "OTA Pausada en Dispositivo ⏸️" : "OTA Reanudada en Dispositivo 🟢",
                        description: `Configuración actualizada para ${hwid}`
                    });
                    loadData(true);
                }
            } catch (err: any) {
                toast({
                    title: "Error alternando pausa en dispositivo",
                    description: err?.message,
                    variant: "destructive"
                });
            }
        });
    };

    const handleResetFailures = (hwid: string) => {
        startTransition(async () => {
            try {
                const res = await resetDeviceOtaFailures(hwid);
                if (res?.success) {
                    toast({
                        title: "Circuit Breaker Reseteado 🔄",
                        description: `Se borró el historial de 3 errores. El celular ${hwid} reintentará actualizar.`
                    });
                    loadData(true);
                }
            } catch (err: any) {
                toast({
                    title: "Error reseteando contador",
                    description: err?.message,
                    variant: "destructive"
                });
            }
        });
    };

    const handleStartEdit = (device: any) => {
        setEditingHwid(device.hardware_id);
        setEditPhone(device.phone_number || '');
        setEditUserId(device.driver_user_id ? String(device.driver_user_id) : 'unassigned');
        setEditName(device.device_name || '');
    };

    const handleSaveDeviceEdit = (hwid: string) => {
        startTransition(async () => {
            try {
                const res = await saveMobileDeviceAssignment({
                    hardwareId: hwid,
                    deviceName: editName,
                    phoneNumber: editPhone,
                    driverUserId: (editUserId && editUserId !== 'unassigned') ? parseInt(editUserId, 10) : undefined
                });
                if (res?.success) {
                    toast({
                        title: "Asignación Guardada ✅",
                        description: "Datos del celular y chofer actualizados."
                    });
                    setEditingHwid(null);
                    loadData(true);
                }
            } catch (err: any) {
                toast({
                    title: "Error guardando asignación",
                    description: err?.message,
                    variant: "destructive"
                });
            }
        });
    };

    const handleDeleteDevice = (hwid: string, name: string) => {
        if (!confirm(`¿Está seguro de eliminar el dispositivo "${name || hwid}" del inventario de flota móvil?`)) {
            return;
        }
        startTransition(async () => {
            try {
                const res = await deleteMobileDeviceAction(hwid);
                if (res?.success) {
                    toast({
                        title: "Dispositivo Eliminado 🗑️",
                        description: "El dispositivo ha sido retirado de la lista."
                    });
                    loadData(true);
                }
            } catch (err: any) {
                toast({
                    title: "Error al eliminar dispositivo",
                    description: err?.message,
                    variant: "destructive"
                });
            }
        });
    };

    if (authLoading || loading) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[400px] gap-3 text-muted-foreground">
                <RefreshCw className="w-8 h-8 animate-spin text-purple-600" />
                <p className="text-sm font-medium">Cargando inventario de flota móvil y estado OTA...</p>
            </div>
        );
    }

    if (!isAuthorized) {
        return (
            <div className="p-8 text-center text-rose-600 font-bold">
                No posee permisos suficientes para acceder a la gestión de flota móvil (it-tools:access).
            </div>
        );
    }

    const targetCode = versionSettings?.version_code || 0;
    const isGlobalPaused = versionSettings?.global_ota_paused === 1;

    // Metrics calculations
    const totalDevices = devices.length;
    const updatedCount = devices.filter(d => (d.current_version_code || 0) >= targetCode && targetCode > 0).length;
    const pendingCount = totalDevices - updatedCount;
    const failedCount = devices.filter(d => (d.install_failed_count || 0) >= 3).length;

    // Installed apps parse helper
    let modalAppsList: any[] = [];
    if (selectedAppsDevice?.installed_apps_json) {
        try {
            modalAppsList = JSON.parse(selectedAppsDevice.installed_apps_json);
        } catch (_) {}
    }

    return (
        <main className="w-full px-4 md:px-8 py-6 space-y-6">
            {/* Top Navigation & Actions */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 p-6 rounded-2xl text-white shadow-xl">
                <div className="space-y-1">
                    <div className="flex items-center gap-2">
                        <Link href="/dashboard/it-tools">
                            <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 rounded-full h-8 w-8">
                                <ArrowLeft className="w-4 h-4" />
                            </Button>
                        </Link>
                        <Badge variant="outline" className="text-purple-300 border-purple-400/40 text-[10px] uppercase font-bold tracking-wider">
                            Herramientas de TI & MDM
                        </Badge>
                    </div>
                    <h1 className="text-2xl md:text-3xl font-black tracking-tight flex items-center gap-3">
                        <Smartphone className="w-8 h-8 text-purple-400" /> Gestión de Flota Móvil, MDM y APK OTA
                    </h1>
                    <p className="text-xs text-purple-200/80 max-w-2xl">
                        Control centralizado de dispositivos Android Clic Driver (Device Owner). Publicación de versiones silenciosas, telemetría de batería, RAM, almacenamiento, ubicación GPS e inventario de aplicaciones.
                    </p>
                </div>

                <div className="flex items-center gap-3 self-start sm:self-center">
                    <Button 
                        onClick={loadData} 
                        variant="outline" 
                        size="sm" 
                        className="bg-white/10 text-white border-white/20 hover:bg-white/20 gap-2 text-xs font-bold"
                    >
                        <RefreshCw className="w-3.5 h-3.5" /> Actualizar Datos
                    </Button>

                    <Button 
                        onClick={handleToggleGlobalPause} 
                        disabled={isPending}
                        variant={isGlobalPaused ? "default" : "destructive"} 
                        size="sm" 
                        className="gap-2 text-xs font-bold shadow-md"
                    >
                        {isGlobalPaused ? <PlayCircle className="w-4 h-4" /> : <PauseCircle className="w-4 h-4" />}
                        {isGlobalPaused ? "Reanudar Distribución Global" : "Pausar Distribución Global"}
                    </Button>
                </div>
            </div>

            {/* KPI Overview Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card className="border-purple-100 dark:border-purple-900/30 bg-purple-50/50 dark:bg-purple-950/20">
                    <CardContent className="p-4 flex items-center justify-between">
                        <div>
                            <p className="text-xs font-bold uppercase text-purple-700 dark:text-purple-300">Total Dispositivos 📱</p>
                            <h3 className="text-2xl font-black text-purple-950 dark:text-purple-100 mt-1">{totalDevices}</h3>
                            <p className="text-[11px] text-muted-foreground mt-0.5">Celulares Android Registrados</p>
                        </div>
                        <div className="p-3 bg-purple-600 text-white rounded-xl">
                            <Smartphone className="w-6 h-6" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="border-emerald-100 dark:border-emerald-900/30 bg-emerald-50/50 dark:bg-emerald-950/20">
                    <CardContent className="p-4 flex items-center justify-between">
                        <div>
                            <p className="text-xs font-bold uppercase text-emerald-700 dark:text-emerald-300">Actualizados 🟢</p>
                            <h3 className="text-2xl font-black text-emerald-950 dark:text-emerald-100 mt-1">{updatedCount}</h3>
                            <p className="text-[11px] text-muted-foreground mt-0.5">En versión v{versionSettings?.version_name || '1.0.3'}</p>
                        </div>
                        <div className="p-3 bg-emerald-600 text-white rounded-xl">
                            <CheckCircle2 className="w-6 h-6" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="border-amber-100 dark:border-amber-900/30 bg-amber-50/50 dark:bg-amber-950/20">
                    <CardContent className="p-4 flex items-center justify-between">
                        <div>
                            <p className="text-xs font-bold uppercase text-amber-700 dark:text-amber-300">Pendientes ⚠️</p>
                            <h3 className="text-2xl font-black text-amber-950 dark:text-amber-100 mt-1">{pendingCount}</h3>
                            <p className="text-[11px] text-muted-foreground mt-0.5">Versión previa instalada</p>
                        </div>
                        <div className="p-3 bg-amber-600 text-white rounded-xl">
                            <AlertTriangle className="w-6 h-6" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="border-rose-100 dark:border-rose-900/30 bg-rose-50/50 dark:bg-rose-950/20">
                    <CardContent className="p-4 flex items-center justify-between">
                        <div>
                            <p className="text-xs font-bold uppercase text-rose-700 dark:text-rose-300">Fallos Circuit Breaker 🔴</p>
                            <h3 className="text-2xl font-black text-rose-950 dark:text-rose-100 mt-1">{failedCount}</h3>
                            <p className="text-[11px] text-muted-foreground mt-0.5">Pausados tras 3 errores</p>
                        </div>
                        <div className="p-3 bg-rose-600 text-white rounded-xl">
                            <ShieldAlert className="w-6 h-6" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Target Version Publisher Card */}
            <Card className="shadow-lg border-purple-100 dark:border-purple-900/30">
                <CardHeader className="bg-gradient-to-r from-purple-50 via-indigo-50 to-purple-50 dark:from-purple-950/30 dark:via-indigo-950/30 dark:to-purple-950/30 border-b border-purple-100 dark:border-purple-900/30">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="p-2.5 bg-purple-600 text-white rounded-lg">
                                <UploadCloud className="w-5 h-5" />
                            </div>
                            <div>
                                <CardTitle className="text-lg font-bold text-purple-950 dark:text-purple-100">
                                    Publicar Nueva Versión Oficial de la APK (Over-The-Air)
                                </CardTitle>
                                <CardDescription className="text-xs">
                                    Declare la nueva versión oficial. Al guardar, los celulares con Device Owner descargarán silenciosamente el APK de la ruta asignada.
                                </CardDescription>
                            </div>
                        </div>

                        {versionSettings && (
                            <Badge variant={isGlobalPaused ? "destructive" : "secondary"} className="font-mono text-xs px-3 py-1">
                                {isGlobalPaused ? 'PAUSADO GLOBALMENTE ⏸️' : `OFICIAL: v${versionSettings.version_name} (Build ${versionSettings.version_code}) 🟢`}
                            </Badge>
                        )}
                    </div>
                </CardHeader>

                <CardContent className="p-6">
                    <form onSubmit={handlePublishVersion} className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                            <div className="space-y-1">
                                <Label htmlFor="versionName" className="text-xs font-bold uppercase text-muted-foreground">Versión Name *</Label>
                                <Input 
                                    id="versionName" 
                                    placeholder="Ej: 1.0.3" 
                                    value={versionName} 
                                    onChange={(e) => setVersionName(e.target.value)} 
                                    className="h-9 text-xs font-mono font-bold"
                                    required
                                />
                            </div>

                            <div className="space-y-1">
                                <Label htmlFor="versionCode" className="text-xs font-bold uppercase text-muted-foreground">Version Code *</Label>
                                <Input 
                                    id="versionCode" 
                                    type="number"
                                    min="1"
                                    placeholder="Ej: 2" 
                                    value={versionCode} 
                                    onChange={(e) => setVersionCode(e.target.value)} 
                                    className="h-9 text-xs font-mono font-bold"
                                    required
                                />
                            </div>

                            <div className="md:col-span-2 space-y-1">
                                <Label htmlFor="apkUrl" className="text-xs font-bold uppercase text-muted-foreground">Ruta / URL del APK *</Label>
                                <Input 
                                    id="apkUrl" 
                                    placeholder="/downloads/apk/ClicDriver_v1.0.3.apk" 
                                    value={apkUrl} 
                                    onChange={(e) => setApkUrl(e.target.value)} 
                                    className="h-9 text-xs font-mono"
                                    required
                                />
                            </div>
                        </div>

                        <div className="space-y-1">
                            <Label htmlFor="releaseNotes" className="text-xs font-bold uppercase text-muted-foreground">Notas del Release / Cambios</Label>
                            <Textarea 
                                id="releaseNotes" 
                                placeholder="Describa los cambios de esta versión..." 
                                value={releaseNotes} 
                                onChange={(e) => setReleaseNotes(e.target.value)} 
                                className="min-h-[60px] text-xs"
                            />
                        </div>

                        <div className="flex items-center justify-between pt-2">
                            <div className="flex items-center space-x-2">
                                <Checkbox 
                                    id="forceUpdate" 
                                    checked={forceUpdate} 
                                    onCheckedChange={(c) => setForceUpdate(!!c)} 
                                />
                                <Label htmlFor="forceUpdate" className="text-xs font-medium cursor-pointer">
                                    Forzar actualización prioritaria al abrir
                                </Label>
                            </div>

                            <Button type="submit" disabled={isPending} className="bg-purple-600 hover:bg-purple-700 text-white font-bold gap-2 text-xs h-9">
                                {isPending ? <RefreshCw className="w-4 h-4 animate-spin" /> : <UploadCloud className="w-4 h-4" />}
                                Publicar Versión OTA
                            </Button>
                        </div>
                    </form>
                </CardContent>
            </Card>

            {/* Mobile Fleet Inventory Table */}
            <Card className="shadow-lg border-purple-100 dark:border-purple-900/30">
                <CardHeader className="bg-purple-50/50 dark:bg-purple-950/20 border-b border-purple-100 dark:border-purple-900/30">
                    <CardTitle className="text-lg font-bold text-purple-950 dark:text-purple-100 flex items-center gap-2">
                        <Smartphone className="w-5 h-5 text-purple-600" /> Inventario de Celulares & Telemetría MDM ({devices.length})
                    </CardTitle>
                    <CardDescription className="text-xs">
                        Administre la asignación de choferes, líneas telefónicas, localización GPS en Google Maps, auditoría de apps y estado OTA.
                    </CardDescription>
                </CardHeader>

                <CardContent className="p-0">
                    {devices.length === 0 ? (
                        <div className="p-8 text-center text-muted-foreground text-sm">
                            No hay celulares registrados aún. Al abrir la APK Clic Driver en los dispositivos, se aprovisionarán automáticamente aquí.
                        </div>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="w-full min-w-[1350px] text-xs text-left">
                                <thead className="bg-purple-100/60 dark:bg-purple-950/40 text-purple-950 dark:text-purple-200 uppercase text-[10px]">
                                    <tr>
                                        <th className="p-3 whitespace-nowrap">Dispositivo / HWID</th>
                                        <th className="p-3 whitespace-nowrap">Chofer Asignado</th>
                                        <th className="p-3 whitespace-nowrap">Línea SIM / Teléfono</th>
                                        <th className="p-3 whitespace-nowrap">Impresora MAC</th>
                                        <th className="p-3 whitespace-nowrap">Versión Instalada</th>
                                        <th className="p-3 whitespace-nowrap">Estado OTA & Reintentos</th>
                                        <th className="p-3 whitespace-nowrap">Localización & Apagado</th>
                                        <th className="p-3 whitespace-nowrap">Batería & Sistema</th>
                                        <th className="p-3 whitespace-nowrap">Última Conexión</th>
                                        <th className="p-3 text-right whitespace-nowrap">Acciones TI</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100 dark:divide-zinc-800">
                                    {devices.map((dev) => {
                                        const isEditing = editingHwid === dev.hardware_id;
                                        const devCode = dev.current_version_code || 0;
                                        const isUpToDate = devCode >= targetCode && targetCode > 0;
                                        const isFailed = dev.install_failed_count >= 3;
                                        const isDevicePaused = dev.ota_paused === 1;

                                        // Calculate online status (< 15 mins)
                                        const lastSeenDate = new Date(dev.last_seen);
                                        const diffMins = Math.floor((new Date().getTime() - lastSeenDate.getTime()) / (1000 * 60));
                                        const isOnline = diffMins < 15;

                                        const hasCurrentGps = dev.current_lat && dev.current_lng;
                                        const hasShutdownGps = dev.shutdown_lat && dev.shutdown_lng;

                                        let installedCount = 0;
                                        if (dev.installed_apps_json) {
                                            try {
                                                installedCount = JSON.parse(dev.installed_apps_json).length;
                                            } catch (_) {}
                                        }

                                        return (
                                            <tr key={dev.hardware_id} className="hover:bg-muted/10 transition-colors">
                                                <td className="p-3">
                                                    {isEditing ? (
                                                        <Input 
                                                            value={editName} 
                                                            onChange={(e) => setEditName(e.target.value)} 
                                                            className="h-8 text-xs font-bold"
                                                        />
                                                    ) : (
                                                        <div className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 flex-wrap">
                                                            <span>{dev.device_name || 'Celular Android'}</span>
                                                            {dev.is_device_owner === 1 && (
                                                                <Badge className="bg-purple-600 text-white text-[10px] px-2 py-0.5 font-semibold whitespace-nowrap shrink-0">
                                                                    Device Owner
                                                                </Badge>
                                                            )}
                                                        </div>
                                                    )}
                                                    <div className="font-mono text-[10px] text-muted-foreground mt-0.5">
                                                        {dev.hardware_id}
                                                    </div>
                                                    {(dev.serial_number || dev.imei) && (
                                                        <div className="flex items-center gap-1.5 flex-wrap text-[9px] mt-0.5 font-mono">
                                                            {dev.serial_number && (
                                                                <span className="bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 px-1 py-0.5 rounded font-semibold">
                                                                    S/N: {dev.serial_number}
                                                                </span>
                                                            )}
                                                            {dev.imei && (
                                                                <span className="bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 px-1 py-0.5 rounded font-semibold">
                                                                    IMEI: {dev.imei}
                                                                </span>
                                                            )}
                                                        </div>
                                                    )}
                                                    {dev.device_model && (
                                                        <div className="text-[9px] text-purple-700 dark:text-purple-300 font-semibold mt-0.5">
                                                            {dev.device_model} • {dev.os_version || 'Android'}
                                                        </div>
                                                    )}
                                                </td>

                                                <td className="p-3">
                                                    {isEditing ? (
                                                        <Select value={editUserId} onValueChange={setEditUserId}>
                                                            <SelectTrigger className="h-8 text-xs bg-white dark:bg-zinc-950">
                                                                <SelectValue placeholder="Seleccionar chofer..." />
                                                            </SelectTrigger>
                                                            <SelectContent>
                                                                <SelectItem value="unassigned">Sin asignación</SelectItem>
                                                                {usersList.map(u => (
                                                                    <SelectItem key={u.id} value={String(u.id)}>{u.name}</SelectItem>
                                                                ))}
                                                            </SelectContent>
                                                        </Select>
                                                    ) : (
                                                        <div className="font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                                                            <UserCheck className="w-3.5 h-3.5 text-purple-600" />
                                                            {dev.driver_user_name || dev.last_driver_name || 'Sin asignar'}
                                                        </div>
                                                    )}
                                                </td>

                                                <td className="p-3">
                                                    {isEditing ? (
                                                        <Input 
                                                            placeholder="Ej: 88887777"
                                                            value={editPhone} 
                                                            onChange={(e) => setEditPhone(e.target.value)} 
                                                            className="h-8 text-xs font-mono"
                                                        />
                                                    ) : (
                                                        <div className="font-mono font-medium text-slate-700 dark:text-slate-300 flex items-center gap-1">
                                                            <Phone className="w-3 h-3 text-emerald-600" />
                                                            {dev.phone_number || dev.driver_phone || 'N/D'}
                                                        </div>
                                                    )}
                                                </td>

                                                <td className="p-3 whitespace-nowrap">
                                                    <div className="font-mono text-[10px] text-slate-600 dark:text-slate-300">
                                                        {dev.printer_mac || 'Sin impresora'}
                                                    </div>
                                                </td>

                                                <td className="p-3 whitespace-nowrap">
                                                    <div className="font-mono font-bold text-slate-800 dark:text-slate-200">
                                                        v{dev.current_app_version || '1.0.0'}
                                                    </div>
                                                    <div className="text-[10px] text-muted-foreground">
                                                        Build {dev.current_version_code || 1}
                                                    </div>
                                                </td>

                                                <td className="p-3 whitespace-nowrap">
                                                    {isFailed ? (
                                                        <Badge variant="destructive" className="gap-1 font-bold text-[10px]">
                                                            <ShieldAlert className="w-3 h-3" /> FALLÓ (3/3)
                                                        </Badge>
                                                    ) : isDevicePaused ? (
                                                        <Badge variant="outline" className="gap-1 font-bold text-[10px] border-amber-300 bg-amber-50 text-amber-800">
                                                            <PauseCircle className="w-3 h-3" /> PAUSADO
                                                        </Badge>
                                                    ) : isUpToDate ? (
                                                        <Badge variant="secondary" className="gap-1 font-bold text-[10px] bg-emerald-100 text-emerald-800 border-0">
                                                            <CheckCircle2 className="w-3 h-3" /> ACTUALIZADO
                                                        </Badge>
                                                    ) : (
                                                        <Badge variant="outline" className="gap-1 font-bold text-[10px] border-indigo-300 bg-indigo-50 text-indigo-800">
                                                            <AlertTriangle className="w-3 h-3" /> PENDIENTE v{versionSettings?.version_name}
                                                        </Badge>
                                                    )}

                                                    {dev.last_install_error && (
                                                        <p className="text-[9px] text-rose-600 truncate max-w-[150px] mt-0.5" title={dev.last_install_error}>
                                                            Error: {dev.last_install_error}
                                                        </p>
                                                    )}
                                                </td>

                                                {/* Localizacion GPS & Alert Apagado */}
                                                <td className="p-3 whitespace-nowrap">
                                                    {hasCurrentGps ? (
                                                        <Button 
                                                            variant="outline" 
                                                            size="sm"
                                                            onClick={() => window.open(`https://www.google.com/maps/search/?api=1&query=${dev.current_lat},${dev.current_lng}`, '_blank')}
                                                            className="h-7 text-[10px] font-bold text-blue-700 bg-blue-50 border-blue-200 hover:bg-blue-100 gap-1"
                                                        >
                                                            <MapPin className="w-3 h-3" /> Ubicación GPS (Google Maps)
                                                        </Button>
                                                    ) : hasShutdownGps ? (
                                                        <Button 
                                                            variant="outline" 
                                                            size="sm"
                                                            onClick={() => window.open(`https://www.google.com/maps/search/?api=1&query=${dev.shutdown_lat},${dev.shutdown_lng}`, '_blank')}
                                                            className="h-7 text-[10px] font-bold text-rose-700 bg-rose-50 border-rose-200 hover:bg-rose-100 gap-1"
                                                        >
                                                            <MapPin className="w-3 h-3" /> Apagado en GPS
                                                        </Button>
                                                    ) : (
                                                        <span className="text-[10px] text-muted-foreground italic">Sin coordenadas</span>
                                                    )}

                                                    {dev.shutdown_at && (
                                                        <div className="text-[9px] text-rose-600 font-semibold mt-0.5">
                                                            🚨 Apagado: {new Date(dev.shutdown_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                                        </div>
                                                    )}
                                                </td>

                                                <td className="p-3 whitespace-nowrap">
                                                    <div className="flex items-center gap-1.5 text-slate-800 dark:text-slate-200 font-bold">
                                                        <Battery className={`w-3.5 h-3.5 ${(dev.battery_level ?? 100) < 20 ? 'text-rose-600' : 'text-emerald-600'}`} />
                                                        <span>{dev.battery_level ?? 100}%</span>
                                                        {dev.is_charging === 1 && (
                                                            <span className="text-[11px] text-amber-500 font-black animate-pulse ml-0.5" title="Dispositivo Conectado al Cargador">⚡</span>
                                                        )}
                                                        {dev.battery_temp_c != null && (
                                                            <span className={`text-[10px] font-mono px-1 py-0.2 rounded font-semibold ml-1 ${dev.battery_temp_c > 42 ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/50' : 'bg-slate-100 text-slate-600 dark:bg-zinc-800 dark:text-zinc-300'}`} title="Temperatura de Batería">
                                                                🌡️ {dev.battery_temp_c}°C
                                                            </span>
                                                        )}
                                                    </div>
                                                    <div className="text-[10px] text-muted-foreground flex items-center gap-1 mt-0.5">
                                                        <span className={`w-1.5 h-1.5 rounded-full ${isOnline ? 'bg-emerald-500 animate-ping' : 'bg-slate-300'}`} />
                                                        <span>{isOnline ? 'En línea' : `Hace ${diffMins} min`}</span>
                                                        {dev.network_type && (
                                                            <span className="text-[9px] font-mono font-semibold text-purple-700 dark:text-purple-300 ml-1">
                                                                • {dev.network_type}
                                                            </span>
                                                        )}
                                                    </div>
                                                    {(dev.ram_free_mb != null || dev.storage_free_mb != null) && (
                                                        <div className="text-[9px] text-slate-400 font-mono mt-0.5 flex items-center gap-1">
                                                            {dev.ram_free_mb != null && <span>RAM: {dev.ram_free_mb}MB libre</span>}
                                                        </div>
                                                    )}
                                                </td>

                                                <td className="p-3 whitespace-nowrap">
                                                    <div className="text-[10px] text-muted-foreground">
                                                        {dev.last_seen ? new Date(dev.last_seen).toLocaleString() : 'N/D'}
                                                    </div>
                                                </td>

                                                <td className="p-3 text-right whitespace-nowrap">
                                                    <div className="flex items-center justify-end gap-1">
                                                        <Button 
                                                            size="sm" 
                                                            variant="outline" 
                                                            onClick={() => handleOpenMdmModal(dev)}
                                                            className="h-7 text-[10px] font-bold text-amber-700 bg-amber-50 border-amber-200 hover:bg-amber-100 gap-1"
                                                        >
                                                            <ShieldAlert className="w-3 h-3" /> Blindaje
                                                        </Button>

                                                        {installedCount > 0 && (
                                                            <Button 
                                                                size="sm"
                                                                variant="outline"
                                                                onClick={() => handleOpenAppsModal(dev)}
                                                                className="h-7 text-[10px] font-bold text-purple-700 bg-purple-50 border-purple-200 hover:bg-purple-100 gap-1"
                                                            >
                                                                <AppWindow className="w-3 h-3" /> Apps ({installedCount})
                                                            </Button>
                                                        )}

                                                        {isEditing ? (
                                                            <>
                                                                <Button 
                                                                    size="icon" 
                                                                    variant="ghost" 
                                                                    type="button" 
                                                                    onClick={() => handleSaveDeviceEdit(dev.hardware_id)}
                                                                    className="h-7 w-7 text-emerald-600 hover:bg-emerald-50"
                                                                    title="Guardar"
                                                                >
                                                                    <Check className="w-3.5 h-3.5" />
                                                                </Button>
                                                                <Button 
                                                                    size="icon" 
                                                                    variant="ghost" 
                                                                    type="button" 
                                                                    onClick={() => setEditingHwid(null)}
                                                                    className="h-7 w-7 text-slate-400 hover:bg-slate-100"
                                                                    title="Cancelar"
                                                                >
                                                                    <X className="w-3.5 h-3.5" />
                                                                </Button>
                                                            </>
                                                        ) : (
                                                            <>
                                                                <Button 
                                                                    size="icon" 
                                                                    variant="ghost" 
                                                                    type="button" 
                                                                    onClick={() => handleStartEdit(dev)}
                                                                    className="h-7 w-7 text-purple-700 hover:bg-purple-50"
                                                                    title="Editar Dispositivo"
                                                                >
                                                                    <Edit2 className="w-3.5 h-3.5" />
                                                                </Button>

                                                                <Button 
                                                                    size="icon" 
                                                                    variant="ghost" 
                                                                    type="button" 
                                                                    onClick={() => handleToggleDevicePause(dev.hardware_id)}
                                                                    className="h-7 w-7 text-amber-700 hover:bg-amber-50"
                                                                    title={isDevicePaused ? "Reanudar OTA" : "Pausar OTA"}
                                                                >
                                                                    {isDevicePaused ? <PlayCircle className="w-3.5 h-3.5" /> : <PauseCircle className="w-3.5 h-3.5" />}
                                                                </Button>

                                                                <Button 
                                                                    size="icon" 
                                                                    variant="ghost" 
                                                                    type="button" 
                                                                    onClick={() => handleDeleteDevice(dev.hardware_id, dev.device_name)}
                                                                    className="h-7 w-7 text-rose-600 hover:bg-rose-50"
                                                                    title="Eliminar Dispositivo de la Lista"
                                                                >
                                                                    <Trash2 className="w-3.5 h-3.5" />
                                                                </Button>

                                                                {isFailed && (
                                                                    <Button 
                                                                        size="icon" 
                                                                        variant="ghost" 
                                                                        type="button" 
                                                                        onClick={() => handleResetFailures(dev.hardware_id)}
                                                                        className="h-7 w-7 text-rose-600 hover:bg-rose-50"
                                                                        title="Resetear Contador de Fallos"
                                                                    >
                                                                        <RotateCcw className="w-3.5 h-3.5" />
                                                                    </Button>
                                                                )}
                                                            </>
                                                        )}
                                                    </div>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* MDM Security Hardening Modal */}
            <Dialog open={!!selectedMdmDevice} onOpenChange={() => setSelectedMdmDevice(null)}>
                <DialogContent className="max-w-xl max-h-[85vh] flex flex-col">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2 text-base font-bold text-amber-800 dark:text-amber-400">
                            <ShieldAlert className="w-5 h-5 text-amber-600" /> Blindaje & Políticas MDM (Device Owner)
                        </DialogTitle>
                        <DialogDescription className="text-xs">
                            Dispositivo: <span className="font-bold text-slate-800 dark:text-slate-200">{selectedMdmDevice?.device_name}</span> ({selectedMdmDevice?.hardware_id})
                        </DialogDescription>
                    </DialogHeader>

                    <div className="flex-1 overflow-y-auto space-y-3 pr-1 my-2">
                        <div className="p-3 bg-amber-50 dark:bg-amber-950/20 rounded-xl border border-amber-200 dark:border-amber-800/40 text-xs text-amber-900 dark:text-amber-200 space-y-1">
                            <span className="font-bold block">👑 Estado de Propietario de Dispositivo (MDM):</span>
                            Las restricciones seleccionadas se aplican silenciosamente en el sistema operativo Android del teléfono en su próxima sincronización.
                        </div>

                        <div className="space-y-2">
                            {/* Modo Kiosco Nativo */}
                            <div className="flex items-center justify-between p-3 rounded-lg border-2 border-purple-300 dark:border-purple-800 bg-purple-50/50 dark:bg-purple-950/20">
                                <div className="space-y-0.5">
                                    <Label className="text-xs font-bold flex items-center gap-1.5 text-purple-900 dark:text-purple-200">
                                        🔒 Modo Kiosco Nativo (Lock Task Mode)
                                    </Label>
                                    <span className="text-[11px] text-muted-foreground block">
                                        Fija la pantalla del teléfono exclusivamente en Clic Driver. (Opción alternativa al Modo Seguro MDM estándar).
                                    </span>
                                </div>
                                <Switch checked={mdmKioskEnabled} onCheckedChange={setMdmKioskEnabled} />
                            </div>

                            {/* GPS Obligatorio */}
                            <div className="flex items-center justify-between p-3 rounded-lg border bg-card">
                                <div className="space-y-0.5">
                                    <Label className="text-xs font-bold flex items-center gap-1.5">
                                        📍 GPS Satelital Obligatorio
                                    </Label>
                                    <span className="text-[11px] text-muted-foreground block">
                                        Fuerza la antena GPS siempre encendida e impide que el chofer la desactive.
                                    </span>
                                </div>
                                <Switch checked={mdmForceGps} onCheckedChange={setMdmForceGps} />
                            </div>

                            {/* Prohibir Modo Avión */}
                            <div className="flex items-center justify-between p-3 rounded-lg border bg-card">
                                <div className="space-y-0.5">
                                    <Label className="text-xs font-bold flex items-center gap-1.5">
                                        ✈️ Bloqueo de Modo Avión
                                    </Label>
                                    <span className="text-[11px] text-muted-foreground block">
                                        Deshabilita el botón de Modo Avión para asegurar señal y conectividad continua.
                                    </span>
                                </div>
                                <Switch checked={mdmDisallowAirplaneMode} onCheckedChange={setMdmDisallowAirplaneMode} />
                            </div>

                            {/* Prohibir Apagar Datos Móviles */}
                            <div className="flex items-center justify-between p-3 rounded-lg border bg-card">
                                <div className="space-y-0.5">
                                    <Label className="text-xs font-bold flex items-center gap-1.5">
                                        📶 Bloqueo de Apagar Datos Móviles
                                    </Label>
                                    <span className="text-[11px] text-muted-foreground block">
                                        Impide desconectar la red celular o los datos móviles de la empresa.
                                    </span>
                                </div>
                                <Switch checked={mdmDisallowMobileDataOff} onCheckedChange={setMdmDisallowMobileDataOff} />
                            </div>

                            {/* Prohibir Modo Ahorro Batería */}
                            <div className="flex items-center justify-between p-3 rounded-lg border bg-card">
                                <div className="space-y-0.5">
                                    <Label className="text-xs font-bold flex items-center gap-1.5">
                                        🔋 Bloqueo de Modo Ahorro de Batería
                                    </Label>
                                    <span className="text-[11px] text-muted-foreground block">
                                        Evita que Android ponga las antenas en suspensión profunda (Doze Mode).
                                    </span>
                                </div>
                                <Switch checked={mdmDisallowBatterySaver} onCheckedChange={setMdmDisallowBatterySaver} />
                            </div>

                            {/* Bloquear Desinstalación ClicDriver */}
                            <div className="flex items-center justify-between p-3 rounded-lg border bg-card">
                                <div className="space-y-0.5">
                                    <Label className="text-xs font-bold flex items-center gap-1.5">
                                        🛡️ Anti-Desinstalación de ClicDriver
                                    </Label>
                                    <span className="text-[11px] text-muted-foreground block">
                                        Hace imposible desinstalar la app administradora desde Android.
                                    </span>
                                </div>
                                <Switch checked={mdmBlockUninstall} onCheckedChange={setMdmBlockUninstall} />
                            </div>

                            {/* Bloquear Ajustes de Android */}
                            <div className="flex items-center justify-between p-3 rounded-lg border bg-card">
                                <div className="space-y-0.5">
                                    <Label className="text-xs font-bold flex items-center gap-1.5">
                                        🔒 Bloqueo de Ajustes del Sistema
                                    </Label>
                                    <span className="text-[11px] text-muted-foreground block">
                                        Impide que el usuario acceda a la app de Configuración de Android.
                                    </span>
                                </div>
                                <Switch checked={mdmDisallowSettings} onCheckedChange={setMdmDisallowSettings} />
                            </div>

                            {/* Bloquear Tethering / Hotspot */}
                            <div className="flex items-center justify-between p-3 rounded-lg border bg-card">
                                <div className="space-y-0.5">
                                    <Label className="text-xs font-bold flex items-center gap-1.5">
                                        🚫 Bloqueo de Compartir Internet (Zona Wi-Fi)
                                    </Label>
                                    <span className="text-[11px] text-muted-foreground block">
                                        Impide crear puntos de acceso Wi-Fi para compartir datos con otros equipos.
                                    </span>
                                </div>
                                <Switch checked={mdmDisallowTethering} onCheckedChange={setMdmDisallowTethering} />
                            </div>

                            {/* Bloquear Play Store / Instalaciones */}
                            <div className="flex items-center justify-between p-3 rounded-lg border bg-card">
                                <div className="space-y-0.5">
                                    <Label className="text-xs font-bold flex items-center gap-1.5">
                                        🛒 Bloqueo de Google Play Store / Instalaciones
                                    </Label>
                                    <span className="text-[11px] text-muted-foreground block">
                                        Impide instalar aplicaciones externas o acceder a la tienda de Google.
                                    </span>
                                </div>
                                <Switch checked={mdmDisallowInstallApps} onCheckedChange={setMdmDisallowInstallApps} />
                            </div>
                        </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-2 border-t">
                        <Button variant="outline" size="sm" onClick={() => setSelectedMdmDevice(null)}>
                            Cancelar
                        </Button>
                        <Button 
                            size="sm" 
                            onClick={handleSaveMdmPolicy}
                            disabled={isPending}
                            className="bg-amber-600 hover:bg-amber-700 text-white font-bold"
                        >
                            Guardar Políticas MDM
                        </Button>
                    </div>
                </DialogContent>
            </Dialog>

            {/* Installed Apps & Whitelist Manager Modal */}
            <Dialog open={!!selectedAppsDevice} onOpenChange={() => setSelectedAppsDevice(null)}>
                <DialogContent className="max-w-lg max-h-[85vh] flex flex-col">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2 text-base font-bold text-purple-800 dark:text-purple-400">
                            <AppWindow className="w-5 h-5 text-purple-600" /> Lista Blanca de Apps ({modalAppsList.length})
                        </DialogTitle>
                        <DialogDescription className="text-xs">
                            Dispositivo: <span className="font-bold text-slate-800 dark:text-slate-200">{selectedAppsDevice?.device_name}</span> ({selectedAppsDevice?.hardware_id}). Las aplicaciones desmarcadas quedarán suspendidas / congeladas en el teléfono.
                        </DialogDescription>
                    </DialogHeader>

                    <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 my-2">
                        {modalAppsList.map((app: any, idx: number) => {
                            const isSystemApp = app.isSystem === true;
                            // If whitelistedPkgs is empty, all default allowed. If populated, check inclusion
                            const isAllowed = whitelistedPkgs.length === 0 || whitelistedPkgs.includes(app.packageName);

                            return (
                                <div key={idx} className={`p-2.5 rounded-lg border flex items-center justify-between gap-3 ${isAllowed ? 'bg-emerald-50/40 border-emerald-200 dark:bg-emerald-950/10' : 'bg-rose-50/40 border-rose-200 dark:bg-rose-950/10'}`}>
                                    <div className="space-y-0.5 overflow-hidden">
                                        <div className="font-bold text-xs text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                                            {app.name || 'Aplicación'}
                                            {isSystemApp && (
                                                <Badge variant="outline" className="text-[9px] py-0 px-1">Sistema</Badge>
                                            )}
                                        </div>
                                        <div className="font-mono text-[10px] text-muted-foreground truncate">
                                            {app.packageName}
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2 shrink-0">
                                        <span className={`text-[10px] font-bold ${isAllowed ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-700 dark:text-rose-400'}`}>
                                            {isAllowed ? 'Permitida' : 'Suspendida'}
                                        </span>
                                        <Switch 
                                            checked={isAllowed} 
                                            onCheckedChange={(val) => handleToggleAppWhitelist(app.packageName, val)} 
                                        />
                                    </div>
                                </div>
                            );
                        })}
                    </div>

                    <div className="flex justify-end gap-2 pt-2 border-t">
                        <Button variant="outline" size="sm" onClick={() => setSelectedAppsDevice(null)}>
                            Cancelar
                        </Button>
                        <Button 
                            size="sm" 
                            onClick={handleSaveAppWhitelist}
                            disabled={isPending}
                            className="bg-purple-600 hover:bg-purple-700 text-white font-bold"
                        >
                            Guardar Lista Blanca
                        </Button>
                    </div>
                </DialogContent>
            </Dialog>
        </main>
    );
}
