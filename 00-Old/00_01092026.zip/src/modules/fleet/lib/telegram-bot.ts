import { getDb } from '@/modules/core/lib/db';
import { FLEET_TABLES } from './schema';
import { logInfo, logError } from '@/modules/core/lib/logger';
import { triggerNotificationEvent } from '@/modules/notifications/lib/notifications-engine';
import { getVehicleById, updateVehicleMileageAndCheckAlerts, checkIsOilChange } from './db';
import { format, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import crypto from 'crypto';

export interface TelegramBotState {
  chatId: string;
  currentFlow: string | null;
  step: string | null;
  tempData: string | null;
  updatedAt: string;
}

export interface TelegramLinkage {
  id: number;
  chatId: string | null;
  employeeId: string;
  username: string | null;
  activationCode: string | null;
  createdAt: string;
  allowFuel?: number;
  allowMaintenance?: number;
  allowDeliveries?: number;
  allowWarehouse?: number;
  employeeName?: string;
  isMechanic?: boolean;
}

/**
 * --- BOT STATES ---
 */

export async function getTelegramState(chatId: string): Promise<TelegramBotState | null> {
  const db = await getDb();
  try {
    const row = db.prepare(`SELECT * FROM ${FLEET_TABLES.telegramStates} WHERE chatId = ?`).get(chatId) as TelegramBotState | undefined;
    return row || null;
  } catch (error: any) {
    console.error(`Error in getTelegramState for chatId ${chatId}:`, error);
    return null;
  }
}

export async function saveTelegramState(
  chatId: string,
  currentFlow: string | null,
  step: string | null,
  tempData: any
): Promise<void> {
  const db = await getDb();
  const tempDataStr = tempData ? JSON.stringify(tempData) : null;
  const now = new Date().toISOString();
  try {
    db.prepare(`
      INSERT INTO ${FLEET_TABLES.telegramStates} (chatId, currentFlow, step, tempData, updatedAt)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(chatId) DO UPDATE SET
        currentFlow = excluded.currentFlow,
        step = excluded.step,
        tempData = excluded.tempData,
        updatedAt = excluded.updatedAt
    `).run(chatId, currentFlow, step, tempDataStr, now);
  } catch (error: any) {
    console.error(`Error in saveTelegramState for chatId ${chatId}:`, error);
    throw error;
  }
}

export async function deleteTelegramState(chatId: string): Promise<void> {
  const db = await getDb();
  try {
    db.prepare(`DELETE FROM ${FLEET_TABLES.telegramStates} WHERE chatId = ?`).run(chatId);
  } catch (error: any) {
    console.error(`Error in deleteTelegramState for chatId ${chatId}:`, error);
    throw error;
  }
}

export async function saveTelegramBotLog(
  db: any,
  vehicleId: number,
  actionType: 'fuel' | 'maintenance' | 'rtv' | 'delivery',
  driverName: string,
  message: string,
  details?: any
): Promise<void> {
  try {
    // Defensive check: Verify if vehicleId exists in fleet_vehicles to prevent FOREIGN KEY violation
    let finalVehicleId = vehicleId;
    const vehicleExists = db.prepare("SELECT id FROM fleet_vehicles WHERE id = ?").get(finalVehicleId);
    
    if (!vehicleExists) {
      // Try to find the vehicle from the driver's active assignment
      let activeVehicleId: number | null = null;
      try {
        const activeAss = db.prepare(`
          SELECT vehiculo_id FROM ops_delivery_assignments a
          JOIN core_employees e ON a.empleado_id = e.EMPLEADO
          WHERE a.activa = 1 AND e.NOMBRE = ?
          LIMIT 1
        `).get(driverName) as { vehiculo_id: number } | undefined;
        if (activeAss && activeAss.vehiculo_id) {
          activeVehicleId = activeAss.vehiculo_id;
        }
      } catch (err) {
        console.error("Error finding active vehicle for log fallback:", err);
      }

      if (activeVehicleId) {
        finalVehicleId = activeVehicleId;
      } else {
        const fallbackVehicle = db.prepare("SELECT id FROM fleet_vehicles ORDER BY id ASC LIMIT 1").get() as { id: number } | undefined;
        if (fallbackVehicle) {
          finalVehicleId = fallbackVehicle.id;
        } else {
          console.warn("Skipping saveTelegramBotLog: No active vehicles registered in fleet_vehicles to satisfy FOREIGN KEY constraint.");
          return;
        }
      }
    }

    db.prepare(`
      INSERT INTO ${FLEET_TABLES.telegramBotLogs} (vehicleId, timestamp, actionType, driverName, message, details)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(
      finalVehicleId,
      new Date().toISOString(),
      actionType,
      driverName,
      message,
      details ? JSON.stringify(details) : null
    );
  } catch (error) {
    console.error("Error saving Telegram bot log:", error);
  }
}

export async function getAllActiveBotStates(): Promise<any[]> {
  const db = await getDb();
  try {
    const rows = db.prepare(`
      SELECT s.*, l.username, COALESCE(e.NOMBRE, u.name) as employeeName
      FROM ${FLEET_TABLES.telegramStates} s
      LEFT JOIN ${FLEET_TABLES.telegramLinkages} l ON s.chatId = l.chatId
      LEFT JOIN core_employees e ON l.employeeId = e.EMPLEADO
      LEFT JOIN core_users u ON l.employeeId = ('U-' || u.id)
      ORDER BY s.updatedAt DESC
    `).all() as any[];
    return JSON.parse(JSON.stringify(rows));
  } catch (error) {
    console.error("Error in getAllActiveBotStates:", error);
    return [];
  }
}

/**
 * --- USER LINKAGES ---
 */

export async function getLinkageByChatId(chatId: string): Promise<TelegramLinkage | null> {
  const db = await getDb();
  try {
    const row = db.prepare(`
      SELECT l.*, COALESCE(e.NOMBRE, u.name) as employeeName 
      FROM ${FLEET_TABLES.telegramLinkages} l
      LEFT JOIN core_employees e ON l.employeeId = e.EMPLEADO AND e.ACTIVO = 'S'
      LEFT JOIN core_users u ON l.employeeId = ('U-' || u.id)
      WHERE l.chatId = ? AND (e.EMPLEADO IS NOT NULL OR u.id IS NOT NULL)
    `).get(chatId) as TelegramLinkage | undefined;
    return row || null;
  } catch (error) {
    console.error(`Error in getLinkageByChatId for ${chatId}:`, error);
    return null;
  }
}

export async function getLinkageByCode(code: string): Promise<TelegramLinkage | null> {
  const db = await getDb();
  try {
    const row = db.prepare(`
      SELECT l.*, COALESCE(e.NOMBRE, u.name) as employeeName
      FROM ${FLEET_TABLES.telegramLinkages} l
      LEFT JOIN core_employees e ON l.employeeId = e.EMPLEADO AND e.ACTIVO = 'S'
      LEFT JOIN core_users u ON l.employeeId = ('U-' || u.id)
      WHERE l.activationCode = ? AND (e.EMPLEADO IS NOT NULL OR u.id IS NOT NULL)
    `).get(code.toUpperCase().trim()) as TelegramLinkage | undefined;

    if (!row) return null;

    // Validar expiración de 15 minutos (900,000 ms)
    if (row.createdAt) {
      const createdTime = new Date(row.createdAt).getTime();
      const nowTime = Date.now();
      if (nowTime - createdTime > 15 * 60 * 1000) {
        return null; // Código expirado
      }
    }

    return row;
  } catch (error) {
    console.error(`Error in getLinkageByCode for code ${code}:`, error);
    return null;
  }
}

export async function createLinkageCode(employeeId: string): Promise<string> {
  const db = await getDb();
  const now = new Date().toISOString();
  
  // Generar código de 6 caracteres criptográficamente seguro (CSPRNG)
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Omit confusing chars (1, I, 0, O)
  let code = '';
  for (let i = 0; i < 6; i++) {
    const idx = crypto.randomInt(0, chars.length);
    code += chars.charAt(idx);
  }

  try {
    db.prepare(`
      INSERT INTO ${FLEET_TABLES.telegramLinkages} (employeeId, activationCode, createdAt)
      VALUES (?, ?, ?)
      ON CONFLICT(employeeId) DO UPDATE SET
        activationCode = excluded.activationCode,
        chatId = NULL,
        username = NULL,
        createdAt = excluded.createdAt
    `).run(employeeId, code, now);
    
    await logInfo(`Código de vinculación Telegram generado para empleado ${employeeId}: ${code}`);
    return code;
  } catch (error) {
    console.error(`Error in createLinkageCode for employee ${employeeId}:`, error);
    throw error;
  }
}

export async function linkTelegramManually(employeeId: string, chatId: string, username?: string): Promise<void> {
  const db = await getDb();
  const now = new Date().toISOString();
  try {
    db.prepare(`
      INSERT INTO ${FLEET_TABLES.telegramLinkages} (employeeId, chatId, username, activationCode, createdAt)
      VALUES (?, ?, ?, NULL, ?)
      ON CONFLICT(employeeId) DO UPDATE SET
        chatId = excluded.chatId,
        username = excluded.username,
        activationCode = NULL,
        createdAt = excluded.createdAt
    `).run(employeeId, chatId, username || null, now);
    await logInfo(`Vinculación Telegram manual realizada para empleado ${employeeId} -> ChatID ${chatId}`);
  } catch (error) {
    console.error(`Error in linkTelegramManually:`, error);
    throw error;
  }
}

export async function activateLinkage(code: string, chatId: string, username?: string): Promise<TelegramLinkage> {
  const db = await getDb();
  const cleanedCode = code.toUpperCase().trim();
  try {
    const linkage = await getLinkageByCode(cleanedCode);
    if (!linkage) {
      throw new Error("Código de activación inválido");
    }

    db.prepare(`
      UPDATE ${FLEET_TABLES.telegramLinkages}
      SET chatId = ?, username = ?, activationCode = NULL
      WHERE id = ?
    `).run(chatId, username || null, linkage.id);

    await logInfo(`Vinculación Telegram activada: Empleado ${linkage.employeeId} vinculado al chat ${chatId}`);
    return linkage;
  } catch (error) {
    console.error(`Error in activateLinkage:`, error);
    throw error;
  }
}

export async function removeLinkage(id: number): Promise<void> {
  const db = await getDb();
  try {
    db.prepare(`DELETE FROM ${FLEET_TABLES.telegramLinkages} WHERE id = ?`).run(id);
    await logInfo(`Vinculación de Telegram eliminada (ID: ${id})`);
  } catch (error) {
    console.error(`Error in removeLinkage:`, error);
    throw error;
  }
}

export async function updateLinkagePermissions(
  id: number,
  permissions: { allowFuel: boolean; allowMaintenance: boolean; allowDeliveries: boolean; allowWarehouse: boolean }
): Promise<void> {
  const db = await getDb();
  try {
    db.prepare(`
      UPDATE ${FLEET_TABLES.telegramLinkages}
      SET allowFuel = ?, allowMaintenance = ?, allowDeliveries = ?, allowWarehouse = ?
      WHERE id = ?
    `).run(
      permissions.allowFuel ? 1 : 0,
      permissions.allowMaintenance ? 1 : 0,
      permissions.allowDeliveries ? 1 : 0,
      permissions.allowWarehouse ? 1 : 0,
      id
    );
    await logInfo(`Permisos de Telegram actualizados para vinculación ID: ${id}`);
  } catch (error: any) {
    console.error(`Error in updateLinkagePermissions:`, error);
    throw error;
  }
}

export async function getAllLinkages(): Promise<TelegramLinkage[]> {
  const db = await getDb();
  try {
    const rows = db.prepare(`
      SELECT l.*, COALESCE(e.NOMBRE, u.name) as employeeName
      FROM ${FLEET_TABLES.telegramLinkages} l
      LEFT JOIN core_employees e ON l.employeeId = e.EMPLEADO
      LEFT JOIN core_users u ON l.employeeId = ('U-' || u.id)
      ORDER BY COALESCE(e.NOMBRE, u.name)
    `).all() as TelegramLinkage[];
    return JSON.parse(JSON.stringify(rows));
  } catch (error) {
    console.error("Error in getAllLinkages:", error);
    return [];
  }
}

/**
 * --- BOT CONFIGURATION SETTINGS ---
 * Using fleet_settings table with category = 'telegram_bot_fleet_settings'
 */

export async function getTelegramBotSettings(): Promise<{ requirePhotoFuel: boolean; requirePhotoMaintenance: boolean }> {
  const db = await getDb();
  try {
    const rows = db.prepare(`
      SELECT value FROM ${FLEET_TABLES.settings} 
      WHERE category = 'telegram_bot_fleet_settings'
    `).all() as { value: string }[];
    
    let requirePhotoFuel = false;
    let requirePhotoMaintenance = false;

    for (const r of rows) {
      if (r.value === 'require_photo_fuel:true') requirePhotoFuel = true;
      if (r.value === 'require_photo_maintenance:true') requirePhotoMaintenance = true;
    }

    return { requirePhotoFuel, requirePhotoMaintenance };
  } catch (error) {
    console.error("Error in getTelegramBotSettings:", error);
    return { requirePhotoFuel: false, requirePhotoMaintenance: false };
  }
}

export async function updateTelegramBotSetting(key: 'requirePhotoFuel' | 'requirePhotoMaintenance', enabled: boolean): Promise<void> {
  const db = await getDb();
  const valueToInsert = `${key === 'requirePhotoFuel' ? 'require_photo_fuel' : 'require_photo_maintenance'}:${enabled}`;
  const valueToRemove = `${key === 'requirePhotoFuel' ? 'require_photo_fuel' : 'require_photo_maintenance'}:${!enabled}`;
  
  try {
    db.transaction(() => {
      // Remove any existing setting for this parameter
      db.prepare(`
        DELETE FROM ${FLEET_TABLES.settings} 
        WHERE category = 'telegram_bot_fleet_settings' AND (value = ? OR value = ?)
      `).run(valueToInsert, valueToRemove);
      
      // If enabled, insert it
      if (enabled) {
        db.prepare(`
          INSERT INTO ${FLEET_TABLES.settings} (category, value, price) 
          VALUES ('telegram_bot_fleet_settings', ?, 0)
        `).run(valueToInsert);
      }
    })();
    await logInfo(`Telegram Bot Configuración actualizada: ${key} = ${enabled}`);
  } catch (error) {
    console.error("Error in updateTelegramBotSetting:", error);
    throw error;
  }
}

export async function getVehicleByPlate(plate: string): Promise<any | null> {
  const db = await getDb();
  try {
    const row = db.prepare(`SELECT * FROM ${FLEET_TABLES.vehicles} WHERE UPPER(plate) = ?`).get(plate.toUpperCase().trim()) as any;
    return row ? JSON.parse(JSON.stringify(row)) : null;
  } catch (error) {
    console.error(`Error in getVehicleByPlate for plate ${plate}:`, error);
    return null;
  }
}

export async function getPlateSuggestions(plate: string): Promise<string[]> {
  const db = await getDb();
  try {
    const cleanText = plate.trim().toUpperCase();
    if (cleanText.length < 2) return [];
    const rows = db.prepare(`SELECT plate FROM ${FLEET_TABLES.vehicles} WHERE UPPER(plate) LIKE ? LIMIT 5`).all(`%${cleanText}%`) as any[];
    return rows.map(r => r.plate);
  } catch (error) {
    console.error(`Error in getPlateSuggestions for ${plate}:`, error);
    return [];
  }
}

export async function getMaintenanceTypes(): Promise<string[]> {
  const db = await getDb();
  try {
    const rows = db.prepare(`
      SELECT value FROM ${FLEET_TABLES.settings} 
      WHERE category = 'maintenance_type' 
      ORDER BY value
    `).all() as { value: string }[];
    return rows.map(r => r.value);
  } catch (error) {
    console.error("Error in getMaintenanceTypes:", error);
    return ['Cambio de Aceite', 'Cambio de Llantas', 'Frenos', 'RTV', 'Mantenimiento General'];
  }
}

export async function saveTelegramFuelLog(log: any, userName: string) {
    const db = await getDb();
    let dateToSave = log.date;
    if (typeof log.date === 'string' && log.date.length === 10) {
        const now = new Date();
        const timeStr = format(now, 'HH:mm:ss');
        dateToSave = `${log.date}T${timeStr}`;
    }

    const logWithUser = { ...log, date: dateToSave, createdBy: userName };
    
    // Insert into DB directly (without authorizeAction)
    try {
        const transaction = db.transaction((data) => {
            db.prepare(`
                INSERT INTO ${FLEET_TABLES.fuelLogs} (vehicleId, date, mileageBefore, liters, cost, driverId, fuelTypeId, notes, createdBy)
                VALUES (@vehicleId, @date, @mileageBefore, @liters, @cost, @driverId, @fuelTypeId, @notes, @createdBy)
            `).run(data);

            // Update current mileage if the log mileage is higher
            db.prepare(`
                UPDATE ${FLEET_TABLES.vehicles} 
                SET currentMileage = MAX(COALESCE(currentMileage, 0), ?) 
                WHERE id = ?
            `).run(data.mileageBefore, data.vehicleId);
        });
        transaction(logWithUser);
        await saveTelegramBotLog(
            db,
            log.vehicleId,
            'fuel',
            userName,
            `Se registró un repostaje de ${log.liters.toFixed(2)} L (Odómetro: ${log.mileageBefore.toLocaleString()} | Costo: CRC ${log.cost?.toLocaleString()})`
        );
        await logInfo(`Fuel log registered via Telegram Bot for vehicle ${log.vehicleId}`);
    } catch (error: any) {
        console.error("Error saving fuel log in Telegram Bot", error);
        await logError(`Error al guardar repostaje vía Telegram Bot para vehículo ID: ${log.vehicleId}`, {
            error: error.message,
            logData: log,
            userName
        });
        throw error;
    }
    
    // Trigger Notification via Engine
    try {
        const vehicle = await getVehicleById(log.vehicleId);
        if (vehicle) {
            const fuelTypeRow = log.fuelTypeId ? db.prepare(`SELECT value FROM fleet_settings WHERE id = ?`).get(log.fuelTypeId) as { value: string } | undefined : undefined;
            const fuelTypeName = fuelTypeRow ? fuelTypeRow.value : 'No especificado';

            await triggerNotificationEvent('onFleetFuelLogAdded', {
                ...log,
                ...vehicle,
                userName,
                fuelTypeName,
                date: format(parseISO(dateToSave), 'dd/MM/yyyy HH:mm', { locale: es }),
                cost: Number(log.cost).toLocaleString('es-CR', { minimumFractionDigits: 2 })
            });
        }
    } catch (e: any) {
        console.error('Failed to trigger fuel log notification', e);
    }

    // Check for maintenance alerts and update mileage via central helper
    try {
        await updateVehicleMileageAndCheckAlerts(db, log.vehicleId, log.mileageBefore, null);
    } catch (e: any) {
        console.error('Failed to process maintenance alert via central helper', e);
    }
}

export async function saveTelegramMaintenanceLog(log: any, userName: string) {
    const db = await getDb();
    let dateToSave = log.date;
    if (typeof log.date === 'string' && log.date.length === 10) {
        const now = new Date();
        const timeStr = format(now, 'HH:mm:ss');
        dateToSave = `${log.date}T${timeStr}`;
    }

    const logWithUser = { ...log, date: dateToSave, createdBy: userName };
    
    // Insert into DB directly (without authorizeAction)
    try {
        const transaction = db.transaction((data) => {
            db.prepare(`
                INSERT INTO ${FLEET_TABLES.maintenanceLogs} (vehicleId, date, mileage, type, description, cost, performedBy, createdBy)
                VALUES (@vehicleId, @date, @mileage, @type, @description, @cost, @performedBy, @createdBy)
            `).run(data);

            // If it's an oil change, update the last oil change mileage
            const isOilChange = checkIsOilChange(data.type, data.description);
            
            if (isOilChange) {
                db.prepare(`
                    UPDATE ${FLEET_TABLES.vehicles} 
                    SET lastOilChangeMileage = ?, currentMileage = MAX(COALESCE(currentMileage, 0), ?), lastOilChangeAlertThreshold = 0
                    WHERE id = ?
                `).run(data.mileage, data.mileage, data.vehicleId);
            } else {
                db.prepare(`
                    UPDATE ${FLEET_TABLES.vehicles} 
                    SET currentMileage = MAX(COALESCE(currentMileage, 0), ?)
                    WHERE id = ?
                `).run(data.mileage, data.vehicleId);
            }

            // Auto update preventative plans lastPerformedValue and reset threshold
            db.prepare(`
                UPDATE fleet_preventative_plans
                SET lastPerformedValue = ?, lastAlertThreshold = 0
                WHERE vehicleId = ? AND maintenanceType = ?
            `).run(data.mileage, data.vehicleId, data.type);
        });
        transaction(logWithUser);
        await saveTelegramBotLog(
            db,
            log.vehicleId,
            'maintenance',
            userName,
            `Se registró mantenimiento [${log.type}] (Odómetro: ${log.mileage.toLocaleString()} | Costo: CRC ${log.cost?.toLocaleString()} | Realizado por: ${log.performedBy || 'N/D'})`
        );
        await logInfo(`Maintenance log (${log.type}) registered via Telegram Bot for vehicle ${log.vehicleId}`);
    } catch (error: any) {
        console.error("Error saving maintenance log in Telegram Bot", error);
        await logError(`Error al guardar mantenimiento (${log.type}) vía Telegram Bot para vehículo ID: ${log.vehicleId}`, {
            error: error.message,
            logData: log,
            userName
        });
        throw error;
    }

    // Check for maintenance alerts and update mileage via central helper
    try {
        await updateVehicleMileageAndCheckAlerts(db, log.vehicleId, log.mileage, null);
    } catch (e: any) {
        console.error('Failed to process maintenance alert via central helper', e);
    }

    // Trigger Notification via Engine
    try {
        const vehicle = await getVehicleById(log.vehicleId);
        if (vehicle) {
            await triggerNotificationEvent('onFleetMaintenanceLogAdded', {
                ...log,
                ...vehicle,
                userName,
                date: format(parseISO(dateToSave), 'dd/MM/yyyy HH:mm', { locale: es }),
                cost: Number(log.cost).toLocaleString('es-CR', { minimumFractionDigits: 2 })
            });
        }
    } catch (e: any) {
        console.error('Failed to trigger maintenance log notification', e);
    }
}

/**
 * --- HELPER FUNCTIONS FOR SUPPORT TICKETS & MECHANIC TELEGRAM WORKFLOWS ---
 */

export async function checkIsMechanic(employeeId: string): Promise<boolean> {
    const db = await getDb();
    try {
        let userRow;
        if (employeeId.startsWith('U-')) {
            userRow = db.prepare("SELECT id FROM core_users WHERE ('U-' || id) = ?").get(employeeId) as { id: number } | undefined;
        } else {
            userRow = db.prepare("SELECT id FROM core_users WHERE employeeId = ?").get(employeeId) as { id: number } | undefined;
        }
        if (!userRow) return false;
        const mapping = db.prepare("SELECT 1 FROM inv_department_technicians WHERE department_id = 1 AND user_id = ?").get(userRow.id);
        return !!mapping;
    } catch (err) {
        console.error("Error in checkIsMechanic:", err);
        return false;
    }
}

export async function getCoreUserIdFromLinkage(employeeId: string): Promise<number | null> {
    const db = await getDb();
    try {
        let userRow;
        if (employeeId.startsWith('U-')) {
            userRow = db.prepare("SELECT id FROM core_users WHERE ('U-' || id) = ?").get(employeeId) as { id: number } | undefined;
        } else {
            userRow = db.prepare("SELECT id FROM core_users WHERE employeeId = ?").get(employeeId) as { id: number } | undefined;
        }
        return userRow ? userRow.id : null;
    } catch (err) {
        console.error("Error in getCoreUserIdFromLinkage:", err);
        return null;
    }
}

export async function createTicketFromTelegram(ticket: {
    departmentId: number;
    subject: string;
    description: string;
    priority?: string;
    maintenanceType?: string;
    equipmentName: string;
    brand?: string;
    model?: string;
    serialNumber?: string;
    user: string;
}): Promise<string> {
    const db = await getDb();
    const now = new Date().toISOString();
    return db.transaction(() => {
        const settings = db.prepare('SELECT ticket_prefix, next_ticket_number FROM ticket_settings WHERE department_id = ?').get(ticket.departmentId) as { ticket_prefix: string; next_ticket_number: number } | undefined;
        if (!settings) {
            throw new Error('Configuración de tickets no encontrada para este departamento.');
        }

        const prefix = settings.ticket_prefix;
        const nextNum = settings.next_ticket_number;
        const consecutive = `${prefix}${String(nextNum).padStart(6, '0')}`;

        db.prepare(`
            INSERT INTO repair_tickets (
                consecutive, department_id, subject, description, status, priority,
                maintenance_type, equipment_name, brand, model, serial_number, created_at, created_by
            ) VALUES (?, ?, ?, ?, 'open', ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
            consecutive,
            ticket.departmentId,
            ticket.subject,
            ticket.description,
            ticket.priority || 'medium',
            ticket.maintenanceType || 'corrective',
            ticket.equipmentName,
            ticket.brand || null,
            ticket.model || null,
            ticket.serialNumber || null,
            now,
            ticket.user
        );

        db.prepare('UPDATE ticket_settings SET next_ticket_number = ? WHERE department_id = ?').run(nextNum + 1, ticket.departmentId);
        return consecutive;
    })();
}

export async function getOpenTicketsForMechanic(userId: number | null): Promise<any[]> {
    const db = await getDb();
    try {
        if (userId) {
            return db.prepare(`
                SELECT * FROM repair_tickets 
                WHERE department_id = 1 AND status IN ('open', 'in_progress', 'on_hold')
                  AND (assignee_id = ? OR assignee_id IS NULL)
                ORDER BY id DESC LIMIT 15
            `).all(userId) as any[];
        } else {
            return db.prepare(`
                SELECT * FROM repair_tickets 
                WHERE department_id = 1 AND status IN ('open', 'in_progress', 'on_hold')
                ORDER BY id DESC LIMIT 15
            `).all() as any[];
        }
    } catch (err) {
        console.error("Error in getOpenTicketsForMechanic:", err);
        return [];
    }
}

export async function assignTicketToMechanic(ticketId: number, userId: number): Promise<void> {
    const db = await getDb();
    try {
        db.prepare('UPDATE repair_tickets SET assignee_id = ? WHERE id = ?').run(userId, ticketId);
    } catch (err) {
        console.error("Error in assignTicketToMechanic:", err);
        throw err;
    }
}

export async function updateTicketStatusFromTelegram(ticketId: number, status: string, user: string): Promise<void> {
    const db = await getDb();
    const now = new Date().toISOString();
    try {
        db.transaction(() => {
            if (status === 'completed' || status === 'canceled') {
                db.prepare(`
                    UPDATE repair_tickets 
                    SET status = ?, closed_at = ?, closed_by = ? 
                    WHERE id = ?
                `).run(status, now, user, ticketId);
            } else {
                db.prepare(`
                    UPDATE repair_tickets 
                    SET status = ?, closed_at = NULL, closed_by = NULL 
                    WHERE id = ?
                `).run(status, ticketId);
            }
        })();
    } catch (err) {
        console.error("Error in updateTicketStatusFromTelegram:", err);
        throw err;
    }
}

export async function searchSpareParts(query: string): Promise<any[]> {
    const db = await getDb();
    try {
        return db.prepare(`
            SELECT id, name, brand, model, quantity, unit, price 
            FROM inv_items 
            WHERE department_id = 1 AND status = 'active'
              AND (name LIKE ? OR brand LIKE ? OR id LIKE ?)
            LIMIT 5
        `).all(`%${query}%`, `%${query}%`, `%${query}%`) as any[];
    } catch (err) {
        console.error("Error in searchSpareParts:", err);
        return [];
    }
}

export async function consumeSparePartForTicket(ticketId: number, itemId: string, quantity: number, user: string): Promise<void> {
    const db = await getDb();
    const now = new Date().toISOString();
    try {
        db.transaction(() => {
            const item = db.prepare('SELECT price, quantity, name, unit FROM inv_items WHERE id = ? AND department_id = 1').get(itemId) as { price: number; quantity: number; name: string; unit: string } | undefined;
            if (!item) {
                throw new Error('El repuesto no existe en el inventario del taller.');
            }
            if (item.quantity < quantity) {
                throw new Error(`Stock insuficiente. Disponible: ${item.quantity} ${item.unit}`);
            }

            const ticket = db.prepare('SELECT consecutive FROM repair_tickets WHERE id = ?').get(ticketId) as { consecutive: string } | undefined;
            if (!ticket) {
                throw new Error('Ticket no encontrado.');
            }

            db.prepare('UPDATE inv_items SET quantity = quantity - ? WHERE id = ?').run(quantity, itemId);

            db.prepare(`
                INSERT INTO inv_transactions (item_id, quantity, type, reason, reference_id, created_at, created_by)
                VALUES (?, ?, 'EXIT', ?, ?, ?, ?)
            `).run(itemId, quantity, `Consumo en Ticket ${ticket.consecutive}`, ticket.consecutive, now, user);

            db.prepare(`
                INSERT INTO ticket_parts (ticket_id, item_id, quantity, price, created_at, created_by)
                VALUES (?, ?, ?, ?, ?, ?)
            `).run(ticketId, itemId, quantity, item.price, now, user);
        })();
    } catch (err) {
        console.error("Error in consumeSparePartForTicket:", err);
        throw err;
    }
}

