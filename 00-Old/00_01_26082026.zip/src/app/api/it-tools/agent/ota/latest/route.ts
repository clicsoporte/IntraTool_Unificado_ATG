import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/modules/core/lib/db';
import { IT_TOOLS_TABLES } from '@/modules/it-tools/lib/schema';

/**
 * GET /api/it-tools/agent/ota/latest
 * Returns latest active OTA binary metadata
 */
export async function GET(req: NextRequest) {
  try {
    const db = await getDb();
    const latest = db.prepare(`
      SELECT version_name, version_code, file_url, file_size, sha256_hash, release_notes, created_at
      FROM ${IT_TOOLS_TABLES.agentOtaVersions}
      WHERE is_active = 1
      ORDER BY version_code DESC
      LIMIT 1
    `).get() as any;

    if (!latest) {
      return NextResponse.json({ success: true, ota_available: false });
    }

    return NextResponse.json({
      success: true,
      ota_available: true,
      version: latest
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
