import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/modules/core/lib/db';
import { IT_TOOLS_TABLES } from '@/modules/it-tools/lib/schema';

/**
 * POST /api/it-tools/agent/commands
 * Agent reports the execution result of a command
 */
export async function POST(req: NextRequest) {
  try {
    const db = await getDb();
    const payload = await req.json();
    const { command_id, status, result_output } = payload;

    if (!command_id || !status) {
      return NextResponse.json({ success: false, error: 'Missing command_id or status' }, { status: 400 });
    }

    const now = new Date().toISOString();
    const resultStr = typeof result_output === 'object' ? JSON.stringify(result_output) : String(result_output || '');

    const info = db.prepare(`
      UPDATE ${IT_TOOLS_TABLES.agentCommands} SET
        status = ?,
        result_output = ?,
        executed_at = ?
      WHERE id = ?
    `).run(status, resultStr, now, command_id);

    if (info.changes === 0) {
      return NextResponse.json({ success: false, error: 'Command not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true, command_id, updated_at: now });
  } catch (error: any) {
    console.error('Error reporting command result:', error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
