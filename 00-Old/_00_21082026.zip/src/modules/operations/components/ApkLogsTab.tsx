'use client';

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { 
    Search, 
    RefreshCw, 
    Smartphone, 
    User, 
    Truck, 
    MapPin, 
    AlertTriangle, 
    Info, 
    AlertCircle, 
    Clock, 
    Phone,
    RotateCcw,
    CheckCircle2,
    Printer,
    FileText,
    ShieldAlert,
    Coffee,
    Wrench,
    Check
} from 'lucide-react';
import { getApkDriverLogsAction } from '@/modules/operations/lib/actions';
import { formatFechaEntrega } from '@/modules/operations/lib/utils';

interface ApkLogsTabProps {
    tvMode?: boolean;
}

const ITEMS_PER_PAGE = 15;

export function ApkLogsTab({ tvMode = false }: ApkLogsTabProps) {
    const getLocalDateStr = () => {
        const d = new Date();
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    };

    const [apkDate, setApkDate] = useState<string>(getLocalDateStr());
    const [apkLogs, setApkLogs] = useState<any[]>([]);
    const [apkLogsLoading, setApkLogsLoading] = useState(false);
    const [actionFilter, setActionFilter] = useState<string>('all');
    const [searchTerm, setSearchTerm] = useState<string>('');
    const [apkPage, setApkPage] = useState(1);

    const fetchLogs = useCallback(async (dateToQuery?: string) => {
        setApkLogsLoading(true);
        try {
            const queryDate = dateToQuery || apkDate;
            const logs = await getApkDriverLogsAction(queryDate);
            setApkLogs(logs || []);
            setApkPage(1);
        } catch (error) {
            console.error("Error fetching APK driver logs:", error);
        } finally {
            setApkLogsLoading(false);
        }
    }, [apkDate]);

    useEffect(() => {
        fetchLogs();
    }, [fetchLogs]);

    // Identificar el tipo de acción para categorización y conteos
    const getLogActionType = (log: any): 'reversion' | 'entrega' | 'reimpresion' | 'pausa' | 'averia' | 'sin_evidencia' | 'otro' => {
        const cat = (log.category || '').toLowerCase();
        const msg = (log.message || '').toLowerCase();

        if (cat === 'reversion' || msg.includes('reversó') || msg.includes('reversion') || msg.includes('revertir')) {
            return 'reversion';
        }
        if (cat === 'reimpresion' || msg.includes('reimprimió') || msg.includes('reimpresion')) {
            return 'reimpresion';
        }
        if (cat === 'pausa' || msg.includes('pausa') || msg.includes('almuerzo') || msg.includes('merienda')) {
            return 'pausa';
        }
        if (cat === 'averia' || msg.includes('avería') || msg.includes('averia') || msg.includes('mecánica')) {
            return 'averia';
        }
        if (msg.includes('firma: ✗') && msg.includes('foto evidencia: ✗')) {
            return 'sin_evidencia';
        }
        if (cat === 'entrega' || msg.includes('entrega #') || msg.includes('procesada como')) {
            return 'entrega';
        }
        return 'otro';
    };

    // Conteos rápidos de auditoría para el supervisor
    const auditStats = useMemo(() => {
        let reversiones = 0;
        let entregas = 0;
        let reimpresiones = 0;
        let sinEvidencia = 0;
        let pausas = 0;

        apkLogs.forEach((log) => {
            const t = getLogActionType(log);
            if (t === 'reversion') reversiones++;
            else if (t === 'reimpresion') reimpresiones++;
            else if (t === 'sin_evidencia') { sinEvidencia++; entregas++; }
            else if (t === 'entrega') entregas++;
            else if (t === 'pausa' || t === 'averia') pausas++;
        });

        return { reversiones, entregas, reimpresiones, sinEvidencia, pausas };
    }, [apkLogs]);

    const filteredLogs = useMemo(() => {
        return apkLogs.filter((log: any) => {
            const actType = getLogActionType(log);

            if (actionFilter !== 'all') {
                if (actionFilter === 'reversion' && actType !== 'reversion') return false;
                if (actionFilter === 'entrega' && actType !== 'entrega' && actType !== 'sin_evidencia') return false;
                if (actionFilter === 'reimpresion' && actType !== 'reimpresion') return false;
                if (actionFilter === 'sin_evidencia' && actType !== 'sin_evidencia') return false;
                if (actionFilter === 'pausa' && actType !== 'pausa' && actType !== 'averia') return false;
            }

            if (searchTerm.trim()) {
                const term = searchTerm.toLowerCase();
                const matchMsg = (log.message || '').toLowerCase().includes(term);
                const matchUser = (log.chofer_nombre || log.user_name || '').toLowerCase().includes(term);
                const matchPlate = (log.placa_vehiculo || '').toLowerCase().includes(term);
                const matchRoute = (log.ruta_nombre || '').toLowerCase().includes(term);
                if (!matchMsg && !matchUser && !matchPlate && !matchRoute) return false;
            }

            return true;
        });
    }, [apkLogs, actionFilter, searchTerm]);

    const paginatedLogs = useMemo(() => {
        const startIndex = (apkPage - 1) * ITEMS_PER_PAGE;
        return filteredLogs.slice(startIndex, startIndex + ITEMS_PER_PAGE);
    }, [filteredLogs, apkPage]);

    const totalPages = Math.ceil(filteredLogs.length / ITEMS_PER_PAGE) || 1;

    const renderActionBadge = (log: any) => {
        const type = getLogActionType(log);

        switch (type) {
            case 'reversion':
                return (
                    <Badge variant="outline" className="bg-rose-500/15 text-rose-700 dark:text-rose-400 border-rose-500/40 gap-1.5 font-extrabold text-[11px] shadow-sm animate-pulse">
                        <RotateCcw className="w-3.5 h-3.5" /> REVERSIÓN DE ENTREGA
                    </Badge>
                );
            case 'reimpresion':
                return (
                    <Badge variant="outline" className="bg-cyan-500/15 text-cyan-700 dark:text-cyan-400 border-cyan-500/40 gap-1.5 font-bold text-[11px]">
                        <Printer className="w-3.5 h-3.5" /> REIMPRESIÓN BOLETA
                    </Badge>
                );
            case 'sin_evidencia':
                return (
                    <Badge variant="outline" className="bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/40 gap-1.5 font-bold text-[11px]">
                        <AlertTriangle className="w-3.5 h-3.5" /> SIN EVIDENCIA COMPLETA
                    </Badge>
                );
            case 'entrega':
                return (
                    <Badge variant="outline" className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/40 gap-1.5 font-bold text-[11px]">
                        <CheckCircle2 className="w-3.5 h-3.5" /> ENTREGA PROCESADA
                    </Badge>
                );
            case 'pausa':
                return (
                    <Badge variant="outline" className="bg-purple-500/15 text-purple-700 dark:text-purple-400 border-purple-500/40 gap-1.5 font-bold text-[11px]">
                        <Coffee className="w-3.5 h-3.5" /> PAUSA / DESCANSO
                    </Badge>
                );
            case 'averia':
                return (
                    <Badge variant="outline" className="bg-orange-500/15 text-orange-700 dark:text-orange-400 border-orange-500/40 gap-1.5 font-bold text-[11px]">
                        <Wrench className="w-3.5 h-3.5" /> AVERÍA REPORTADA
                    </Badge>
                );
            default:
                return (
                    <Badge variant="outline" className="bg-slate-500/10 text-slate-700 dark:text-slate-300 border-slate-500/30 gap-1.5 font-bold text-[11px]">
                        <Info className="w-3.5 h-3.5" /> EVENTO CHOFER
                    </Badge>
                );
        }
    };

    return (
        <div className="space-y-6 animate-in fade-in duration-300">
            {/* Header and Controls */}
            <div className={`p-4 border rounded-2xl flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 ${
                tvMode ? 'bg-slate-900/60 border-slate-800' : 'bg-card shadow-sm'
            }`}>
                <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-purple-500/20 to-indigo-500/20 border border-purple-500/30 flex items-center justify-center text-purple-600 dark:text-purple-400 shadow-sm">
                        <ShieldAlert className="w-6 h-6" />
                    </div>
                    <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                            <h3 className="text-base font-bold tracking-tight">Auditoría Operativa de Choferes (APK)</h3>
                            <Badge className="bg-purple-600 text-white font-mono text-[10px] uppercase">Supervisión</Badge>
                        </div>
                        <p className="text-xs text-muted-foreground font-medium">
                            Bitácora de acciones del chofer en ruta: reversiones, entregas con/sin evidencia, reimpresiones térmicas y descansos.
                        </p>
                    </div>
                </div>

                <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto justify-start lg:justify-end">
                    {/* Date Input */}
                    <div className="flex items-center gap-1.5 bg-muted/30 p-1 rounded-xl border border-muted/50">
                        <Input
                            type="date"
                            value={apkDate}
                            onChange={(e) => setApkDate(e.target.value)}
                            className={`h-9 w-36 rounded-lg font-bold text-xs border-0 bg-transparent shadow-none ${
                                tvMode ? 'text-white' : ''
                            }`}
                        />
                        <Button
                            size="sm"
                            onClick={() => fetchLogs(apkDate)}
                            className="rounded-lg font-bold text-xs bg-purple-600 hover:bg-purple-700 text-white gap-1.5 h-8 px-3"
                            disabled={apkLogsLoading}
                        >
                            <RefreshCw className={`w-3.5 h-3.5 ${apkLogsLoading ? 'animate-spin' : ''}`} />
                            Actualizar
                        </Button>
                    </div>
                </div>
            </div>

            {/* Quick Audit Metric Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                <button
                    onClick={() => { setActionFilter('all'); setApkPage(1); }}
                    className={`p-3 rounded-2xl border text-left transition-all ${
                        actionFilter === 'all' 
                            ? 'bg-purple-500/10 border-purple-500/40 ring-2 ring-purple-500/20' 
                            : 'bg-card border-muted/60 hover:border-muted'
                    }`}
                >
                    <span className="text-[11px] font-bold text-muted-foreground block">Total Eventos</span>
                    <span className="text-xl font-extrabold text-foreground">{apkLogs.length}</span>
                </button>

                <button
                    onClick={() => { setActionFilter('reversion'); setApkPage(1); }}
                    className={`p-3 rounded-2xl border text-left transition-all ${
                        actionFilter === 'reversion' 
                            ? 'bg-rose-500/15 border-rose-500/40 ring-2 ring-rose-500/20' 
                            : 'bg-card border-muted/60 hover:border-muted'
                    }`}
                >
                    <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-rose-600 dark:text-rose-400">🚨 Reversiones</span>
                        {auditStats.reversiones > 0 && (
                            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                        )}
                    </div>
                    <span className={`text-xl font-extrabold ${auditStats.reversiones > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-foreground'}`}>
                        {auditStats.reversiones}
                    </span>
                </button>

                <button
                    onClick={() => { setActionFilter('entrega'); setApkPage(1); }}
                    className={`p-3 rounded-2xl border text-left transition-all ${
                        actionFilter === 'entrega' 
                            ? 'bg-emerald-500/10 border-emerald-500/40 ring-2 ring-emerald-500/20' 
                            : 'bg-card border-muted/60 hover:border-muted'
                    }`}
                >
                    <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 block">✓ Entregas Procesadas</span>
                    <span className="text-xl font-extrabold text-foreground">{auditStats.entregas}</span>
                </button>

                <button
                    onClick={() => { setActionFilter('reimpresion'); setApkPage(1); }}
                    className={`p-3 rounded-2xl border text-left transition-all ${
                        actionFilter === 'reimpresion' 
                            ? 'bg-cyan-500/10 border-cyan-500/40 ring-2 ring-cyan-500/20' 
                            : 'bg-card border-muted/60 hover:border-muted'
                    }`}
                >
                    <span className="text-[11px] font-bold text-cyan-600 dark:text-cyan-400 block">🖨️ Reimpresiones</span>
                    <span className="text-xl font-extrabold text-foreground">{auditStats.reimpresiones}</span>
                </button>

                <button
                    onClick={() => { setActionFilter('pausa'); setApkPage(1); }}
                    className={`p-3 rounded-2xl border text-left transition-all ${
                        actionFilter === 'pausa' 
                            ? 'bg-amber-500/10 border-amber-500/40 ring-2 ring-amber-500/20' 
                            : 'bg-card border-muted/60 hover:border-muted'
                    }`}
                >
                    <span className="text-[11px] font-bold text-amber-600 dark:text-amber-400 block">☕ Pausas / Averías</span>
                    <span className="text-xl font-extrabold text-foreground">{auditStats.pausas}</span>
                </button>
            </div>

            {/* Search Input Filter */}
            <div className="relative">
                <Search className="w-4 h-4 text-muted-foreground absolute left-3.5 top-1/2 -translate-y-1/2" />
                <Input
                    type="text"
                    placeholder="Buscar por chofer, cliente, número de documento (#123), placa o ruta..."
                    value={searchTerm}
                    onChange={(e) => { setSearchTerm(e.target.value); setApkPage(1); }}
                    className="pl-9 h-10 rounded-xl bg-card border-muted font-medium text-xs shadow-sm"
                />
            </div>

            {apkLogsLoading ? (
                <div className="flex items-center justify-center p-12 bg-card rounded-2xl border border-muted animate-pulse">
                    <div className="text-center space-y-4">
                        <RefreshCw className="w-8 h-8 animate-spin mx-auto text-purple-500" />
                        <p className="text-muted-foreground font-medium text-xs">Cargando bitácora de auditoría del chofer...</p>
                    </div>
                </div>
            ) : filteredLogs.length === 0 ? (
                <div className="p-12 text-center bg-card rounded-2xl border border-muted/50 space-y-3">
                    <Smartphone className="w-10 h-10 text-muted-foreground/40 mx-auto" />
                    <h4 className="text-sm font-bold text-foreground">No se encontraron acciones para los filtros seleccionados</h4>
                    <p className="text-xs text-muted-foreground max-w-md mx-auto">
                        No hay registros reportados por los choferes para el día seleccionado con el filtro de acción actual.
                    </p>
                </div>
            ) : (
                <div className="space-y-3">
                    {paginatedLogs.map((log: any) => {
                        const isReversion = getLogActionType(log) === 'reversion';
                        const isReprint = getLogActionType(log) === 'reimpresion';
                        
                        return (
                            <div 
                                key={log.id || Math.random()} 
                                className={`p-4 rounded-2xl border transition-all duration-200 hover:shadow-md ${
                                    isReversion
                                        ? 'bg-rose-500/[0.04] border-rose-500/40 dark:border-rose-900/60 hover:border-rose-500'
                                        : isReprint
                                        ? 'bg-cyan-500/[0.03] border-cyan-500/30 dark:border-cyan-900/50 hover:border-cyan-500/60'
                                        : tvMode ? 'bg-slate-900/40 border-slate-800/80 hover:border-slate-700' : 'bg-card border-muted/50 hover:border-border'
                                }`}
                            >
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 mb-2 border-b border-muted/30">
                                    <div className="flex items-center gap-2 flex-wrap">
                                        {renderActionBadge(log)}
                                        
                                        <div className="flex items-center gap-1.5 text-xs font-bold text-foreground bg-muted/30 px-2 py-0.5 rounded-md">
                                            <User className="w-3.5 h-3.5 text-primary" />
                                            <span>{log.chofer_nombre || log.user_name || 'Chofer APK'}</span>
                                        </div>

                                        {log.chofer_telefono && (
                                            <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
                                                <Phone className="w-3 h-3 text-emerald-500" />
                                                <span>{log.chofer_telefono}</span>
                                            </div>
                                        )}
                                    </div>

                                    <div className="flex items-center gap-2.5 text-xs text-muted-foreground font-medium shrink-0 flex-wrap sm:flex-nowrap">
                                        {log.placa_vehiculo && (
                                            <div className="flex items-center gap-1 bg-muted/50 px-2 py-0.5 rounded-md font-mono text-[10px] font-bold">
                                                <Truck className="w-3 h-3 text-sky-500" />
                                                {log.placa_vehiculo}
                                            </div>
                                        )}
                                        {log.ruta_nombre && (
                                            <div className="flex items-center gap-1 text-[11px]">
                                                <MapPin className="w-3 h-3 text-amber-500" />
                                                {log.ruta_nombre}
                                            </div>
                                        )}
                                        <div className="flex items-center gap-1 font-mono text-[11px] bg-muted/40 px-2 py-0.5 rounded-md font-bold text-foreground">
                                            <Clock className="w-3 h-3 text-primary" />
                                            {formatFechaEntrega(log.timestamp)}
                                        </div>
                                    </div>
                                </div>

                                <div className={`text-xs font-sans p-3 rounded-xl border leading-relaxed ${
                                    isReversion
                                        ? 'bg-rose-500/10 text-rose-950 dark:text-rose-200 border-rose-500/30 font-medium'
                                        : 'bg-muted/20 text-foreground border-muted/30'
                                }`}>
                                    {log.message}
                                </div>
                            </div>
                        );
                    })}

                    {/* Pagination */}
                    {totalPages > 1 && (
                        <div className="flex items-center justify-between pt-2 px-1 text-xs text-muted-foreground">
                            <span>
                                Mostrando página <strong>{apkPage}</strong> de <strong>{totalPages}</strong> ({filteredLogs.length} acciones registradas)
                            </span>
                            <div className="flex items-center gap-2">
                                <Button
                                    size="sm"
                                    variant="outline"
                                    disabled={apkPage <= 1}
                                    onClick={() => setApkPage(p => Math.max(1, p - 1))}
                                    className="rounded-xl h-8 text-xs font-bold"
                                >
                                    Anterior
                                </Button>
                                <Button
                                    size="sm"
                                    variant="outline"
                                    disabled={apkPage >= totalPages}
                                    onClick={() => setApkPage(p => Math.min(totalPages, p + 1))}
                                    className="rounded-xl h-8 text-xs font-bold"
                                >
                                    Siguiente
                                </Button>
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}
