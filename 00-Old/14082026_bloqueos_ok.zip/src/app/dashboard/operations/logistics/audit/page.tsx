'use client';

import React, { useState, useEffect, useCallback } from 'react';
import Image from 'next/image';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { useToast } from '@/modules/core/hooks/use-toast';
import { 
    Search, 
    Download, 
    ShieldCheck, 
    FileText, 
    Clock, 
    MapPin, 
    User, 
    Truck, 
    Calendar, 
    Camera, 
    CheckCircle2, 
    AlertTriangle, 
    XCircle, 
    ExternalLink, 
    Printer, 
    RefreshCw,
    Filter
} from 'lucide-react';
import Link from 'next/link';
import jsPDF from 'jspdf';
import { exportToExcel } from '@/modules/core/lib/excel-export';
import { searchDeliveryAuditLogs, exportDeliveryAuditLogsToCsv, AuditFilterParams } from '@/modules/operations/lib/audit-actions';
import { EvidencePhotoViewer } from '@/modules/operations/components/EvidencePhotoViewer';
import { getBoletaThermalPrintHtml, sendBoletaManualEmail } from '@/modules/operations/lib/actions';

export default function LogisticsAuditPage() {
    const { toast } = useToast();
    const [loading, setLoading] = useState(false);
    const [exporting, setExporting] = useState(false);
    const [results, setResults] = useState<any[]>([]);

    // Thermal Print & Email Modals
    const [thermalHtml, setThermalHtml] = useState<string | null>(null);
    const [thermalOpen, setThermalOpen] = useState(false);
    const [emailModalDoc, setEmailModalDoc] = useState<any | null>(null);
    const [targetEmail, setTargetEmail] = useState('');
    const [sendingEmail, setSendingEmail] = useState(false);
    
    // Pagination State
    const [page, setPage] = useState<number>(1);
    const [pageSize, setPageSize] = useState<number>(25);
    const [totalPages, setTotalPages] = useState<number>(1);
    const [totalCount, setTotalCount] = useState<number>(0);

    // Filter State
    const [filters, setFilters] = useState<AuditFilterParams>({
        documentoNumero: '',
        fechaDesde: '',
        fechaHasta: '',
        clienteNombre: '',
        choferNombre: '',
        vehiculoPlaca: '',
        estado: 'todos'
    });

    // Expediente Modal State
    const [selectedDoc, setSelectedDoc] = useState<any | null>(null);
    const [expedienteOpen, setExpedienteOpen] = useState(false);
    const [selectedPhoto, setSelectedPhoto] = useState<{ url: string; title: string } | null>(null);
    const [hasSearched, setHasSearched] = useState(false);

    const handleSearch = useCallback(async (targetPage = page, targetSize = pageSize) => {
        setLoading(true);
        setHasSearched(true);
        try {
            const res = await searchDeliveryAuditLogs({
                ...filters,
                page: targetPage,
                pageSize: targetSize
            });
            if (res.success && res.data) {
                setResults(res.data);
                setTotalPages(res.totalPages || 1);
                setTotalCount(res.totalCount || 0);
            } else {
                toast({ variant: 'destructive', title: 'Error de búsqueda', description: res.error || 'No se pudieron cargar los registros.' });
            }
        } catch (e: any) {
            toast({ variant: 'destructive', title: 'Error', description: e.message });
        } finally {
            setLoading(false);
        }
    }, [filters, page, pageSize, toast]);

    // Pagination change trigger (only after initial explicit search)
    useEffect(() => {
        if (hasSearched) {
            handleSearch(page, pageSize);
        }
    }, [page, pageSize, hasSearched, handleSearch]);

    const handleExportExcel = async () => {
        setExporting(true);
        try {
            const res = await searchDeliveryAuditLogs({ ...filters, page: 1, pageSize: 10000 });
            if (res.success && res.data) {
                const headers = [
                    'Documento',
                    'Tipo Documento',
                    'Estado',
                    'Cliente ID',
                    'Nombre Cliente',
                    'Chofer',
                    'Vehículo / Placa',
                    'Ruta',
                    'Vendedor ERP',
                    'Creador ERP',
                    'Fecha Registro',
                    'Hora Arribo Bodega',
                    'Hora Entrega Efectiva',
                    'Hora Salida Bodega',
                    'Minutos Descarga',
                    'Minutos Espera',
                    'Minutos Permanencia Total',
                    'Evidencias (Fotos)',
                    'Tiene Foto Factura',
                    'Tiene Foto Paquetes',
                    'Observación o Comentario de Calle',
                    'Dirección Embarque (EMB)',
                    'Coordenadas Lat/Lng'
                ];

                const excelRows = res.data.map(item => {
                    const hasPhotos = item.foto_factura || item.foto_evidencia ? 'Sí' : 'No';
                    const vehiculoStr = item.vehiculo_placa ? `${item.vehiculo_marca || ''} (${item.vehiculo_placa})` : '';
                    const direccionStr = item.direccion_embarque_erp || item.cliente_direccion || item.direccion_factura_erp || '';

                    return [
                        item.documento_numero || '',
                        item.tipo_documento || '',
                        item.estado || '',
                        item.cliente_id || '',
                        item.cliente_nombre || '',
                        item.chofer_nombre || 'No asignado',
                        vehiculoStr,
                        item.ruta_nombre || '',
                        item.vendedor || '',
                        item.creado_por || '',
                        item.fecha_registro || '',
                        item.hora_ingreso_geocerca || '',
                        item.hora_entrega_efectiva || item.fecha_entrega || '',
                        item.hora_salida_geocerca || '',
                        item.tiempo_descarga_min || 0,
                        item.tiempo_espera_post_entrega_min || 0,
                        item.tiempo_total_permanencia_min || 0,
                        hasPhotos,
                        item.foto_factura ? 'Sí' : 'No',
                        item.foto_evidencia ? 'Sí' : 'No',
                        item.comentario || '',
                        direccionStr,
                        item.latitud && item.longitud ? `${item.latitud},${item.longitud}` : ''
                    ];
                });

                exportToExcel({
                    fileName: 'Reporte_Auditoria_Entregas',
                    sheetName: 'Auditoría Entregas',
                    headers,
                    data: excelRows
                });

                toast({ title: 'Exportación Exitosa (.xlsx)', description: `Se descargó el libro de Excel con ${res.data.length} registros.` });
            } else {
                toast({ variant: 'destructive', title: 'Error al Exportar', description: res.error || 'No se pudo generar el archivo Excel.' });
            }
        } catch (e: any) {
            toast({ variant: 'destructive', title: 'Error', description: e.message });
        } finally {
            setExporting(false);
        }
    };

    const handleOpenExpediente = (doc: any) => {
        setSelectedDoc(doc);
        setExpedienteOpen(true);
    };

    const handlePrintThermalReceipt = async (docId: number) => {
        try {
            const res = await getBoletaThermalPrintHtml(docId);
            if (res.success && res.html) {
                setThermalHtml(res.html);
                setThermalOpen(true);
            } else {
                toast({ variant: 'destructive', title: 'Error de Formato', description: res.error || 'No se pudo generar la boleta.' });
            }
        } catch (e: any) {
            toast({ variant: 'destructive', title: 'Error', description: e.message });
        }
    };

    const handleSendEmailSubmit = async () => {
        if (!emailModalDoc || !targetEmail.trim()) return;
        setSendingEmail(true);
        try {
            const res = await sendBoletaManualEmail(emailModalDoc.id, targetEmail.trim());
            if (res.success) {
                toast({ title: 'Correo Enviado', description: `Se envió la boleta de entrega a ${targetEmail.trim()}` });
                setEmailModalDoc(null);
                setTargetEmail('');
            } else {
                toast({ variant: 'destructive', title: 'Error al Enviar', description: res.error });
            }
        } catch (e: any) {
            toast({ variant: 'destructive', title: 'Error', description: e.message });
        } finally {
            setSendingEmail(false);
        }
    };

    const handleDownloadExpedientePdf = (docTarget: any) => {
        if (!docTarget) return;
        try {
            const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'letter' });
            const marginX = 14;
            let currentY = 15;

            // Banner Header
            doc.setFillColor(30, 58, 138); // Deep Blue
            doc.rect(marginX, currentY, 188, 16, 'F');

            doc.setFont('Helvetica', 'bold');
            doc.setFontSize(13);
            doc.setTextColor(255, 255, 255);
            doc.text("EXPEDIENTE DIGITAL DE EVIDENCIA DE ENTREGA", marginX + 6, currentY + 10.5);

            currentY += 22;

            // Doc Ref & State
            doc.setFontSize(10.5);
            doc.setTextColor(15, 23, 42);
            doc.text(`Documento / Factura N°: ${docTarget.documento_numero || 'N/A'}`, marginX, currentY);
            doc.text(`Estado: ${docTarget.estado?.toUpperCase() || 'PENDIENTE'}`, marginX + 130, currentY);

            currentY += 6;
            doc.setDrawColor(226, 232, 240);
            doc.line(marginX, currentY, marginX + 188, currentY);
            currentY += 6;

            // Details Table Box
            doc.setFillColor(248, 250, 252);
            doc.rect(marginX, currentY, 188, 38, 'F');
            doc.setDrawColor(203, 213, 225);
            doc.rect(marginX, currentY, 188, 38, 'S');

            doc.setFontSize(9);
            doc.setFont('Helvetica', 'bold');
            doc.setTextColor(71, 85, 105);

            doc.text("Cliente / Razón Social:", marginX + 4, currentY + 7);
            doc.setFont('Helvetica', 'normal');
            doc.setTextColor(15, 23, 42);
            doc.text(`${docTarget.cliente_nombre || docTarget.cliente_id}`, marginX + 45, currentY + 7);

            doc.setFont('Helvetica', 'bold');
            doc.setTextColor(71, 85, 105);
            doc.text("Dirección (EMB):", marginX + 4, currentY + 14);
            doc.setFont('Helvetica', 'normal');
            doc.setTextColor(15, 23, 42);
            const dirTruncated = (docTarget.cliente_direccion || 'Sin dirección').slice(0, 70);
            doc.text(dirTruncated, marginX + 45, currentY + 14);

            doc.setFont('Helvetica', 'bold');
            doc.setTextColor(71, 85, 105);
            doc.text("Chofer Asignado:", marginX + 4, currentY + 21);
            doc.setFont('Helvetica', 'normal');
            doc.setTextColor(15, 23, 42);
            doc.text(`${docTarget.chofer_nombre || 'No asignado'}`, marginX + 45, currentY + 21);

            doc.setFont('Helvetica', 'bold');
            doc.setTextColor(71, 85, 105);
            doc.text("Vehículo / Placa:", marginX + 4, currentY + 28);
            doc.setFont('Helvetica', 'normal');
            doc.setTextColor(15, 23, 42);
            doc.text(`${docTarget.vehiculo_marca || ''} (${docTarget.vehiculo_placa || 'N/A'})`, marginX + 45, currentY + 28);

            doc.setFont('Helvetica', 'bold');
            doc.setTextColor(71, 85, 105);
            doc.text("Vendedor / Creador ERP:", marginX + 4, currentY + 35);
            doc.setFont('Helvetica', 'normal');
            doc.setTextColor(15, 23, 42);
            doc.text(`${docTarget.vendedor || 'N/A'} / ${docTarget.creado_por || 'N/A'}`, marginX + 45, currentY + 35);

            currentY += 44;

            // Timeline Box
            doc.setFont('Helvetica', 'bold');
            doc.setFontSize(10);
            doc.setTextColor(30, 58, 138);
            doc.text("CRONOLOGÍA DE TIEMPOS Y GEOCERCA GPS", marginX, currentY);
            currentY += 5;

            doc.setFillColor(241, 245, 249);
            doc.rect(marginX, currentY, 188, 18, 'F');
            doc.setFontSize(8.5);

            doc.setFont('Helvetica', 'bold');
            doc.setTextColor(37, 99, 235);
            doc.text("1. Arribo Geocerca Bodega", marginX + 4, currentY + 6);
            doc.setFont('Helvetica', 'normal');
            doc.setTextColor(15, 23, 42);
            doc.text(docTarget.hora_ingreso_geocerca ? docTarget.hora_ingreso_geocerca.replace('T', ' ').slice(0, 19) : 'Sin Arribo', marginX + 4, currentY + 12);

            doc.setFont('Helvetica', 'bold');
            doc.setTextColor(16, 185, 129);
            doc.text("2. Entrega Efectiva (Firma)", marginX + 68, currentY + 6);
            doc.setFont('Helvetica', 'normal');
            doc.setTextColor(15, 23, 42);
            doc.text(docTarget.hora_entrega_efectiva ? docTarget.hora_entrega_efectiva.replace('T', ' ').slice(0, 19) : (docTarget.fecha_entrega || 'N/A'), marginX + 68, currentY + 12);

            doc.setFont('Helvetica', 'bold');
            doc.setTextColor(147, 51, 234);
            doc.text("3. Salida de Bodega Cliente", marginX + 132, currentY + 6);
            doc.setFont('Helvetica', 'normal');
            doc.setTextColor(15, 23, 42);
            doc.text(docTarget.hora_salida_geocerca ? docTarget.hora_salida_geocerca.replace('T', ' ').slice(0, 19) : 'En sitio / N/A', marginX + 132, currentY + 12);

            currentY += 24;

            // GPS Box
            if (docTarget.latitud && docTarget.longitud) {
                const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${docTarget.latitud},${docTarget.longitud}`;
                doc.setFillColor(236, 253, 245);
                doc.rect(marginX, currentY, 188, 10, 'F');
                doc.setFont('Helvetica', 'bold');
                doc.setFontSize(8.5);
                doc.setTextColor(4, 120, 87);
                doc.text(`Ubicacion GPS: Lat ${docTarget.latitud}, Lng ${docTarget.longitud} (Abrir en Google Maps)`, marginX + 4, currentY + 6.5);
                doc.link(marginX + 4, currentY + 1, 180, 8, { url: mapsUrl });
                currentY += 14;
            }

            // Comment Box
            if (docTarget.comentario) {
                doc.setFillColor(254, 243, 199);
                doc.rect(marginX, currentY, 188, 12, 'F');
                doc.setFont('Helvetica', 'bold');
                doc.setFontSize(8.5);
                doc.setTextColor(180, 83, 9);
                doc.text("Observacion de Calle:", marginX + 4, currentY + 5);
                doc.setFont('Helvetica', 'italic');
                doc.setTextColor(146, 64, 14);
                doc.text(`"${docTarget.comentario.slice(0, 95)}"`, marginX + 40, currentY + 5);
                currentY += 16;
            }

            // Signature & Receiver Box in PDF
            doc.setFillColor(248, 250, 252);
            doc.rect(marginX, currentY, 188, 30, 'F');
            doc.setDrawColor(203, 213, 225);
            doc.rect(marginX, currentY, 188, 30, 'S');

            doc.setFont('Helvetica', 'bold');
            doc.setFontSize(9);
            doc.setTextColor(30, 58, 138);
            doc.text("FIRMA Y RECEPTOR DE LA ENTREGA", marginX + 4, currentY + 6);

            doc.setFont('Helvetica', 'normal');
            doc.setFontSize(8.5);
            doc.setTextColor(15, 23, 42);
            doc.text(`Recibido Por: ${docTarget.nombre_recibe || 'Sin registrar'}`, marginX + 4, currentY + 14);

            if (docTarget.firma_cliente && docTarget.firma_cliente.startsWith('data:image/')) {
                try {
                    doc.addImage(docTarget.firma_cliente, 'PNG', marginX + 110, currentY + 4, 70, 22);
                } catch (_) {}
            }

            // Footer Notice
            currentY = 250;
            doc.setFont('Helvetica', 'normal');
            doc.setFontSize(8);
            doc.setTextColor(148, 163, 184);
            doc.text(`Documento generado automaticamente por Clic-Tools - Fecha: ${new Date().toLocaleString('es-CR')}`, marginX, currentY);
            doc.text("Este expediente digital sirve como comprobante oficial de entrega y trazabilidad satelital GPS.", marginX, currentY + 4);

            doc.save(`Expediente_Entrega_${docTarget.documento_numero}.pdf`);
            toast({ title: 'PDF Generado', description: `Se descargó el expediente #${docTarget.documento_numero}.pdf` });
        } catch (e: any) {
            toast({ variant: 'destructive', title: 'Error PDF', description: 'No se pudo generar el expediente en PDF.' });
        }
    };

    return (
        <div className="p-6 max-w-7xl mx-auto space-y-6">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b pb-4">
                <div>
                    <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
                        <ShieldCheck className="h-7 w-7 text-indigo-600" />
                        Centro de Auditoría & Evidencias 360°
                    </h1>
                    <p className="text-sm text-muted-foreground">
                        Búsqueda avanzada de entregas, expediente digital de fotos/GPS y exportación a Excel para supervisores.
                    </p>
                </div>
                <div className="flex items-center gap-2">
                    <Button
                        onClick={handleExportExcel}
                        disabled={exporting || results.length === 0}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs gap-1.5"
                    >
                        <Download className="w-4 h-4" />
                        {exporting ? 'Generando Excel...' : 'Exportar a Excel (.csv)'}
                    </Button>
                    <Link
                        href="/dashboard/operations/logistics"
                        className="inline-flex items-center justify-center rounded-md bg-secondary px-3 py-1.5 text-xs font-medium text-secondary-foreground hover:bg-secondary/80"
                    >
                        ⬅ Volver a Logística
                    </Link>
                </div>
            </div>

            {/* Multicriteria Search Form */}
            <Card className="shadow-sm border border-muted">
                <CardHeader className="pb-3">
                    <CardTitle className="text-base font-semibold flex items-center gap-2">
                        <Filter className="w-4 h-4 text-indigo-600" />
                        Filtros de Búsqueda Multicriterio
                    </CardTitle>
                    <CardDescription className="text-xs">
                        Combine cualquier criterio de factura, cliente, chofer, placa o rango de fechas.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                        {/* Factura / Documento */}
                        <div className="space-y-1">
                            <Label className="text-xs font-semibold">Factura / Documento</Label>
                            <Input
                                placeholder="Ej: FAC-84920"
                                value={filters.documentoNumero}
                                onChange={(e) => setFilters(prev => ({ ...prev, documentoNumero: e.target.value }))}
                                className="h-9 text-xs"
                            />
                        </div>

                        {/* Cliente */}
                        <div className="space-y-1">
                            <Label className="text-xs font-semibold">Cliente / Razón Social</Label>
                            <Input
                                placeholder="Ej: El Ángel / Auto Mercado"
                                value={filters.clienteNombre}
                                onChange={(e) => setFilters(prev => ({ ...prev, clienteNombre: e.target.value }))}
                                className="h-9 text-xs"
                            />
                        </div>

                        {/* Chofer */}
                        <div className="space-y-1">
                            <Label className="text-xs font-semibold">Chofer</Label>
                            <Input
                                placeholder="Nombre del chofer"
                                value={filters.choferNombre}
                                onChange={(e) => setFilters(prev => ({ ...prev, choferNombre: e.target.value }))}
                                className="h-9 text-xs"
                            />
                        </div>

                        {/* Placa Camión */}
                        <div className="space-y-1">
                            <Label className="text-xs font-semibold">Placa Vehículo</Label>
                            <Input
                                placeholder="Ej: CL-2231"
                                value={filters.vehiculoPlaca}
                                onChange={(e) => setFilters(prev => ({ ...prev, vehiculoPlaca: e.target.value }))}
                                className="h-9 text-xs font-mono uppercase"
                            />
                        </div>

                        {/* Fecha Desde */}
                        <div className="space-y-1">
                            <Label className="text-xs font-semibold">Fecha Desde</Label>
                            <Input
                                type="date"
                                value={filters.fechaDesde}
                                onChange={(e) => setFilters(prev => ({ ...prev, fechaDesde: e.target.value }))}
                                className="h-9 text-xs"
                            />
                        </div>

                        {/* Fecha Hasta */}
                        <div className="space-y-1">
                            <Label className="text-xs font-semibold">Fecha Hasta</Label>
                            <Input
                                type="date"
                                value={filters.fechaHasta}
                                onChange={(e) => setFilters(prev => ({ ...prev, fechaHasta: e.target.value }))}
                                className="h-9 text-xs"
                            />
                        </div>

                        {/* Estado */}
                        <div className="space-y-1">
                            <Label className="text-xs font-semibold">Estado de Entrega</Label>
                            <Select
                                value={filters.estado}
                                onValueChange={(val) => setFilters(prev => ({ ...prev, estado: val }))}
                            >
                                <SelectTrigger className="h-9 text-xs">
                                    <SelectValue placeholder="Todos los estados" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="todos">Todos los estados</SelectItem>
                                    <SelectItem value="completo">🟢 Completado</SelectItem>
                                    <SelectItem value="incompleto">⚠️ Incompleto / Parcial</SelectItem>
                                    <SelectItem value="rechazado">❌ Rechazado</SelectItem>
                                    <SelectItem value="descartado">🗑️ Descartado</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        {/* Botón Buscar */}
                        <div className="flex items-end">
                            <Button
                                onClick={() => {
                                    setPage(1);
                                    handleSearch(1, pageSize);
                                }}
                                disabled={loading}
                                className="w-full h-9 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs gap-1.5"
                            >
                                {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                                Buscar Entregas
                            </Button>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Results Table Card */}
            <Card className="shadow-sm border border-muted">
                <CardHeader className="pb-3 flex flex-row items-center justify-between">
                    <div>
                        <CardTitle className="text-base font-semibold">Resultados de Auditoría</CardTitle>
                        <CardDescription className="text-xs">
                            Se encontraron <span className="font-bold text-indigo-600">{results.length}</span> registros de entrega coincidentes.
                        </CardDescription>
                    </div>
                </CardHeader>
                <CardContent>
                    {loading ? (
                        <div className="flex items-center justify-center p-12 animate-pulse">
                            <RefreshCw className="w-8 h-8 animate-spin text-indigo-600 mr-3" />
                            <span className="text-sm font-semibold text-muted-foreground">Consultando base de datos de auditoría...</span>
                        </div>
                    ) : !hasSearched ? (
                        <div className="text-center py-12 px-4 space-y-3">
                            <div className="w-12 h-12 rounded-full bg-indigo-50 dark:bg-indigo-950/50 flex items-center justify-center mx-auto text-indigo-600">
                                <Search className="w-6 h-6" />
                            </div>
                            <h3 className="text-sm font-bold text-foreground">Búsqueda de Auditoría bajo demanda</h3>
                            <p className="text-xs text-muted-foreground max-w-md mx-auto">
                                Seleccione el número de documento, cliente, chofer, placa o rango de fechas arriba y presione el botón <strong>&quot;Buscar Entregas&quot;</strong> para cargar los registros.
                            </p>
                        </div>
                    ) : results.length === 0 ? (
                        <div className="text-center py-12 text-sm text-muted-foreground italic">
                            No se encontraron entregas que coincidan con los filtros aplicados.
                        </div>
                    ) : (
                        <>
                            <div className="overflow-x-auto">
                                <table className="w-full text-left text-xs">
                                    <thead>
                                        <tr className="border-b bg-muted/50 font-semibold uppercase text-muted-foreground">
                                            <th className="py-2.5 px-3">Documento</th>
                                            <th className="py-2.5 px-3">Estado</th>
                                            <th className="py-2.5 px-3">Cliente</th>
                                            <th className="py-2.5 px-3">Chofer / Camión</th>
                                            <th className="py-2.5 px-3">Fecha / Arribo</th>
                                            <th className="py-2.5 px-3 text-center">Tiempos</th>
                                            <th className="py-2.5 px-3">Nota Chofer</th>
                                            <th className="py-2.5 px-3 text-center">Evidencias</th>
                                            <th className="py-2.5 px-3 text-right">Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {results.map((doc) => (
                                            <tr key={doc.id} className="border-b hover:bg-muted/30 transition-colors">
                                                <td className="py-2.5 px-3 font-mono font-bold text-foreground">
                                                    {doc.documento_numero}
                                                </td>
                                                <td className="py-2.5 px-3">
                                                    {doc.estado === 'completo' && <Badge variant="default" className="bg-emerald-500 text-white">🟢 Completado</Badge>}
                                                    {doc.estado === 'incompleto' && <Badge variant="default" className="bg-amber-500 text-white">⚠️ Incompleto</Badge>}
                                                    {doc.estado === 'rechazado' && <Badge variant="destructive">❌ Rechazado</Badge>}
                                                    {doc.estado === 'descartado' && <Badge variant="outline" className="text-gray-500">🗑️ Descartado</Badge>}
                                                    {doc.estado === 'pendiente' && <Badge variant="outline" className="text-blue-500">⏳ Pendiente</Badge>}
                                                </td>
                                                <td className="py-2.5 px-3 font-medium">
                                                    <div>{doc.cliente_nombre || doc.cliente_id}</div>
                                                    <div className="text-[10px] text-muted-foreground truncate max-w-[180px]">{doc.cliente_direccion || 'Sin dirección'}</div>
                                                </td>
                                                <td className="py-2.5 px-3">
                                                    <div className="font-semibold">{doc.chofer_nombre || 'No asignado'}</div>
                                                    <div className="text-[10px] text-muted-foreground font-mono">{doc.vehiculo_placa ? `${doc.vehiculo_marca || ''} (${doc.vehiculo_placa})` : '--'}</div>
                                                </td>
                                                <td className="py-2.5 px-3">
                                                    <div>{doc.fecha_registro ? doc.fecha_registro.split('T')[0] : '--'}</div>
                                                    <div className="text-[10px] text-blue-600 font-semibold">{doc.hora_ingreso_geocerca ? `Arribo: ${doc.hora_ingreso_geocerca.split('T')[1]?.slice(0,5)}` : 'Sin Arribo'}</div>
                                                </td>
                                                <td className="py-2.5 px-3 text-center font-mono text-[11px]">
                                                    {doc.tiempo_descarga_min ? (
                                                        <span className="font-bold text-blue-600">{doc.tiempo_descarga_min} min</span>
                                                    ) : (
                                                        <span className="text-muted-foreground">--</span>
                                                    )}
                                                </td>
                                                <td className="py-2.5 px-3 max-w-[200px]">
                                                    {doc.comentario ? (
                                                        <div className="text-[11px] text-slate-700 font-medium truncate" title={doc.comentario}>
                                                            💬 {doc.comentario}
                                                        </div>
                                                    ) : (
                                                        <span className="text-[10px] text-slate-400 italic">Sin comentarios</span>
                                                    )}
                                                </td>
                                                <td className="py-2.5 px-3 text-center">
                                                     <div className="flex items-center justify-center gap-1 flex-wrap">
                                                         {doc.firma_cliente && (
                                                             <button
                                                                 type="button"
                                                                 onClick={() => setSelectedPhoto({
                                                                     url: doc.firma_cliente.startsWith('http') || doc.firma_cliente.startsWith('data:') ? doc.firma_cliente : `/api/fleet/files/${doc.firma_cliente}`,
                                                                     title: `Firma Digital - Documento #${doc.documento_numero}`
                                                                 })}
                                                             >
                                                                 <Badge variant="outline" className="text-[10px] bg-emerald-50 text-emerald-700 border-emerald-200 cursor-pointer hover:bg-emerald-100 transition-colors">✍️ Firma</Badge>
                                                             </button>
                                                         )}
                                                         {doc.foto_factura && (
                                                             <button
                                                                 type="button"
                                                                 onClick={() => setSelectedPhoto({
                                                                     url: doc.foto_factura.startsWith('http') || doc.foto_factura.startsWith('data:') ? doc.foto_factura : `/api/fleet/files/${doc.foto_factura}`,
                                                                     title: `Foto Factura - Documento #${doc.documento_numero}`
                                                                 })}
                                                             >
                                                                 <Badge variant="outline" className="text-[10px] bg-blue-50 text-blue-600 border-blue-200 cursor-pointer hover:bg-blue-100 transition-colors">📷 Factura</Badge>
                                                             </button>
                                                         )}
                                                         {doc.foto_evidencia && (
                                                             <button
                                                                 type="button"
                                                                 onClick={() => setSelectedPhoto({
                                                                     url: doc.foto_evidencia.startsWith('http') || doc.foto_evidencia.startsWith('data:') ? doc.foto_evidencia : `/api/fleet/files/${doc.foto_evidencia}`,
                                                                     title: `Foto Paquetes - Documento #${doc.documento_numero}`
                                                                 })}
                                                             >
                                                                 <Badge variant="outline" className="text-[10px] bg-purple-50 text-purple-600 border-purple-200 cursor-pointer hover:bg-purple-100 transition-colors">📦 Cajas</Badge>
                                                             </button>
                                                         )}
                                                         {!doc.firma_cliente && !doc.foto_factura && !doc.foto_evidencia && (
                                                             <span className="text-muted-foreground text-[10px] italic">Sin foto</span>
                                                         )}
                                                     </div>
                                                </td>
                                                <td className="py-2.5 px-3 text-right">
                                                    <Button
                                                        size="sm"
                                                        variant="outline"
                                                        onClick={() => handleOpenExpediente(doc)}
                                                        className="h-7 text-[11px] font-semibold gap-1 text-indigo-600 border-indigo-200 hover:bg-indigo-50"
                                                    >
                                                        <FileText className="w-3 h-3" />
                                                        Expediente 360°
                                                    </Button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>

                            {/* Pagination Footer Bar */}
                            <div className="pt-4 border-t flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
                                <div className="text-muted-foreground">
                                    Mostrando <span className="font-bold text-foreground">{results.length}</span> de <span className="font-bold text-foreground">{totalCount}</span> registros. (Página <span className="font-bold text-indigo-600">{page}</span> de <span className="font-bold text-indigo-600">{totalPages}</span>)
                                </div>

                                <div className="flex items-center gap-3">
                                    <div className="flex items-center gap-1">
                                        <span className="text-muted-foreground font-medium">Items por página:</span>
                                        <Select value={String(pageSize)} onValueChange={(val) => { setPageSize(Number(val)); setPage(1); }}>
                                            <SelectTrigger className="h-8 w-16 text-xs font-bold">
                                                <SelectValue placeholder="25" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="10">10</SelectItem>
                                                <SelectItem value="25">25</SelectItem>
                                                <SelectItem value="50">50</SelectItem>
                                                <SelectItem value="100">100</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    <div className="flex items-center gap-1">
                                        <Button
                                            variant="outline"
                                            size="sm"
                                            disabled={page <= 1 || loading}
                                            onClick={() => setPage(p => Math.max(p - 1, 1))}
                                            className="h-8 text-xs font-bold"
                                        >
                                            ◀ Anterior
                                        </Button>
                                        <Button
                                            variant="outline"
                                            size="sm"
                                            disabled={page >= totalPages || loading}
                                            onClick={() => setPage(p => Math.min(p + 1, totalPages))}
                                            className="h-8 text-xs font-bold"
                                        >
                                            Siguiente ▶
                                        </Button>
                                    </div>
                                </div>
                            </div>
                        </>
                    )}
                </CardContent>
            </Card>

            {/* Expediente 360° Modal */}
            <Dialog open={expedienteOpen} onOpenChange={setExpedienteOpen}>
                <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
                    {selectedDoc && (
                        <div className="space-y-6">
                            <DialogHeader>
                                <DialogTitle className="text-xl font-bold flex items-center justify-between">
                                    <span className="flex items-center gap-2">
                                        <ShieldCheck className="w-6 h-6 text-indigo-600" />
                                        Expediente de Entrega: #{selectedDoc.documento_numero}
                                    </span>
                                    <Badge variant={selectedDoc.estado === 'completo' ? 'default' : 'destructive'}>
                                        {selectedDoc.estado.toUpperCase()}
                                    </Badge>
                                </DialogTitle>
                                <DialogDescription className="text-xs">
                                    Expediente completo de trazabilidad, evidencias fotográficas, timestamps de geocerca y coordenadas de entrega.
                                </DialogDescription>
                            </DialogHeader>

                            {/* Section 1: Data Summary */}
                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-muted/40 p-3 rounded-xl border text-xs">
                                <div>
                                    <span className="text-muted-foreground font-semibold block">Cliente:</span>
                                    <span className="font-bold text-foreground">{selectedDoc.cliente_nombre || selectedDoc.cliente_id}</span>
                                </div>
                                <div>
                                    <span className="text-muted-foreground font-semibold block">Chofer:</span>
                                    <span className="font-bold text-foreground">{selectedDoc.chofer_nombre || 'No asignado'}</span>
                                </div>
                                <div>
                                    <span className="text-muted-foreground font-semibold block">Vehículo / Placa:</span>
                                    <span className="font-bold text-foreground font-mono">{selectedDoc.vehiculo_placa || 'N/A'}</span>
                                </div>
                                <div>
                                    <span className="text-muted-foreground font-semibold block">Ruta:</span>
                                    <span className="font-bold text-foreground">{selectedDoc.ruta_nombre || 'N/A'}</span>
                                </div>
                                <div>
                                    <span className="text-muted-foreground font-semibold block">Vendedor ERP:</span>
                                    <span className="font-bold text-foreground">{selectedDoc.vendedor || 'N/A'}</span>
                                </div>
                                <div>
                                    <span className="text-muted-foreground font-semibold block">Creador ERP:</span>
                                    <span className="font-bold text-foreground">{selectedDoc.creado_por || 'N/A'}</span>
                                </div>
                                {selectedDoc.nombre_recibe && (
                                    <div className="col-span-2 sm:col-span-3 bg-indigo-50/50 dark:bg-indigo-950/20 p-2 rounded-lg border border-indigo-100 dark:border-indigo-900">
                                        <span className="text-indigo-600 font-semibold block text-[10px] uppercase tracking-wider">✍️ Persona que Recibe en Destino:</span>
                                        <span className="font-extrabold text-sm text-indigo-950 dark:text-indigo-200">{selectedDoc.nombre_recibe}</span>
                                    </div>
                                )}
                            </div>

                            {/* Section 2: Timestamps Timeline */}
                            <div className="space-y-2 border-l-2 border-indigo-500 pl-4 py-1 text-xs">
                                <h4 className="font-bold uppercase tracking-wider text-indigo-600 text-[11px]">⏱️ Cronología de Atención en Bodega Cliente</h4>
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                                    <div className="bg-blue-50 dark:bg-blue-950/30 p-2 rounded-lg border border-blue-200">
                                        <span className="text-blue-600 font-semibold block text-[10px]">1. Arribo a Geocerca</span>
                                        <span className="font-bold">{selectedDoc.hora_ingreso_geocerca ? selectedDoc.hora_ingreso_geocerca.replace('T', ' ').slice(0, 19) : 'No capturado'}</span>
                                    </div>
                                    <div className="bg-emerald-50 dark:bg-emerald-950/30 p-2 rounded-lg border border-emerald-200">
                                        <span className="text-emerald-600 font-semibold block text-[10px]">2. Entrega Efectiva (Firma)</span>
                                        <span className="font-bold">{selectedDoc.hora_entrega_efectiva ? selectedDoc.hora_entrega_efectiva.replace('T', ' ').slice(0, 19) : selectedDoc.fecha_entrega || 'N/A'}</span>
                                        {selectedDoc.tiempo_descarga_min && <span className="text-[10px] text-emerald-700 block mt-0.5">⏱️ Descarga: {selectedDoc.tiempo_descarga_min} min</span>}
                                    </div>
                                    <div className="bg-purple-50 dark:bg-purple-950/30 p-2 rounded-lg border border-purple-200">
                                        <span className="text-purple-600 font-semibold block text-[10px]">3. Salida de Bodega</span>
                                        <span className="font-bold">{selectedDoc.hora_salida_geocerca ? selectedDoc.hora_salida_geocerca.replace('T', ' ').slice(0, 19) : 'En sitio / N/A'}</span>
                                    </div>
                                </div>
                            </div>

                            {/* Section 3: GPS Coordinates & Maps */}
                            {selectedDoc.latitud && selectedDoc.longitud && (
                                <div className="flex items-center justify-between bg-emerald-50 text-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-200 p-3 rounded-xl border border-emerald-200 text-xs">
                                    <div className="flex items-center gap-2">
                                        <MapPin className="w-5 h-5 text-emerald-600" />
                                        <div>
                                            <span className="font-bold block">Ubicación GPS de Descarga Confirmada:</span>
                                            <span className="font-mono text-[11px]">{selectedDoc.latitud}, {selectedDoc.longitud}</span>
                                        </div>
                                    </div>
                                    <a
                                        href={`https://www.google.com/maps/search/?api=1&query=${selectedDoc.latitud},${selectedDoc.longitud}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="inline-flex items-center gap-1 font-bold text-emerald-700 hover:underline text-xs"
                                    >
                                        Abrir en Google Maps <ExternalLink className="w-3.5 h-3.5" />
                                    </a>
                                </div>
                            )}

                            {/* Section 4: Comment / Calle Notes */}
                            {selectedDoc.comentario && (
                                <div className="bg-amber-50 dark:bg-amber-950/30 p-3 rounded-xl border border-amber-200 text-xs">
                                    <span className="font-bold text-amber-800 dark:text-amber-300 block mb-1">💬 Observación o Comentario de Calle:</span>
                                    <p className="italic text-amber-900 dark:text-amber-100">&quot;{selectedDoc.comentario}&quot;</p>
                                </div>
                            )}

                            {/* Section 5: Photos Evidence */}
                            <div className="space-y-2">
                                <h4 className="font-bold text-xs flex items-center gap-2">
                                    <Camera className="w-4 h-4 text-indigo-600" />
                                    Evidencias Fotográficas Adjuntas
                                </h4>
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                                    {selectedDoc.firma_cliente ? (
                                        <div className="space-y-1">
                                            <span className="text-[11px] font-semibold text-muted-foreground block">✍️ Firma Digital del Cliente:</span>
                                            <div className="bg-white p-2 rounded-xl border shadow-sm h-48 flex items-center justify-center">
                                                <Image
                                                    src={selectedDoc.firma_cliente.startsWith('http') || selectedDoc.firma_cliente.startsWith('data:') ? selectedDoc.firma_cliente : `/api/fleet/files/${selectedDoc.firma_cliente}`}
                                                    alt="Firma Digital"
                                                    width={300}
                                                    height={150}
                                                    unoptimized
                                                    className="max-h-full max-w-full object-contain"
                                                />
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="h-48 bg-muted/30 border border-dashed rounded-xl flex items-center justify-center text-xs text-muted-foreground italic">
                                            Sin firma digital en pantalla.
                                        </div>
                                    )}

                                    {selectedDoc.foto_factura ? (
                                        <div className="space-y-1">
                                            <span className="text-[11px] font-semibold text-muted-foreground block">📄 Factura Firmada / Comprobante:</span>
                                            <Image
                                                src={selectedDoc.foto_factura.startsWith('http') || selectedDoc.foto_factura.startsWith('data:') ? selectedDoc.foto_factura : `/api/fleet/files/${selectedDoc.foto_factura}`}
                                                alt="Foto Factura"
                                                width={400}
                                                height={200}
                                                unoptimized
                                                className="w-full h-48 object-cover rounded-xl border shadow-sm"
                                            />
                                        </div>
                                    ) : (
                                        <div className="h-48 bg-muted/30 border border-dashed rounded-xl flex items-center justify-center text-xs text-muted-foreground italic">
                                            Sin foto de factura firmada.
                                        </div>
                                    )}

                                    {selectedDoc.foto_evidencia ? (
                                        <div className="space-y-1">
                                            <span className="text-[11px] font-semibold text-muted-foreground block">📦 Mercadería Descargada / Paquetes:</span>
                                            <Image
                                                src={selectedDoc.foto_evidencia.startsWith('http') || selectedDoc.foto_evidencia.startsWith('data:') ? selectedDoc.foto_evidencia : `/api/fleet/files/${selectedDoc.foto_evidencia}`}
                                                alt="Foto Mercadería"
                                                width={400}
                                                height={200}
                                                unoptimized
                                                className="w-full h-48 object-cover rounded-xl border shadow-sm"
                                            />
                                        </div>
                                    ) : (
                                        <div className="h-48 bg-muted/30 border border-dashed rounded-xl flex items-center justify-center text-xs text-muted-foreground italic">
                                            Sin foto de mercadería.
                                        </div>
                                    )}
                                </div>
                            </div>

                            <DialogFooter className="pt-4 border-t flex-wrap gap-2 justify-between">
                                <div className="flex items-center gap-2 flex-wrap">
                                    <Button
                                        variant="outline"
                                        onClick={() => handlePrintThermalReceipt(selectedDoc.id)}
                                        className="gap-1.5 text-xs text-amber-800 border-amber-300 hover:bg-amber-50 font-semibold"
                                    >
                                        <Printer className="w-4 h-4 text-amber-600" /> Reimprimir Boleta Térmica (80mm)
                                    </Button>
                                    <Button
                                        variant="outline"
                                        onClick={() => {
                                            setEmailModalDoc(selectedDoc);
                                            setTargetEmail('');
                                        }}
                                        className="gap-1.5 text-xs text-blue-700 border-blue-200 hover:bg-blue-50 font-semibold"
                                    >
                                        <FileText className="w-4 h-4 text-blue-600" /> Reenviar por Correo
                                    </Button>
                                    <Button
                                        variant="outline"
                                        onClick={() => handleDownloadExpedientePdf(selectedDoc)}
                                        className="gap-1.5 text-xs text-indigo-700 border-indigo-200 hover:bg-indigo-50 font-semibold"
                                    >
                                        <Download className="w-4 h-4 text-indigo-600" /> Descargar PDF Carta con Firma
                                    </Button>
                                </div>
                                <Button onClick={() => setExpedienteOpen(false)} className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold">
                                    Cerrar Expediente
                                </Button>
                            </DialogFooter>
                        </div>
                    )}
                </DialogContent>
            </Dialog>

            {/* Thermal Print Modal */}
            <Dialog open={thermalOpen} onOpenChange={setThermalOpen}>
                <DialogContent className="max-w-md max-h-[85vh] overflow-y-auto">
                    <DialogHeader>
                        <DialogTitle className="text-base font-bold flex items-center gap-2">
                            <Printer className="w-5 h-5 text-amber-600" /> Reimprimir Boleta de Entrega
                        </DialogTitle>
                        <DialogDescription className="text-xs">
                            Vista previa del formato térmico oficial con firma digital del cliente y productos.
                        </DialogDescription>
                    </DialogHeader>

                    {thermalHtml && (
                        <div 
                            className="bg-white p-4 border rounded-xl shadow-inner text-black font-mono text-xs overflow-x-auto my-2 border-slate-300"
                            dangerouslySetInnerHTML={{ __html: thermalHtml }}
                        />
                    )}

                    <DialogFooter className="pt-2">
                        <Button 
                            onClick={() => {
                                const printWindow = window.open('', '_blank');
                                if (printWindow && thermalHtml) {
                                    printWindow.document.write(`
                                        <html>
                                            <head>
                                                <title>Boleta de Entrega</title>
                                                <style>
                                                    body { font-family: monospace; padding: 10px; margin: 0; }
                                                    @media print { body { width: 80mm; } }
                                                </style>
                                            </head>
                                            <body>${thermalHtml}</body>
                                        </html>
                                    `);
                                    printWindow.document.close();
                                    printWindow.focus();
                                    setTimeout(() => printWindow.print(), 300);
                                }
                            }} 
                            className="w-full bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs gap-2"
                        >
                            <Printer className="w-4 h-4" /> Mandar a Imprimir
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Send Email Modal */}
            <Dialog open={!!emailModalDoc} onOpenChange={(open) => { if (!open) setEmailModalDoc(null); }}>
                <DialogContent className="max-w-sm">
                    <DialogHeader>
                        <DialogTitle className="text-base font-bold flex items-center gap-2">
                            <FileText className="w-5 h-5 text-blue-600" /> Reenviar Boleta por Correo
                        </DialogTitle>
                        <DialogDescription className="text-xs">
                            Indica el correo electrónico del cliente para transmitir el comprobante oficial con la firma.
                        </DialogDescription>
                    </DialogHeader>

                    <div className="space-y-3 py-2">
                        <Label htmlFor="auditTargetEmail" className="text-xs font-semibold">Correo Electrónico Destino:</Label>
                        <Input
                            id="auditTargetEmail"
                            type="email"
                            placeholder="ejemplo@cliente.com"
                            value={targetEmail}
                            onChange={(e) => setTargetEmail(e.target.value)}
                            className="h-10 text-xs"
                        />
                    </div>

                    <DialogFooter>
                        <Button
                            variant="outline"
                            onClick={() => setEmailModalDoc(null)}
                            disabled={sendingEmail}
                            className="text-xs"
                        >
                            Cancelar
                        </Button>
                        <Button
                            onClick={handleSendEmailSubmit}
                            disabled={sendingEmail || !targetEmail.trim()}
                            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs gap-1.5"
                        >
                            {sendingEmail ? 'Enviando...' : 'Enviar Correo'}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* High-Resolution Evidence Photo Viewer Modal */}
            <EvidencePhotoViewer
                selectedPhoto={selectedPhoto}
                onClose={() => setSelectedPhoto(null)}
            />
        </div>
    );
}
