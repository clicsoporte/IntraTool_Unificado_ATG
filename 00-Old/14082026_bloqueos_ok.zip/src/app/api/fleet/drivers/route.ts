import { NextResponse } from 'next/server';
import { getDb } from '@/modules/core/lib/db';

export async function GET() {
  try {
    const db = await getDb();
    const rows = db.prepare(`
      SELECT id, name, employeeId 
      FROM core_users 
      WHERE employeeId IN (
        SELECT value FROM fleet_settings WHERE category = 'driver'
      )
      ORDER BY name ASC
    `).all();

    return NextResponse.json({
      success: true,
      drivers: rows
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
