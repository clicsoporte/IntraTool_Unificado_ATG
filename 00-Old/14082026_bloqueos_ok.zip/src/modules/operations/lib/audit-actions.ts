'use server';

import { getDb } from '@/modules/core/lib/db';
import { getCurrentUser } from '@/modules/core/lib/auth';
import { authorizeAction } from '@/modules/core/lib/auth-guard';
import { logInfo, logError } from '@/modules/core/lib/logger';

export interface AuditFilterParams {
    documentoNumero?: string;
    fechaDesde?: string;
    fechaHasta?: string;
    clienteNombre?: string;
    choferNombre?: string;
    vehiculoPlaca?: string;
    estado?: string;
    searchTerm?: string;
    page?: number;
    pageSize?: number;
}

export async function searchDeliveryAuditLogs(filters: AuditFilterParams): Promise<{ success: boolean; data?: any[]; totalCount?: number; totalPages?: number; page?: number; pageSize?: number; error?: string }> {
    const user = await getCurrentUser();
    if (!user) {
        return { success: false, error: 'Usuario no autenticado.' };
    }

    const db = await getDb();
    try {
        let whereSql = ` WHERE 1=1`;
        const params: any[] = [];

        // Scoping check for sales/creators if user does NOT have global audit permission
        const hasGlobalAudit = user.role === 'admin' || user.role === 'superadmin' || user.role === 'logistics_manager';
        if (!hasGlobalAudit && (user.erpAlias || user.salespersonId)) {
            whereSql += ` AND (q.creado_por = ? OR h.VENDEDOR = ?)`;
            params.push(user.erpAlias || '', user.salespersonId || '');
        }

        if (filters.documentoNumero && filters.documentoNumero.trim() !== '') {
            whereSql += ` AND q.documento_numero LIKE ?`;
            params.push(`%${filters.documentoNumero.trim()}%`);
        }

        if (filters.fechaDesde && filters.fechaDesde.trim() !== '') {
            whereSql += ` AND q.fecha_registro >= ?`;
            params.push(filters.fechaDesde.trim());
        }

        if (filters.fechaHasta && filters.fechaHasta.trim() !== '') {
            whereSql += ` AND q.fecha_registro <= ?`;
            params.push(`${filters.fechaHasta.trim()}T23:59:59`);
        }

        if (filters.clienteNombre && filters.clienteNombre.trim() !== '') {
            whereSql += ` AND (q.cliente_nombre LIKE ? OR q.cliente_id LIKE ? OR c.name LIKE ?)`;
            const term = `%${filters.clienteNombre.trim()}%`;
            params.push(term, term, term);
        }

        if (filters.choferNombre && filters.choferNombre.trim() !== '') {
            whereSql += ` AND u.name LIKE ?`;
            params.push(`%${filters.choferNombre.trim()}%`);
        }

        if (filters.vehiculoPlaca && filters.vehiculoPlaca.trim() !== '') {
            whereSql += ` AND v.plate LIKE ?`;
            params.push(`%${filters.vehiculoPlaca.trim()}%`);
        }

        if (filters.estado && filters.estado.trim() !== '' && filters.estado !== 'todos') {
            whereSql += ` AND q.estado = ?`;
            params.push(filters.estado.trim());
        }

        if (filters.searchTerm && filters.searchTerm.trim() !== '') {
            whereSql += ` AND (q.documento_numero LIKE ? OR q.cliente_nombre LIKE ? OR q.comentario LIKE ?)`;
            const term = `%${filters.searchTerm.trim()}%`;
            params.push(term, term, term);
        }

        // Count Total Records
        const countSql = `
            SELECT COUNT(*) as count 
            FROM ops_delivery_queue q
            LEFT JOIN core_erp_invoice_headers h ON q.documento_numero = h.FACTURA
            LEFT JOIN ops_delivery_assignments a ON (q.asignacion_id = a.id OR q.devolucion_asignacion_id = a.id)
            LEFT JOIN ops_delivery_routes r ON a.ruta_id = r.id
            LEFT JOIN core_users u ON a.empleado_id = u.id
            LEFT JOIN fleet_vehicles v ON a.vehiculo_id = v.id
            LEFT JOIN core_customers c ON q.cliente_id = c.id
            ${whereSql}
        `;
        const countRow = db.prepare(countSql).get(...params) as { count: number };
        const totalCount = countRow?.count || 0;

        let query = `
            SELECT 
                q.id,
                q.documento_numero,
                q.tipo_documento,
                q.cliente_id,
                q.cliente_nombre,
                q.creado_por,
                COALESCE(h.VENDEDOR, q.creado_por) as vendedor,
                q.fecha_registro,
                q.fecha_entrega,
                q.estado,
                q.comentario,
                q.foto_evidencia,
                q.foto_factura,
                q.latitud,
                q.longitud,
                q.hora_ingreso_geocerca,
                q.hora_entrega_efectiva,
                q.hora_salida_geocerca,
                q.tiempo_descarga_min,
                q.tiempo_espera_post_entrega_min,
                q.tiempo_total_permanencia_min,
                a.fecha as asignacion_fecha,
                r.name as ruta_nombre,
                u.name as chofer_nombre,
                v.plate as vehiculo_placa,
                v.brand as vehiculo_marca,
                v.model as vehiculo_modelo,
                c.phone as cliente_telefono,
                c.address as cliente_direccion,
                h.EMBARCAR_A as direccion_embarque_erp,
                h.DIREC_EMBARQUE as direccion_factura_erp
            FROM ops_delivery_queue q
            LEFT JOIN core_erp_invoice_headers h ON q.documento_numero = h.FACTURA
            LEFT JOIN ops_delivery_assignments a ON (q.asignacion_id = a.id OR q.devolucion_asignacion_id = a.id)
            LEFT JOIN ops_delivery_routes r ON a.ruta_id = r.id
            LEFT JOIN core_users u ON a.empleado_id = u.id
            LEFT JOIN fleet_vehicles v ON a.vehiculo_id = v.id
            LEFT JOIN core_customers c ON q.cliente_id = c.id
            ${whereSql}
            ORDER BY q.id DESC
        `;

        const curPage = filters.page || 1;
        const curSize = filters.pageSize || 25;
        const limit = Number(curSize);
        const offset = (Number(curPage) - 1) * limit;

        query += ` LIMIT ? OFFSET ?`;
        const pageParams = [...params, limit, offset];

        const rawRows = db.prepare(query).all(...pageParams);
        const rows = JSON.parse(JSON.stringify(rawRows));
        const totalPages = Math.ceil(totalCount / limit) || 1;

        return { success: true, data: rows, totalCount, totalPages, page: curPage, pageSize: curSize };
    } catch (e: any) {
        logError('Error in searchDeliveryAuditLogs:', e.message);
        return { success: false, error: e.message };
    }
}

export async function exportDeliveryAuditLogsToCsv(filters: AuditFilterParams): Promise<{ success: boolean; csvContent?: string; filename?: string; error?: string }> {
    // Export up to 10,000 matching records without pagination truncation
    const res = await searchDeliveryAuditLogs({ ...filters, page: 1, pageSize: 10000 });
    if (!res.success || !res.data) {
        return { success: false, error: res.error || 'Error al obtener datos para exportación.' };
    }

    try {
        const headers = [
            'Documento',
            'Tipo Documento',
            'Estado',
            'Cliente ID',
            'Nombre Cliente',
            'Chofer',
            'Vehiculo / Placa',
            'Ruta',
            'Vendedor ERP',
            'Creador ERP',
            'Fecha Registro',
            'Hora Arribo Bodega',
            'Hora Entrega Efectiva',
            'Hora Salida Bodega',
            'Minutos Descarga',
            'Minutos Espera',
            'Minutos Permanencia Total',
            'Evidencias (Fotos)',
            'Tiene Foto Factura',
            'Tiene Foto Paquetes',
            'Observacion o Comentario de Calle',
            'Direccion Embarque (EMB)',
            'Coordenadas Lat/Lng'
        ];

        const csvLines = [headers.join(',')];

        res.data.forEach(item => {
            const hasPhotos = item.foto_factura || item.foto_evidencia ? 'Si' : 'No';
            const vehiculoStr = item.vehiculo_placa ? `${item.vehiculo_marca || ''} (${item.vehiculo_placa})` : '';
            const direccionStr = item.direccion_embarque_erp || item.cliente_direccion || item.direccion_factura_erp || '';

            const row = [
                `"${(item.documento_numero || '').replace(/"/g, '""')}"`,
                `"${(item.tipo_documento || '').replace(/"/g, '""')}"`,
                `"${(item.estado || '').replace(/"/g, '""')}"`,
                `"${(item.cliente_id || '').replace(/"/g, '""')}"`,
                `"${(item.cliente_nombre || '').replace(/"/g, '""')}"`,
                `"${(item.chofer_nombre || 'No asignado').replace(/"/g, '""')}"`,
                `"${vehiculoStr.replace(/"/g, '""')}"`,
                `"${(item.ruta_nombre || '').replace(/"/g, '""')}"`,
                `"${(item.vendedor || '').replace(/"/g, '""')}"`,
                `"${(item.creado_por || '').replace(/"/g, '""')}"`,
                `"${(item.fecha_registro || '').replace(/"/g, '""')}"`,
                `"${(item.hora_ingreso_geocerca || '').replace(/"/g, '""')}"`,
                `"${(item.hora_entrega_efectiva || item.fecha_entrega || '').replace(/"/g, '""')}"`,
                `"${(item.hora_salida_geocerca || '').replace(/"/g, '""')}"`,
                `"${item.tiempo_descarga_min || 0}"`,
                `"${item.tiempo_espera_post_entrega_min || 0}"`,
                `"${item.tiempo_total_permanencia_min || 0}"`,
                `"${hasPhotos}"`,
                `"${item.foto_factura ? 'Si' : 'No'}"`,
                `"${item.foto_evidencia ? 'Si' : 'No'}"`,
                `"${(item.comentario || '').replace(/"/g, '""')}"`,
                `"${direccionStr.replace(/"/g, '""')}"`,
                `"${item.latitud && item.longitud ? `${item.latitud},${item.longitud}` : ''}"`
            ];
            csvLines.push(row.join(','));
        });

        const csvContent = '\uFEFF' + csvLines.join('\n'); // Add UTF-8 BOM for Excel
        const dateStr = new Date().toISOString().split('T')[0];
        const filename = `Reporte_Auditoria_Entregas_${dateStr}.csv`;

        logInfo(`Exportado reporte de auditoría de entregas a CSV: ${res.data.length} registros`);
        return { success: true, csvContent, filename };
    } catch (e: any) {
        logError('Error generating CSV export:', e.message);
        return { success: false, error: e.message };
    }
}
