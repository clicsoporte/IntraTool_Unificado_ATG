
'use client';

import React from 'react';
import { useConsignmentsAgreements } from '@/modules/consignments/hooks/useConsignmentsAgreements';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { PlusCircle, Edit2, Loader2, Trash2, Settings2, Users } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { SearchInput } from '@/components/ui/search-input';
import { ConsignmentAgreement, ConsignmentProduct } from '@/modules/core/types';
import { usePageTitle } from '@/modules/core/hooks/usePageTitle';
import { Skeleton } from '@/components/ui/skeleton';
import { ScrollArea } from '@/components/ui/scroll-area';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { MultiSelectFilter } from '@/components/ui/multi-select-filter';
import { Separator } from '@/components/ui/separator';

export default function AgreementsPage() {
    const { state, actions, selectors } = useConsignmentsAgreements();
    usePageTitle().setTitle('Acuerdos de Consignación');

    if (state.isLoading) {
        return (
             <main className="flex-1 p-4 md:p-6 lg:p-8">
                <Skeleton className="h-96 w-full max-w-5xl mx-auto" />
            </main>
        )
    }

    return (
        <main className="flex-1 p-4 md:p-6 lg:p-8">
            <Card className="max-w-5xl mx-auto">
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <div>
                            <CardTitle>Acuerdos de Consignación</CardTitle>
                            <CardDescription>
                                Define los clientes, bodegas, productos y stocks máximos para cada consignación.
                            </CardDescription>
                        </div>
                        {selectors.hasPermission('consignments:setup') && (
                            <Button onClick={() => actions.openAgreementForm()}>
                                <PlusCircle className="mr-2 h-4 w-4" /> Nuevo Acuerdo
                            </Button>
                        )}
                    </div>
                    <div className="flex items-center space-x-2 pt-4">
                        <Switch
                            id="active-filter"
                            checked={state.showOnlyActiveAgreements}
                            onCheckedChange={actions.setShowOnlyActiveAgreements}
                        />
                        <Label htmlFor="active-filter">Mostrar solo acuerdos activos</Label>
                    </div>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Cliente</TableHead>
                                <TableHead>Bodega ERP</TableHead>
                                <TableHead>Productos</TableHead>
                                <TableHead>Estado</TableHead>
                                <TableHead className="text-right">Acciones</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {selectors.filteredAgreements.map((agreement) => (
                                <TableRow key={agreement.id}>
                                    <TableCell className="font-medium">{agreement.client_name}</TableCell>
                                    <TableCell>{agreement.erp_warehouse_id}</TableCell>
                                    <TableCell>{agreement.product_count || 0}</TableCell>
                                    <TableCell>
                                        <Switch
                                            checked={agreement.is_active === 1}
                                            onCheckedChange={(checked) => actions.toggleAgreementStatus(agreement.id, checked)}
                                            disabled={!selectors.hasPermission('consignments:setup')}
                                        />
                                    </TableCell>
                                    <TableCell className="text-right">
                                        <Button variant="ghost" size="icon" onClick={() => actions.openAgreementForm(agreement)} disabled={!selectors.hasPermission('consignments:setup')}>
                                            <Edit2 className="h-4 w-4" />
                                        </Button>
                                         <AlertDialog open={state.agreementToDelete?.id === agreement.id} onOpenChange={(open) => !open && actions.setAgreementToDelete(null)}>
                                            <AlertDialogTrigger asChild>
                                                <Button variant="ghost" size="icon" disabled={!selectors.hasPermission('consignments:setup')} onClick={() => actions.setAgreementToDelete(agreement)}>
                                                    <Trash2 className="h-4 w-4 text-destructive" />
                                                </Button>
                                            </AlertDialogTrigger>
                                            <AlertDialogContent>
                                                <AlertDialogHeader>
                                                    <AlertDialogTitle>¿Confirmar eliminación?</AlertDialogTitle>
                                                    <AlertDialogDescription>
                                                        {state.agreementToDelete?.boleta_count && state.agreementToDelete.boleta_count > 0 
                                                            ? `No se puede eliminar. El acuerdo tiene ${state.agreementToDelete.boleta_count} boleta(s) asociada(s). Por favor, elimínelas primero.`
                                                            : `Esta acción eliminará permanentemente el acuerdo para ${state.agreementToDelete?.client_name}.`
                                                        }
                                                    </AlertDialogDescription>
                                                </AlertDialogHeader>
                                                <AlertDialogFooter>
                                                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                                    {(!state.agreementToDelete?.boleta_count || state.agreementToDelete.boleta_count === 0) && (
                                                        <AlertDialogAction
                                                            onClick={actions.handleDeleteAgreement}
                                                            disabled={state.isSubmitting}
                                                        >
                                                            {state.isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin"/>}
                                                            Sí, Eliminar
                                                        </AlertDialogAction>
                                                    )}
                                                </AlertDialogFooter>
                                            </AlertDialogContent>
                                        </AlertDialog>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>

            <Dialog open={state.isAgreementFormOpen} onOpenChange={actions.setIsAgreementFormOpen}>
                <DialogContent className="sm:max-w-4xl">
                    <DialogHeader>
                        <DialogTitle>{state.editingAgreement ? 'Editar' : 'Nuevo'} Acuerdo de Consignación</DialogTitle>
                    </DialogHeader>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
                        <div className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="client-search">Cliente</Label>
                                <SearchInput
                                    options={selectors.customerOptions}
                                    onSelect={(option) => actions.handleFieldChange('client_id', option.value)}
                                    value={state.clientSearchTerm}
                                    onValueChange={actions.setClientSearchTerm}
                                    open={state.isClientSearchOpen}
                                    onOpenChange={actions.setIsClientSearchOpen}
                                    placeholder="Buscar cliente..."
                                    disabled={!!state.editingAgreement}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="erp-warehouse">Bodega ERP Asignada (sin IVA)</Label>
                                <SearchInput
                                    options={selectors.warehouseOptions}
                                    onSelect={(option) => actions.handleFieldChange('erp_warehouse_id', option.value)}
                                    value={state.warehouseSearchTerm}
                                    onValueChange={actions.setWarehouseSearchTerm}
                                    open={state.isWarehouseSearchOpen}
                                    onOpenChange={actions.setIsWarehouseSearchOpen}
                                    placeholder="Buscar bodega virtual..."
                                />
                            </div>
                            <div className="space-y-2">
                                <Label>Modo de Operación</Label>
                                <RadioGroup
                                    value={state.agreementFormData.operation_mode}
                                    onValueChange={(value: 'manual' | 'auto') => actions.handleFieldChange('operation_mode', value)}
                                    className="flex space-x-4"
                                >
                                    <div className="flex items-center space-x-2">
                                        <RadioGroupItem value="auto" id="mode_auto" />
                                        <Label htmlFor="mode_auto">Automático (por máximos)</Label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <RadioGroupItem value="manual" id="mode_manual" />
                                        <Label htmlFor="mode_manual">Manual (a petición)</Label>
                                    </div>
                                </RadioGroup>
                                <p className="text-sm text-muted-foreground">
                                    Define si las reposiciones se calculan por stock máximo o si son ingresadas manualmente.
                                </p>
                            </div>
                             <div className="space-y-2">
                                <Label>Modo de Visualización de Código</Label>
                                <RadioGroup 
                                    value={state.agreementFormData.product_code_display_mode} 
                                    onValueChange={(value) => actions.handleFieldChange('product_code_display_mode', value)}
                                    className="flex space-x-4"
                                >
                                    <div className="flex items-center space-x-2">
                                        <RadioGroupItem value="erp_only" id="erp_only" />
                                        <Label htmlFor="erp_only">Solo ERP</Label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <RadioGroupItem value="alias_only" id="alias_only" />
                                        <Label htmlFor="alias_only">Solo Alias</Label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <RadioGroupItem value="both" id="both" />
                                        <Label htmlFor="both">Ambos</Label>
                                    </div>
                                </RadioGroup>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="notes">Notas</Label>
                                <Textarea
                                    id="notes"
                                    value={state.agreementFormData.notes || ''}
                                    onChange={(e) => actions.handleFieldChange('notes', e.target.value)}
                                />
                            </div>
                            <Separator />
                            <div className="space-y-2">
                                <Label>Usuarios a Notificar</Label>
                                 <p className="text-sm text-muted-foreground">
                                    Estos usuarios recibirán un correo con cada cambio de estado de las boletas de este cliente.
                                </p>
                                <MultiSelectFilter
                                    title="Seleccionar Usuarios"
                                    options={selectors.userOptions}
                                    selectedValues={(state.agreementFormData.notification_user_ids || []).map(String)}
                                    onSelectedChange={(ids) => actions.handleFieldChange('notification_user_ids', ids.map(Number))}
                                />
                            </div>
                        </div>
                        <div className="space-y-4">
                            <Label>Productos Autorizados</Label>
                            <div className="space-y-2">
                                <SearchInput
                                    options={selectors.productOptions}
                                    onSelect={(option) => actions.addProductToAgreement(option.value)}
                                    value={state.productSearchTerm}
                                    onValueChange={actions.setProductSearchTerm}
                                    open={state.isProductSearchOpen}
                                    onOpenChange={actions.setIsProductSearchOpen}
                                    placeholder="Añadir producto..."
                                />
                            </div>
                             <ScrollArea className="h-96 overflow-y-auto border rounded-md p-2">
                                <div className="space-y-3">
                                    {state.agreementProducts.map((p: ConsignmentProduct, index: number) => (
                                        <Card key={p.product_id}>
                                            <CardHeader className="p-3 flex flex-row items-center justify-between">
                                                <div>
                                                    <p className="font-medium">{selectors.getProductName(p.product_id)}</p>
                                                    <p className="text-xs text-muted-foreground">{p.product_id}</p>
                                                </div>
                                                <Button variant="ghost" size="icon" onClick={() => actions.removeProductFromAgreement(index)}>
                                                    <Trash2 className="h-4 w-4 text-destructive" />
                                                </Button>
                                            </CardHeader>
                                            <CardContent className="p-3 pt-0 grid grid-cols-2 gap-3">
                                                <div className="space-y-1">
                                                    <Label htmlFor={`client-code-${index}`} className="text-xs">Código Cliente (Alias)</Label>
                                                    <Input id={`client-code-${index}`} value={p.client_product_code || ''} onChange={(e) => actions.updateProductField(index, 'client_product_code', e.target.value)} className="h-8"/>
                                                </div>
                                                 <div className="space-y-1">
                                                    <Label htmlFor={`max-stock-${index}`} className="text-xs">Stock Máximo</Label>
                                                    <Input id={`max-stock-${index}`} type="number" value={p.max_stock || ''} onChange={(e) => actions.updateProductField(index, 'max_stock', Number(e.target.value))} className="text-right h-8 hide-number-arrows"/>
                                                </div>
                                                <div className="space-y-1 col-span-2">
                                                    <Label htmlFor={`price-${index}`} className="text-xs">Precio (sin IVA)</Label>
                                                    <Input id={`price-${index}`} type="number" value={p.price || ''} onChange={(e) => actions.updateProductField(index, 'price', Number(e.target.value))} className="text-right h-8 hide-number-arrows"/>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    ))}
                                </div>
                            </ScrollArea>
                        </div>
                    </div>
                    <DialogFooter>
                        <DialogClose asChild><Button variant="ghost">Cancelar</Button></DialogClose>
                        <Button onClick={actions.handleSaveAgreement} disabled={state.isSubmitting}>
                            {state.isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin"/>}
                            Guardar Acuerdo
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </main>
    );
}
