/**
 * @fileoverview Page for managing individual inventory units (pallets, boxes, etc.).
 * Allows creation of unique trackable units, assignment to products and locations,
 * and printing of QR code labels.
 */
'use client';

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/modules/core/hooks/use-toast';
import { usePageTitle } from '@/modules/core/hooks/usePageTitle';
import { useAuthorization } from '@/modules/core/hooks/useAuthorization';
import { logError, logInfo } from '@/modules/core/lib/logger';
import { getLocations, addInventoryUnit, getInventoryUnits, deleteInventoryUnit, getSelectableLocations } from '@/modules/warehouse/lib/actions';
import type { Product, WarehouseLocation, InventoryUnit } from '@/modules/core/types';
import { useAuth } from '@/modules/core/hooks/useAuth';
import { SearchInput } from '@/components/ui/search-input';
import { Loader2, Trash2, PlusCircle, Printer, List } from 'lucide-react';
import { useDebounce } from 'use-debounce';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import jsPDF from "jspdf";
import QRCode from 'qrcode';
import jsbarcode from 'jsbarcode';
import { format, parseISO } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const initialNewUnitState = {
    productId: '',
    humanReadableId: '',
    locationId: null as number | null,
    notes: '',
    quantity: 1,
};

const renderLocationPathAsString = (locationId: number, locations: WarehouseLocation[]): string => {
    if (!locationId) return '';
    const path: WarehouseLocation[] = [];
    let current: WarehouseLocation | undefined = locations.find(l => l.id === locationId);
    
    while (current) {
        path.unshift(current);
        const parentId = current.parentId;
        if (!parentId) break;
        current = locations.find(l => l.id === parentId);
    }
    return path.map(l => l.name).join(' > ');
};

export default function ManageUnitsPage() {
    useAuthorization(['warehouse:units:create', 'warehouse:units:delete']);
    const { setTitle } = usePageTitle();
    const { toast } = useToast();
    const { user, companyData, products: authProducts, allItemLocations } = useAuth();

    const [isLoading, setIsLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);
    
    const [products, setProducts] = useState<Product[]>([]);
    const [allLocations, setAllLocations] = useState<WarehouseLocation[]>([]);
    const [selectableLocations, setSelectableLocations] = useState<WarehouseLocation[]>([]);
    const [inventoryUnits, setInventoryUnits] = useState<InventoryUnit[]>([]);
    
    const [newUnit, setNewUnit] = useState(initialNewUnitState);

    const [productSearchTerm, setProductSearchTerm] = useState('');
    const [isProductSearchOpen, setIsProductSearchOpen] = useState(false);
    const [locationSearchTerm, setLocationSearchTerm] = useState('');
    const [isLocationSearchOpen, setIsLocationSearchOpen] = useState(false);

    const [debouncedProductSearch] = useDebounce(productSearchTerm, companyData?.searchDebounceTime ?? 500);
    const [debouncedLocationSearch] = useDebounce(locationSearchTerm, 300);

    const loadInitialData = useCallback(async () => {
        setIsLoading(true);
        try {
            const [locs, units] = await Promise.all([
                getLocations(),
                getInventoryUnits(),
            ]);
            setProducts(authProducts.filter(p => p.active === 'S'));
            setAllLocations(locs);
            setSelectableLocations(getSelectableLocations(locs));
            setInventoryUnits(units);
        } catch (error) {
            logError("Failed to load data for units page", { error });
            toast({ title: "Error de Carga", description: "No se pudieron cargar los datos necesarios.", variant: "destructive" });
        } finally {
            setIsLoading(false);
        }
    }, [toast, authProducts]);
    
    useEffect(() => {
        setTitle("Gestión de Lotes/Tarimas");
        loadInitialData();
    }, [setTitle, loadInitialData]);

    const mixedLocationIds = useMemo(() => {
        const counts = new Map<number, number>();
        allItemLocations.forEach(il => {
            if (il.locationId) {
                counts.set(il.locationId, (counts.get(il.locationId) || 0) + 1);
            }
        });
        return new Set(
            Array.from(counts.entries())
                .filter(([_, count]) => count > 1)
                .map(([locationId]) => locationId)
        );
    }, [allItemLocations]);

    const productOptions = useMemo(() => {
        if (!debouncedProductSearch) return [];
        const searchLower = debouncedProductSearch.toLowerCase();

        if (searchLower.length < 2 && !/^\d+$/.test(searchLower)) return [];

        const exactMatch = products.find(p => p.id.toLowerCase() === searchLower);
        const partialMatches = products.filter(p =>
            p.id.toLowerCase() !== searchLower &&
            (p.id.toLowerCase().includes(searchLower) || p.description.toLowerCase().includes(searchLower))
        );

        const results = [];
        if (exactMatch) {
            results.push({ value: exactMatch.id, label: `[${exactMatch.id}] ${exactMatch.description}` });
        }
        results.push(...partialMatches.map(p => ({ value: p.id, label: `[${p.id}] ${p.description}` })));
        
        return results;
    }, [products, debouncedProductSearch]);

    const locationOptions = useMemo(() => {
        const searchTerm = debouncedLocationSearch.trim().toLowerCase();
        if (searchTerm === '*' || searchTerm === '') {
            return selectableLocations.map(l => ({ 
                value: String(l.id), 
                label: `${renderLocationPathAsString(l.id, allLocations)}${mixedLocationIds.has(l.id) ? ' (Mixta)' : ''}`
            }));
        }
        return selectableLocations
            .filter(l => renderLocationPathAsString(l.id, allLocations).toLowerCase().includes(searchTerm))
            .map(l => ({ 
                value: String(l.id), 
                label: `${renderLocationPathAsString(l.id, allLocations)}${mixedLocationIds.has(l.id) ? ' (Mixta)' : ''}`
             }));
    }, [allLocations, selectableLocations, debouncedLocationSearch, mixedLocationIds]);

    const handleSelectProduct = (option: { value: string; label: string; }) => {
        const { value, label } = option;
        const product = authProducts.find(p => p.id === value);
        if (product) {
            setNewUnit(prev => ({ ...prev, productId: value }));
            setProductSearchTerm(label);
            setIsProductSearchOpen(false);
        }
    };
    
    const handleSelectLocation = (option: { value: string; label: string; }) => {
        const { value, label } = option;
        const location = allLocations.find(l => String(l.id) === value);
        if (location) {
            setNewUnit(prev => ({ ...prev, locationId: Number(value) }));
            setLocationSearchTerm(label);
            setIsLocationSearchOpen(false);
        }
    };

    const handleCreateUnit = async () => {
        if (!newUnit.productId || !newUnit.locationId) {
            toast({ title: "Datos Incompletos", description: "Debe seleccionar un producto y una ubicación.", variant: "destructive" });
            return;
        }
        if (!user) {
             toast({ title: "Error de Autenticación", description: "No se pudo identificar al usuario.", variant: "destructive" });
            return;
        }

        setIsSubmitting(true);
        try {
            const createdUnit = await addInventoryUnit({ ...newUnit, createdBy: user.name });
            setInventoryUnits(prev => [createdUnit, ...prev]);
            
            toast({ title: "Unidad Creada", description: `Se ha creado la unidad ${createdUnit.unitCode} para ${createdUnit.productId}.` });
            logInfo('Inventory unit created', { unitCode: createdUnit.unitCode, productId: createdUnit.productId });
            
            // Reset form
            setNewUnit(initialNewUnitState);
            setProductSearchTerm('');
            setLocationSearchTerm('');

        } catch(e: any) {
            logError('Failed to create inventory unit', { error: e.message, details: newUnit });
            toast({ title: "Error", description: `No se pudo crear la unidad. ${e.message}`, variant: "destructive" });
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleDeleteUnit = async (id: number) => {
        setIsSubmitting(true);
        try {
            await deleteInventoryUnit(id);
            setInventoryUnits(prev => prev.filter(u => u.id !== id));
            toast({ title: "Unidad Eliminada", variant: "destructive" });
        } catch(e: any) {
             logError('Failed to delete inventory unit', { error: e.message });
            toast({ title: "Error", description: `No se pudo eliminar la unidad. ${e.message}`, variant: "destructive" });
        } finally {
            setIsSubmitting(false);
        }
    };

    const handlePrintLabel = async (unit: InventoryUnit) => {
        const product = products.find(p => p.id === unit.productId);
        const location = allLocations.find(l => l.id === unit.locationId);
        
        try {
            const qrCodeDataUrl = await QRCode.toDataURL(unit.unitCode!, { errorCorrectionLevel: 'H', width: 200 });

            const barcodeCanvas = document.createElement('canvas');
            jsbarcode(barcodeCanvas, unit.unitCode!, { format: 'CODE128', displayValue: false });
            const barcodeDataUrl = barcodeCanvas.toDataURL('image/png');

            const doc = new jsPDF({
                orientation: 'landscape',
                unit: 'in',
                format: [4, 3] // 4x3 inch label
            });

            const margin = 0.2;
            const contentWidth = 4 - (margin * 2);
            
            const leftColX = margin;
            const leftColWidth = 1.2;
            doc.addImage(qrCodeDataUrl, 'PNG', leftColX, margin, leftColWidth, leftColWidth);
            doc.addImage(barcodeDataUrl, 'PNG', leftColX, margin + leftColWidth + 0.1, leftColWidth, 0.4);
            doc.setFontSize(10).text(unit.unitCode!, leftColX + leftColWidth / 2, margin + leftColWidth + 0.1 + 0.4 + 0.15, { align: 'center' });

            const rightColX = leftColX + leftColWidth + 0.2;
            const rightColWidth = contentWidth - leftColWidth - 0.2;

            let currentY = margin + 0.1;
            doc.setFontSize(12).setFont('Helvetica', 'bold').text(`Producto: ${product?.id || 'N/A'}`, rightColX, currentY);
            currentY += 0.2;
            
            doc.setFontSize(9).setFont('Helvetica', 'normal');
            const descLines = doc.splitTextToSize(product?.description || 'Descripción no disponible', rightColWidth);
            doc.text(descLines, rightColX, currentY);
            currentY += (descLines.length * 0.15) + 0.2;
            
            doc.setFontSize(10).setFont('Helvetica', 'bold').text(`Lote/ID: ${unit.humanReadableId || 'N/A'}`, rightColX, currentY);
            currentY += 0.15;
            doc.text(`Documento: ${unit.documentId || 'N/A'}`, rightColX, currentY);
            currentY += 0.15;
            doc.text(`Doc. ERP: ${unit.erpDocumentId || 'N/A'}`, rightColX, currentY);
            currentY += 0.25;

            doc.setFontSize(10).setFont('Helvetica', 'bold').text(`Ubicación:`, rightColX, currentY);
            currentY += 0.15;
            
            doc.setFontSize(9).setFont('Helvetica', 'normal');
            const locLines = doc.splitTextToSize(renderLocationPathAsString(location?.id || 0, allLocations), rightColWidth);
            doc.text(locLines, rightColX, currentY);
            
            const footerY = 3 - margin;
            doc.setFontSize(8).setTextColor(150);
            doc.text(`Creado: ${format(new Date(), 'dd/MM/yyyy')} por ${user?.name || 'Sistema'}`, 4 - margin, footerY, { align: 'right' });

            doc.save(`etiqueta_unidad_${unit.unitCode}.pdf`);

        } catch (err) {
            console.error(err);
            toast({ title: 'Error al generar QR/Barcode', description: 'No se pudo crear la imagen del código.', variant: 'destructive'});
        }
    };
    
    if (isLoading) {
        return (
            <main className="flex-1 p-4 md:p-6 lg:p-8">
                 <div className="grid gap-8 md:grid-cols-3">
                    <div className="md:col-span-1 space-y-6">
                        <Skeleton className="h-64 w-full" />
                    </div>
                    <div className="md:col-span-2">
                        <Skeleton className="h-80 w-full" />
                    </div>
                </div>
            </main>
        )
    }

    return (
        <main className="flex-1 p-4 md:p-6 lg:p-8">
            <div className="mx-auto max-w-5xl space-y-8">
                <Card>
                    <CardHeader>
                        <CardTitle>Nueva Unidad de Inventario</CardTitle>
                        <CardDescription>Crea un identificador único (tarima, lote, caja) para un producto, asígnale una ubicación y genera su etiqueta QR.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label>1. Producto <span className="text-destructive">*</span></Label>
                                <SearchInput options={productOptions} onSelect={handleSelectProduct} value={productSearchTerm} onValueChange={setProductSearchTerm} placeholder="Buscar producto..." open={isProductSearchOpen} onOpenChange={setIsProductSearchOpen} />
                            </div>
                             <div className="space-y-2">
                                <Label>2. Ubicación <span className="text-destructive">*</span></Label>
                                 <div className="flex items-center gap-2">
                                    <SearchInput options={locationOptions} onSelect={handleSelectLocation} value={locationSearchTerm} onValueChange={setLocationSearchTerm} placeholder="Buscar... ('*' o vacío para ver todas)" open={isLocationSearchOpen} onOpenChange={setIsLocationSearchOpen} />
                                    <Button type="button" variant="outline" size="icon" onClick={() => {setLocationSearchTerm('*'); setIsLocationSearchOpen(true);}}>
                                        <List className="h-4 w-4" />
                                    </Button>
                                </div>
                            </div>
                        </div>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                             <div className="space-y-2">
                                <Label htmlFor="quantity">3. Cantidad en la Unidad</Label>
                                <Input id="quantity" type="number" value={newUnit.quantity} onChange={(e) => setNewUnit(prev => ({...prev, quantity: Number(e.target.value)}))} placeholder="Ej: 1"/>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="human-id">4. Identificador Humano (Lote/Tarima)</Label>
                                <Input id="human-id" value={newUnit.humanReadableId} onChange={(e) => setNewUnit(prev => ({ ...prev, humanReadableId: e.target.value }))} placeholder="Ej: LOTE-2024-10-A"/>
                            </div>
                             <div className="space-y-2 md:col-span-2">
                                <Label htmlFor="notes">5. Notas (Opcional)</Label>
                                <Textarea id="notes" value={newUnit.notes} onChange={(e) => setNewUnit(prev => ({ ...prev, notes: e.target.value }))} placeholder="Ej: Media tarima, producto de alta rotación"/>
                            </div>
                        </div>
                    </CardContent>
                    <CardFooter>
                        <Button onClick={handleCreateUnit} disabled={isSubmitting || !newUnit.productId || !newUnit.locationId}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            <PlusCircle className="mr-2 h-4 w-4" />
                            Crear Unidad
                        </Button>
                    </CardFooter>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>Unidades Creadas Recientemente</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="max-h-96 overflow-y-auto">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>ID Unidad</TableHead>
                                        <TableHead>Producto</TableHead>
                                        <TableHead>ID Humano</TableHead>
                                        <TableHead>Ubicación</TableHead>
                                        <TableHead>Creado</TableHead>
                                        <TableHead className="text-right">Acciones</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {inventoryUnits.map(unit => {
                                        const product = products.find(p => p.id === unit.productId);
                                        const location = allLocations.find(l => l.id === unit.locationId);
                                        const isMixed = location ? mixedLocationIds.has(location.id) : false;
                                        return (
                                            <TableRow key={unit.id} className="border-b">
                                                <TableCell className="p-2 font-mono">{unit.unitCode}</TableCell>
                                                <TableCell className="p-2">
                                                    <div className="font-medium">{product?.description || 'N/A'}</div>
                                                    <div className="text-xs text-muted-foreground">{unit.productId}</div>
                                                </TableCell>
                                                <TableCell className="p-2 font-mono">{unit.humanReadableId || '-'}</TableCell>
                                                <TableCell className="p-2">
                                                    <div className="flex items-center gap-2">
                                                        <span>{location ? renderLocationPathAsString(location.id, allLocations) : 'N/A'}</span>
                                                        {isMixed && <Badge variant="destructive">Mixta</Badge>}
                                                    </div>
                                                </TableCell>
                                                <TableCell className="p-2 text-xs text-muted-foreground">
                                                    <div>{unit.createdBy}</div>
                                                    <div>{format(new Date(unit.createdAt), 'dd/MM/yyyy HH:mm')}</div>
                                                </TableCell>
                                                <TableCell className="p-2 text-right">
                                                    <Button variant="outline" size="sm" onClick={() => handlePrintLabel(unit)}><Printer className="mr-2 h-4 w-4"/>Imprimir</Button>
                                                    <Button variant="ghost" size="icon" onClick={() => handleDeleteUnit(unit.id)} disabled={isSubmitting}>
                                                        <Trash2 className="h-4 w-4 text-destructive"/>
                                                    </Button>
                                                </TableCell>
                                            </TableRow>
                                        );
                                    })}
                                </TableBody>
                            </Table>
                             {inventoryUnits.length === 0 && (
                                <div className="text-center py-10 text-muted-foreground">No hay unidades de inventario creadas.</div>
                            )}
                        </div>
                    </CardContent>
                </Card>
            </div>
        </main>
    );
}
