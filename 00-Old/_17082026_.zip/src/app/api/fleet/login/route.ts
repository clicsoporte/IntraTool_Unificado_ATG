import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/modules/core/lib/db';
import bcrypt from 'bcryptjs';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { usernameOrEmail, password, driverId } = body;

    if (!password || typeof password !== 'string' || password.trim().length === 0) {
      return NextResponse.json({ success: false, error: 'Debe proporcionar su contraseña' }, { status: 400 });
    }

    const db = await getDb();

    if (driverId) {
      const user = db.prepare('SELECT id, name, email, employeeId, password, is_active FROM core_users WHERE id = ?').get(driverId) as any;
      if (!user) {
        return NextResponse.json({ success: false, error: 'Usuario no encontrado' }, { status: 404 });
      }

      if (user.is_active === 0) {
        return NextResponse.json({ success: false, error: 'Cuenta de chofer inactiva' }, { status: 403 });
      }

      if (!user.password) {
        return NextResponse.json({ success: false, error: 'El usuario no tiene contraseña configurada' }, { status: 401 });
      }

      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return NextResponse.json({ success: false, error: 'Contraseña incorrecta' }, { status: 401 });
      }

      return NextResponse.json({
        success: true,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          employeeId: user.employeeId,
        }
      });
    }

    if (!usernameOrEmail) {
      return NextResponse.json({ success: false, error: 'Debe proporcionar usuario/correo' }, { status: 400 });
    }

    const cleanSearch = usernameOrEmail.trim();
    const user = db.prepare(`
      SELECT id, name, email, employeeId, password, is_active 
      FROM core_users 
      WHERE LOWER(email) = LOWER(?) OR LOWER(name) = LOWER(?) OR employeeId = ?
    `).get(cleanSearch, cleanSearch, cleanSearch) as any;

    if (!user) {
      return NextResponse.json({ success: false, error: 'Usuario o contraseña incorrectos' }, { status: 401 });
    }

    if (user.is_active === 0) {
      return NextResponse.json({ success: false, error: 'Cuenta de chofer inactiva' }, { status: 403 });
    }

    if (!user.password) {
      return NextResponse.json({ success: false, error: 'El usuario no tiene contraseña configurada' }, { status: 401 });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return NextResponse.json({ success: false, error: 'Usuario o contraseña incorrectos' }, { status: 401 });
    }

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        employeeId: user.employeeId,
      }
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
