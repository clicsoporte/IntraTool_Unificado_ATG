import { NextResponse } from 'next/server';
import { addSuggestion } from '@/modules/core/lib/suggestions-actions';

/**
 * POST /api/fleet/suggestions
 * Permite a la APK Clic Driver enviar sugerencias directamente a /dashboard/admin/suggestions
 */
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { content, userId, userName } = body;

    if (!content || typeof content !== 'string' || !content.trim()) {
      return NextResponse.json({ success: false, error: 'El contenido de la sugerencia es requerido.' }, { status: 400 });
    }

    const finalUserName = userName || 'Chofer Clic Driver';
    const finalUserId = userId ? Number(userId) : null;

    await addSuggestion(content.trim(), finalUserId, finalUserName);

    return NextResponse.json({ success: true, message: 'Sugerencia registrada exitosamente.' });
  } catch (error: any) {
    console.error('Error al guardar sugerencia desde APK:', error);
    return NextResponse.json({ success: false, error: error?.message || 'Error al guardar la sugerencia.' }, { status: 500 });
  }
}
