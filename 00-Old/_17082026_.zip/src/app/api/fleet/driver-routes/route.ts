import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/modules/core/lib/db';
import { getBusinessDateStr } from '@/modules/core/lib/timezone';
import { updateDeliveryStatusInternal, getDocumentLinesInternal } from '@/modules/operations/lib/delivery-service';

export async function GET(req: NextRequest) {
  try {
    const db = await getDb();
    const today = await getBusinessDateStr();
    const { searchParams } = new URL(req.url);
    const userIdParam = searchParams.get('userId');

    let userId = userIdParam ? Number(userIdParam) : null;

    if (!userId || isNaN(userId)) {
      return NextResponse.json({
        success: true,
        hasActiveAssignment: false,
        assignment: null,
        deliveries: []
      });
    }

    // Find driver's active assignment today
    const assignment = db.prepare(`
      SELECT 
        a.id,
        a.ruta_id,
        a.empleado_id,
        a.vehiculo_id,
        a.fecha,
        a.activa,
        a.fecha_salida,
        a.siguiente_cliente,
        a.fecha_inicio_retorno,
        a.fecha_completada,
        COALESCE(r.name, '') as ruta_nombre,
        COALESCE(v.plate, '') as vehiculo_placa
      FROM ops_delivery_assignments a
      LEFT JOIN ops_delivery_routes r ON a.ruta_id = r.id
      LEFT JOIN fleet_vehicles v ON a.vehiculo_id = v.id
      WHERE a.empleado_id = ? AND a.fecha = ? AND a.activa = 1
      LIMIT 1
    `).get(userId, today) as any;

    if (!assignment) {
      return NextResponse.json({
        success: true,
        hasActiveAssignment: false,
        assignment: null,
        deliveries: []
      });
    }

    // Fetch documents belonging STRICTLY to this active assignment
    const docs = db.prepare(`
      SELECT 
        q.id,
        q.documento_numero,
        q.boleta_numero,
        q.tipo_documento,
        q.cliente_nombre,
        q.cliente_id,
        COALESCE(
          (
            SELECT sa.detalle_direccion 
            FROM core_customer_shipment_addresses sa 
            JOIN core_erp_invoice_headers h ON h.FACTURA = q.documento_numero
            WHERE sa.cliente_id = q.cliente_id AND sa.direccion_id = h.DIREC_EMBARQUE
              AND sa.detalle_direccion IS NOT NULL AND sa.detalle_direccion != '' AND sa.detalle_direccion NOT GLOB '*[0-9].0'
            LIMIT 1
          ),
          (
            SELECT sa.descripcion 
            FROM core_customer_shipment_addresses sa 
            JOIN core_erp_invoice_headers h ON h.FACTURA = q.documento_numero
            WHERE sa.cliente_id = q.cliente_id AND sa.direccion_id = h.DIREC_EMBARQUE
              AND sa.descripcion IS NOT NULL AND sa.descripcion != '' AND sa.descripcion NOT GLOB '*[0-9].0'
            LIMIT 1
          ),
          (
            SELECT sa.detalle_direccion 
            FROM core_customer_shipment_addresses sa 
            WHERE sa.cliente_id = q.cliente_id 
              AND sa.detalle_direccion IS NOT NULL AND sa.detalle_direccion != '' AND sa.detalle_direccion NOT GLOB '*[0-9].0'
            ORDER BY sa.id ASC LIMIT 1
          ),
          (
            SELECT sa.descripcion 
            FROM core_customer_shipment_addresses sa 
            WHERE sa.cliente_id = q.cliente_id 
              AND sa.descripcion IS NOT NULL AND sa.descripcion != '' AND sa.descripcion NOT GLOB '*[0-9].0'
            ORDER BY sa.id ASC LIMIT 1
          ),
          (SELECT c.address FROM core_customers c WHERE c.id = q.cliente_id AND c.address IS NOT NULL AND c.address != '' LIMIT 1),
          'Dirección registrada en expediente del cliente'
        ) as lugar_entrega,
        q.comentario,
        COALESCE(
          (SELECT OBSERVACIONES FROM core_erp_invoice_headers WHERE FACTURA = q.documento_numero LIMIT 1),
          ''
        ) as observaciones,
        q.estado,
        COALESCE(u.name, '') as chofer_nombre,
        COALESCE(v.plate, '') as placa_vehiculo,
        COALESCE(r.name, '') as ruta_nombre,
        q.fecha_entrega,
        q.nombre_recibe,
        q.firma_cliente,
        q.latitud,
        q.longitud
      FROM ops_delivery_queue q
      JOIN ops_delivery_assignments a ON q.asignacion_id = a.id
      LEFT JOIN core_users u ON a.empleado_id = u.id
      LEFT JOIN fleet_vehicles v ON a.vehiculo_id = v.id
      LEFT JOIN ops_delivery_routes r ON a.ruta_id = r.id
      WHERE q.asignacion_id = ?
      ORDER BY q.id ASC
    `).all(assignment.id);

    const getLinesStmt = db.prepare(`
      SELECT 
        producto_codigo as codigo, 
        producto_descripcion as desc, 
        cantidad_pedida as pedida, 
        cantidad_entregada as entregada, 
        cantidad_faltante as faltante 
      FROM ops_delivery_lines 
      WHERE delivery_order_id = ?
    `);

    let totalLinesCount = 0;
    for (const doc of docs as any[]) {
      if (doc.tipo_documento === 'recoger') {
        try {
          const supp = db.prepare('SELECT address, latitude, longitude FROM core_suppliers WHERE id = ? OR LOWER(name) = LOWER(?)').get(doc.cliente_id, doc.cliente_nombre) as { address?: string; latitude?: number; longitude?: number } | undefined;
          if (supp) {
            if (supp.latitude !== null && supp.latitude !== undefined) {
              doc.latitud_destino = supp.latitude;
              doc.longitud_destino = supp.longitude;
            }
            if (supp.address && (!doc.lugar_entrega || doc.lugar_entrega.includes('expediente'))) {
              doc.lugar_entrega = supp.address;
            }
          }
        } catch (_) {}
      }

      let dbLines = (getLinesStmt.all(doc.id) as any[]) || [];

      if (dbLines.length === 0) {
        try {
          const cleanDocNum = (doc.documento_numero || '').replace('-PARTIAL', '').replace('-RETRY', '');
          const erpLines = await getDocumentLinesInternal(cleanDocNum, doc.tipo_documento || 'factura');
          if (erpLines && erpLines.length > 0) {
            dbLines = erpLines.map((l: any) => ({
              codigo: l.articulo || l.codigo || 'ART',
              desc: l.descripcion || l.desc || `Producto ${l.articulo}`,
              pedida: Number(l.cantidad || l.pedida || 1),
              entregada: doc.estado === 'completo' || doc.estado === 'entregado' ? Number(l.cantidad || l.pedida || 1) : 0,
              faltante: doc.estado === 'completo' || doc.estado === 'entregado' ? 0 : Number(l.cantidad || l.pedida || 1),
            }));
          }
        } catch (_) {}
      }

      if (dbLines.length > 0) {
        doc.lines = dbLines;
      } else {
        doc.lines = [{
          codigo: doc.boleta_numero || doc.documento_numero || `DOC-${doc.id}`,
          desc: `Mercancía / Bultos General (${doc.cliente_nombre || 'Cliente'})`,
          pedida: 1,
          entregada: doc.estado === 'completo' || doc.estado === 'entregado' ? 1 : 0,
          faltante: doc.estado === 'completo' || doc.estado === 'entregado' ? 0 : 1
        }];
      }
      totalLinesCount += doc.lines.length;
    }

    return NextResponse.json({
      success: true,
      hasActiveAssignment: true,
      assignment,
      date: today,
      count: docs.length,
      totalLinesCount,
      deliveries: docs
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, estado, comentario, fotoEvidencia, fotoFactura, firmaCliente, nombreRecibe, lines, choferNombre, lat, lng } = body;

    if (!id || !estado) {
      return NextResponse.json({ success: false, error: "Faltan parámetros requeridos (id, estado)" }, { status: 400 });
    }

    const success = await updateDeliveryStatusInternal(Number(id), {
      estado,
      comentario,
      canal: 'web',
      gestionadoPor: choferNombre || 'App Nativa ClicDriver',
      fotoEvidencia,
      fotoFactura,
      firmaCliente,
      nombreRecibe,
      lat: lat ? Number(lat) : null,
      lng: lng ? Number(lng) : null,
      lines: lines || []
    });

    if (success) {
      return NextResponse.json({ success: true, message: "Entrega registrada exitosamente" });
    } else {
      return NextResponse.json({ success: false, error: "No se pudo actualizar el estado de la entrega" }, { status: 500 });
    }
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
