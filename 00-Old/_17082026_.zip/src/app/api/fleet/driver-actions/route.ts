import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/modules/core/lib/db';
import { getBusinessDateStr } from '@/modules/core/lib/timezone';

export async function GET() {
  try {
    const db = await getDb();
    const routes = db.prepare("SELECT id, name FROM ops_delivery_routes WHERE active = 1 ORDER BY name ASC").all();
    const vehicles = db.prepare("SELECT id, plate, brand, model FROM fleet_vehicles ORDER BY plate ASC").all();

    return NextResponse.json({
      success: true,
      routes,
      vehicles
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action, userId, rutaId, vehiculoId, assignmentId, docNumStr, lat, lng, siguienteCliente, finishType } = body;

    const db = await getDb();
    const todayStr = await getBusinessDateStr();
    const now = new Date().toISOString();

    // 1. INICIAR RUTA (Seleccionar Vehículo y Ruta)
    if (action === 'start_route') {
      if (!userId || !rutaId || !vehiculoId) {
        return NextResponse.json({ success: false, error: 'Faltan parámetros: userId, rutaId, vehiculoId' }, { status: 400 });
      }

      const existing = db.prepare("SELECT id FROM ops_delivery_assignments WHERE empleado_id = ? AND fecha = ? AND activa = 1").get(userId, todayStr);
      if (existing) {
        return NextResponse.json({ success: true, message: 'Ruta ya activa', assignmentId: (existing as any).id });
      }

      const info = db.prepare(`
        INSERT INTO ops_delivery_assignments (
          ruta_id, empleado_id, vehiculo_id, fecha, activa, fecha_creacion
        ) VALUES (?, ?, ?, ?, 1, ?)
      `).run(rutaId, userId, vehiculoId, todayStr, now);

      return NextResponse.json({
        success: true,
        assignmentId: Number(info.lastInsertRowid),
        message: 'Ruta iniciada correctamente'
      });
    }

    // 2. CARGAR / ESCANEAR FACTURA A LA RUTA
    if (action === 'autoload_invoice') {
      if (!assignmentId || !docNumStr) {
        return NextResponse.json({ success: false, error: 'Faltan parámetros: assignmentId, docNumStr' }, { status: 400 });
      }

      const tokens = docNumStr.split(/[,;\s]+/).map((t: string) => t.trim().toUpperCase()).filter((t: string) => t.length > 0);
      let loadedCount = 0;
      const notFoundTokens: string[] = [];

      for (const token of tokens) {
        let queueDoc = db.prepare(`
          SELECT q.*, a.empleado_id, u.name as chofer_nombre
          FROM ops_delivery_queue q
          LEFT JOIN ops_delivery_assignments a ON q.asignacion_id = a.id AND a.activa = 1
          LEFT JOIN core_users u ON a.empleado_id = u.id
          WHERE (UPPER(q.documento_numero) = ? OR UPPER(q.documento_numero) LIKE ?) AND q.entregado = 0
          ORDER BY CASE WHEN UPPER(q.documento_numero) = ? THEN 1 ELSE 2 END, q.id DESC
          LIMIT 1
        `).get(token, `%${token}`, token) as any;

        if (!queueDoc && token.length >= 3) {
          queueDoc = db.prepare(`
            SELECT q.*, a.empleado_id, u.name as chofer_nombre
            FROM ops_delivery_queue q
            LEFT JOIN ops_delivery_assignments a ON q.asignacion_id = a.id AND a.activa = 1
            LEFT JOIN core_users u ON a.empleado_id = u.id
            WHERE UPPER(q.documento_numero) LIKE ? AND q.entregado = 0
            ORDER BY q.id DESC
            LIMIT 1
          `).get(`%${token}%`) as any;
        }

        if (queueDoc) {
          if (queueDoc.asignacion_id && queueDoc.asignacion_id !== assignmentId && queueDoc.empleado_id) {
            return NextResponse.json({
              success: false,
              error: `El documento #${queueDoc.documento_numero} ya está asignado a la ruta de ${queueDoc.chofer_nombre || 'otro chofer'}.`
            }, { status: 400 });
          }

          db.prepare("UPDATE ops_delivery_queue SET asignacion_id = ?, estado = 'en_ruta' WHERE id = ?").run(assignmentId, queueDoc.id);
          loadedCount++;
          continue;
        }

        let erpInvoice = db.prepare(`
          SELECT FACTURA, CLIENTE, NOMBRE_CLIENTE FROM core_erp_invoice_headers
          WHERE UPPER(FACTURA) = ? OR UPPER(FACTURA) LIKE ?
          ORDER BY CASE WHEN UPPER(FACTURA) = ? THEN 1 ELSE 2 END, FACTURA DESC
          LIMIT 1
        `).get(token, `%${token}`, token) as any;

        if (!erpInvoice && token.length >= 3) {
          erpInvoice = db.prepare(`
            SELECT FACTURA, CLIENTE, NOMBRE_CLIENTE FROM core_erp_invoice_headers
            WHERE UPPER(FACTURA) LIKE ?
            ORDER BY FACTURA DESC
            LIMIT 1
          `).get(`%${token}%`) as any;
        }

        if (erpInvoice) {
          const existingInQueue = db.prepare("SELECT id, asignacion_id FROM ops_delivery_queue WHERE UPPER(documento_numero) = ? AND entregado = 0").get(erpInvoice.FACTURA.toUpperCase()) as any;
          if (existingInQueue) {
            if (existingInQueue.asignacion_id && existingInQueue.asignacion_id !== assignmentId) {
              return NextResponse.json({
                success: false,
                error: `La factura #${erpInvoice.FACTURA} ya está asignada a otra ruta.`
              }, { status: 400 });
            }
            db.prepare("UPDATE ops_delivery_queue SET asignacion_id = ?, estado = 'en_ruta' WHERE id = ?").run(assignmentId, existingInQueue.id);
          } else {
            db.prepare(`
              INSERT INTO ops_delivery_queue (
                documento_numero, tipo_documento, cliente_id, cliente_nombre, asignacion_id, entregado, estado, fecha_registro
              ) VALUES (?, 'factura', ?, ?, ?, 0, 'en_ruta', ?)
            `).run(erpInvoice.FACTURA, erpInvoice.CLIENTE, erpInvoice.NOMBRE_CLIENTE, assignmentId, todayStr);
          }
          loadedCount++;
          continue;
        }

        notFoundTokens.push(token);
      }

      if (loadedCount === 0 && notFoundTokens.length > 0) {
        return NextResponse.json({
          success: false,
          error: `No se encontraron documentos en ERP o cola general para: ${notFoundTokens.join(', ')}`
        }, { status: 404 });
      }

      return NextResponse.json({
        success: true,
        message: `Se cargaron ${loadedCount} factura(s) a tu ruta activa.${notFoundTokens.length > 0 ? ` (No encontrados: ${notFoundTokens.join(', ')})` : ''}`
      });
    }

    // 3. SALIR A RUTA (DEPART TO ROUTE)
    if (action === 'depart_route') {
      if (!assignmentId) {
        return NextResponse.json({ success: false, error: 'Falta assignmentId' }, { status: 400 });
      }

      db.prepare(`
        UPDATE ops_delivery_assignments
        SET fecha_salida = ?
        WHERE id = ?
      `).run(now, assignmentId);

      if (lat && lng) {
        db.prepare(`
          INSERT INTO ops_delivery_gps_logs (asignacion_id, timestamp, latitud, longitud, evento)
          VALUES (?, ?, ?, ?, 'salida_ruta')
        `).run(assignmentId, now, lat, lng);
      }

      return NextResponse.json({ success: true, message: 'Salida a ruta registrada' });
    }

    // 4. INDICAR SIGUIENTE CLIENTE
    if (action === 'set_next_client') {
      if (!assignmentId || !siguienteCliente) {
        return NextResponse.json({ success: false, error: 'Faltan parámetros: assignmentId, siguienteCliente' }, { status: 400 });
      }

      db.prepare(`
        UPDATE ops_delivery_assignments
        SET siguiente_cliente = ?, siguiente_cliente_fecha = ?
        WHERE id = ?
      `).run(siguienteCliente, now, assignmentId);

      return NextResponse.json({ success: true, message: `Siguiente cliente fijado: ${siguienteCliente}` });
    }

    // 5. FINALIZAR RUTA / INICIAR RETORNO
    if (action === 'finish_route') {
      if (!assignmentId) {
        return NextResponse.json({ success: false, error: 'Falta assignmentId' }, { status: 400 });
      }

      if (finishType === 'return') {
        db.prepare(`
          UPDATE ops_delivery_assignments
          SET fecha_inicio_retorno = ?, latitud_retorno = ?, longitud_retorno = ?
          WHERE id = ?
        `).run(now, lat || null, lng || null, assignmentId);
        return NextResponse.json({ success: true, message: 'Inicio de retorno registrado' });
      } else {
        const { finalizeRouteAssignmentInternal } = await import('@/modules/operations/lib/actions');
        const driverName = body.driverName || 'Chofer APK';
        const finRes = await finalizeRouteAssignmentInternal(assignmentId, driverName, db, lat || null, lng || null);
        return NextResponse.json({
          success: finRes.success,
          consecutivo: finRes.consecutivo,
          message: finRes.success ? `Ruta finalizada con consecutivo ${finRes.consecutivo}` : (finRes.error || 'Error al finalizar ruta')
        });
      }
    }

    // 6. REVERTIR ENTREGA (Soporta APK sin requerir cookies de sesión web)
    if (action === 'revert_delivery') {
      const { docId } = body;
      if (!docId) {
        return NextResponse.json({ success: false, error: 'Falta docId' }, { status: 400 });
      }
      const { revertDeliveryInternal } = await import('@/modules/operations/lib/driver-actions');
      const res = await revertDeliveryInternal(Number(docId));
      return NextResponse.json(res);
    }

    // 7. REPORTAR AVERÍA (Reutiliza la lógica existente)
    if (action === 'report_breakdown') {
      const { vehiculoId, breakdownType, description, choferNombre } = body;
      if (!vehiculoId || !description) {
        return NextResponse.json({ success: false, error: 'Faltan parámetros de avería' }, { status: 400 });
      }
      const { saveTelegramMaintenanceLog } = await import('@/modules/fleet/lib/telegram-bot');
      await saveTelegramMaintenanceLog({
        vehicleId: Number(vehiculoId),
        date: todayStr,
        mileage: 0,
        type: breakdownType || 'Mecánica',
        description,
        cost: 0,
        performedBy: choferNombre || 'Chofer APK'
      }, choferNombre || 'Chofer APK');
      return NextResponse.json({ success: true, message: 'Avería reportada exitosamente a la central' });
    }

    // 8. ENVIAR BOLETA POR CORREO
    if (action === 'send_email') {
      const { docId, targetEmail } = body;
      if (!docId) {
        return NextResponse.json({ success: false, error: 'Falta docId' }, { status: 400 });
      }
      const { sendBoletaManualEmail } = await import('@/modules/operations/lib/actions');
      const res = await sendBoletaManualEmail(Number(docId), targetEmail || '');
      return NextResponse.json(res);
    }

    return NextResponse.json({ success: false, error: `Acción desconocida: ${action}` }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
