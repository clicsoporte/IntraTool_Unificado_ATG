'use client';

import React from 'react';
import { 
    Dialog, 
    DialogContent, 
    DialogHeader, 
    DialogTitle, 
    DialogDescription 
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Camera, Download, ExternalLink, X } from 'lucide-react';
import Image from 'next/image';

interface SelectedPhoto {
    url: string;
    title: string;
}

interface EvidencePhotoViewerProps {
    selectedPhoto: SelectedPhoto | null;
    onClose: () => void;
}

export function EvidencePhotoViewer({ selectedPhoto, onClose }: EvidencePhotoViewerProps) {
    const handleDownload = async () => {
        if (!selectedPhoto) return;
        try {
            const response = await fetch(selectedPhoto.url);
            const blob = await response.blob();
            const blobUrl = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = blobUrl;
            // Clean filename
            const cleanTitle = (selectedPhoto.title || 'Evidencia_Entrega')
                .replace(/[^a-zA-Z0-9_-]/g, '_')
                .replace(/_+/g, '_');
            link.download = `${cleanTitle}.png`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            window.URL.revokeObjectURL(blobUrl);
        } catch (e) {
            // Fallback direct download
            const link = document.createElement('a');
            link.href = selectedPhoto.url;
            link.download = 'evidencia.png';
            link.target = '_blank';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    };

    return (
        <Dialog open={!!selectedPhoto} onOpenChange={(open) => { if (!open) onClose(); }}>
            <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col border border-slate-800 bg-slate-950/95 backdrop-blur-xl text-white shadow-2xl p-6 rounded-3xl">
                <DialogHeader className="space-y-1.5 pb-2 border-b border-white/10">
                    <DialogTitle className="text-lg font-bold flex items-center gap-2 text-white">
                        <Camera className="h-5 w-5 text-indigo-400" />
                        {selectedPhoto?.title || "Evidencia Digital"}
                    </DialogTitle>
                    <DialogDescription className="text-xs text-slate-400">
                        Comprobante fotográfico / firma digital registrado en el sistema de entregas.
                    </DialogDescription>
                </DialogHeader>

                {selectedPhoto && (
                    <div className="relative mt-3 w-full h-[55vh] min-h-[320px] bg-black/70 rounded-2xl overflow-hidden flex items-center justify-center border border-white/10 group p-2">
                        <Image 
                            src={selectedPhoto.url} 
                            alt={selectedPhoto.title} 
                            fill
                            className="object-contain transition-transform duration-300 group-hover:scale-105"
                            unoptimized
                        />
                    </div>
                )}

                <div className="mt-4 pt-2 border-t border-white/10 flex flex-wrap gap-2 justify-between items-center">
                    <Button 
                        variant="secondary" 
                        className="bg-white/10 hover:bg-white/20 text-white rounded-xl h-10 px-4 text-xs font-semibold"
                        onClick={onClose}
                    >
                        Cerrar
                    </Button>

                    <div className="flex items-center gap-2">
                        {selectedPhoto && (
                            <>
                                <Button
                                    onClick={handleDownload}
                                    className="bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl h-10 px-4 text-xs font-semibold flex items-center gap-1.5 shadow-sm"
                                >
                                    <Download className="w-4 h-4" />
                                    Descargar Imagen
                                </Button>
                                <a 
                                    href={selectedPhoto.url}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    <Button 
                                        variant="outline"
                                        className="bg-indigo-600 hover:bg-indigo-700 border-none text-white rounded-xl h-10 px-4 text-xs font-semibold flex items-center gap-1.5 shadow-sm"
                                    >
                                        <ExternalLink className="w-4 h-4" />
                                        Abrir en Pestaña Nueva
                                    </Button>
                                </a>
                            </>
                        )}
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}
