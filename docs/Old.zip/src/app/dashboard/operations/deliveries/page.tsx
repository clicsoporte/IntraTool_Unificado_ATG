'use client';

import React, { useState, useEffect } from 'react';
import { useToast } from '@/modules/core/hooks/use-toast';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { 
    Dialog, 
    DialogContent, 
    DialogHeader, 
    DialogTitle, 
    DialogDescription, 
    DialogFooter 
} from '@/components/ui/dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue
} from '@/components/ui/select';
import { 
    RefreshCw, 
    Tv, 
    Monitor, 
    AlertTriangle, 
    CheckCircle, 
    XCircle, 
    Clock, 
    Lock, 
    ShieldAlert, 
    Key, 
    FileText, 
    Check, 
    Truck, 
    MapPin, 
    User,
    ChevronRight,
    Eye
} from 'lucide-react';
import {
    getAssignedDeliveriesToday,
    getActiveAssignmentsToday,
    getDeliverySettings,
    updateDeliveryStatus,
    getDocumentLines,
    generateReleaseCode,
    getActiveReleaseCode
} from '@/modules/operations/lib/actions';

export default function DeliveriesDashboardPage() {
    const { toast } = useToast();
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [tvMode, setTvMode] = useState(false);
    const [hideDelivered, setHideDelivered] = useState(false);
    
    // Auto-Refresh state
    const [refreshIntervalSec, setRefreshIntervalSec] = useState<number>(30); // Default 30s
    const [secondsToNextRefresh, setSecondsToNextRefresh] = useState<number>(30);

    // Operational State
    const [assignments, setAssignments] = useState<any[]>([]);
    const [deliveries, setDeliveries] = useState<any[]>([]);
    const [settings, setSettings] = useState<any>({
        delivery_mode: 'sencillo',
        release_codes_enabled: 'false'
    });

    // Contingency Modal State
    const [modalOpen, setModalOpen] = useState(false);
    const [selectedDoc, setSelectedDoc] = useState<any>(null);
    const [modalLoading, setModalLoading] = useState(false);
    const [modalLines, setModalLines] = useState<any[]>([]);

    // Manual status update inputs
    const [manualState, setManualState] = useState<'completo' | 'incompleto' | 'rechazado'>('completo');
    const [manualComment, setManualComment] = useState('');
    
    // Advanced mode specific inputs
    const [lineQuantities, setLineQuantities] = useState<Record<string, { entregada: number; faltante: number }>>({});
    const [releaseCode, setReleaseCode] = useState('');
    const [generatedCode, setGeneratedCode] = useState('');
    const [generatingCode, setGeneratingCode] = useState(false);

    const loadData = React.useCallback(async () => {
        setLoading(true);
        try {
            const [a, d, s] = await Promise.all([
                getActiveAssignmentsToday(),
                getAssignedDeliveriesToday(),
                getDeliverySettings()
            ]);
            setAssignments(a);
            setDeliveries(d);
            if (s) setSettings(s);
        } catch (e: any) {
            toast({
                title: 'Error de carga',
                description: 'No se pudieron recuperar las entregas activas.',
                variant: 'destructive'
            });
        } finally {
            setLoading(false);
        }
    }, [toast]);

    const silentRefresh = React.useCallback(async () => {
        setRefreshing(true);
        try {
            const [a, d, s] = await Promise.all([
                getActiveAssignmentsToday(),
                getAssignedDeliveriesToday(),
                getDeliverySettings()
            ]);
            setAssignments(a);
            setDeliveries(d);
            if (s) setSettings(s);
        } catch (e) {
            console.error('Silent refresh failed:', e);
        } finally {
            setRefreshing(false);
        }
    }, []);

    // Auto-polling effect (interactive countdown timer)
    useEffect(() => {
        loadData();
    }, [loadData]);

    useEffect(() => {
        if (refreshIntervalSec === 0) return;

        setSecondsToNextRefresh(refreshIntervalSec);

        const countdownTimer = setInterval(() => {
            setSecondsToNextRefresh((prev) => {
                if (prev <= 1) {
                    silentRefresh();
                    return refreshIntervalSec;
                }
                return prev - 1;
            });
        }, 1000);

        return () => clearInterval(countdownTimer);
    }, [refreshIntervalSec, silentRefresh]);

    // Opens manual delivery contingency modal
    async function handleOpenManualDelivery(doc: any) {
        // Concurrency Warning check
        const isLocked = doc.telegram_lock_at && (new Date().getTime() - new Date(doc.telegram_lock_at).getTime() < 5 * 60 * 1000);
        if (isLocked) {
            if (!confirm(`🚨 ¡ADVERTENCIA DE CONCURRENCIA! 🚨\nUn chofer de Telegram está reportando este pedido actualmente (Bloqueo iniciado hace poco).\n¿Está seguro de forzar el reporte manual desde la web y sobrescribir sus datos?`)) {
                return;
            }
        }

        setSelectedDoc(doc);
        setManualState('completo');
        setManualComment('');
        setReleaseCode('');
        setGeneratedCode('');
        setLineQuantities({});
        setModalLines([]);
        setModalOpen(true);

        if (settings.delivery_mode === 'avanzado') {
            setModalLoading(true);
            try {
                const lines = await getDocumentLines(doc.documento_numero, doc.tipo_documento);
                setModalLines(lines);
                
                // Initialize quantities mapping
                const initialQuantities: Record<string, { entregada: number; faltante: number }> = {};
                for (const line of lines) {
                    initialQuantities[line.linea] = {
                        entregada: line.cantidad,
                        faltante: 0
                    };
                }
                setLineQuantities(initialQuantities);

                // Fetch active release code if any
                const activeCode = await getActiveReleaseCode(doc.id);
                if (activeCode) {
                    setGeneratedCode(activeCode.codigo);
                }
            } catch (e: any) {
                toast({
                    title: 'Error de líneas',
                    description: 'No se pudieron recuperar las líneas del documento ERP.',
                    variant: 'destructive'
                });
            } finally {
                setModalLoading(false);
            }
        }
    }

    function handleQtyChange(lineNum: string, pedida: number, entregadaVal: string) {
        const qtyEntregada = Math.max(0, Math.min(pedida, Number(entregadaVal) || 0));
        const qtyFaltante = pedida - qtyEntregada;
        
        setLineQuantities(prev => ({
            ...prev,
            [lineNum]: {
                entregada: qtyEntregada,
                faltante: qtyFaltante
            }
        }));
    }

    async function handleGenerateCode() {
        if (!selectedDoc) return;
        setGeneratingCode(true);
        try {
            const res = await generateReleaseCode(selectedDoc.id, 'Coordinador Web');
            if (res.success && res.codigo) {
                setGeneratedCode(res.codigo);
                toast({
                    title: 'Código Generado',
                    description: `Código de liberación: ${res.codigo} (Válido por 15 min).`,
                });
            } else {
                throw new Error(res.error);
            }
        } catch (e: any) {
            toast({
                title: 'Error de generación',
                description: e.message,
                variant: 'destructive'
            });
        } finally {
            setGeneratingCode(false);
        }
    }

    async function handleSubmitManualDelivery() {
        if (!selectedDoc) return;

        setModalLoading(true);
        try {
            let processedLines: any[] = [];
            let hasMermas = false;

            if (settings.delivery_mode === 'avanzado') {
                processedLines = modalLines.map(line => {
                    const qty = lineQuantities[line.linea] || { entregada: line.cantidad, faltante: 0 };
                    if (qty.faltante > 0) hasMermas = true;
                    return {
                        codigo: line.articulo,
                        desc: line.descripcion,
                        pedida: line.cantidad,
                        entregada: qty.entregada,
                        faltante: qty.faltante
                    };
                });

                // Validation code logic
                if (hasMermas && settings.release_codes_enabled === 'true') {
                    if (!releaseCode.trim()) {
                        throw new Error('Se requiere digitar un Código de Validación debido a diferencias físicas en la entrega.');
                    }
                    if (releaseCode.trim() !== generatedCode) {
                        throw new Error('El Código de Validación ingresado no es válido o ya expiró.');
                    }
                }
            }

            const stateToSave = settings.delivery_mode === 'avanzado' 
                ? (hasMermas ? 'incompleto' : 'completo')
                : manualState;

            const res = await updateDeliveryStatus(selectedDoc.id, {
                estado: stateToSave,
                comentario: manualComment,
                canal: 'web',
                gestionadoPor: 'Coordinador Web',
                lines: processedLines
            });

            if (res.success) {
                toast({
                    title: 'Entrega registrada',
                    description: 'La entrega manual se guardó y procesó correctamente.',
                });
                setModalOpen(false);
                silentRefresh();
            } else {
                throw new Error(res.error);
            }
        } catch (e: any) {
            toast({
                title: 'Error al reportar',
                description: e.message || 'No se pudo guardar el reporte de entrega.',
                variant: 'destructive'
            });
        } finally {
            setModalLoading(false);
        }
    }

    // UI filters
    const displayedDeliveries = deliveries.filter(d => {
        if (hideDelivered && d.estado === 'completo') return false;
        return true;
    });

    if (loading) {
        return (
            <div className="flex items-center justify-center p-12 bg-card rounded-2xl border border-muted animate-pulse">
                <div className="text-center space-y-4">
                    <RefreshCw className="w-8 h-8 animate-spin mx-auto text-blue-500" />
                    <p className="text-muted-foreground font-medium">Cargando monitor en tiempo real...</p>
                </div>
            </div>
        );
    }

    return (
        <div className={`space-y-6 ${tvMode ? 'bg-slate-950 p-6 rounded-3xl text-slate-100 border border-slate-800' : ''}`}>
            
            {/* Header controls */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div className="space-y-1">
                    <h2 className={`text-xl font-extrabold tracking-tight ${tvMode ? 'text-white' : ''}`}>
                        Trazabilidad Logística en Tiempo Real
                    </h2>
                    <p className={`text-xs font-medium ${tvMode ? 'text-slate-400' : 'text-muted-foreground'}`}>
                        Monitoree la flota en ruta y resuelva incidencias o registre contingencias manuales.
                    </p>
                </div>

                <div className="flex items-center gap-3 flex-wrap">
                    {/* Auto-Refresh Control */}
                    <div className={`flex items-center gap-2 border px-2.5 py-1 rounded-xl text-xs font-bold shadow-sm h-9 ${
                        tvMode 
                            ? 'border-slate-800 bg-slate-900/60 text-slate-300' 
                            : 'border-muted bg-background/50 backdrop-blur text-muted-foreground'
                    }`}>
                        <span className="flex items-center gap-1.5 shrink-0">
                            <RefreshCw className={`w-3.5 h-3.5 ${refreshIntervalSec > 0 ? 'animate-spin text-emerald-500' : (tvMode ? 'text-slate-400' : 'text-muted-foreground')}`} style={{ animationDuration: refreshIntervalSec > 0 ? '3s' : undefined }} />
                            {refreshIntervalSec > 0 ? (
                                <span className="text-[10px] text-emerald-500 font-extrabold animate-pulse">🔴 EN VIVO ({secondsToNextRefresh}s)</span>
                            ) : (
                                <span className="text-[10px] font-extrabold">Refresco</span>
                            )}
                        </span>
                        <Select 
                            value={String(refreshIntervalSec)} 
                            onValueChange={(val) => setRefreshIntervalSec(Number(val))}
                        >
                            <SelectTrigger className={`h-6 w-20 rounded-lg font-bold text-[10px] bg-transparent border-none shadow-none focus:ring-0 p-0 ${
                                tvMode ? 'text-slate-200 hover:text-white' : 'text-foreground'
                            }`}>
                                <SelectValue placeholder="Intervalo" />
                            </SelectTrigger>
                            <SelectContent className={tvMode ? 'bg-slate-900 border-slate-800 text-slate-100' : ''}>
                                <SelectItem value="0">Apagado</SelectItem>
                                <SelectItem value="10">Cada 10s</SelectItem>
                                <SelectItem value="30">Cada 30s</SelectItem>
                                <SelectItem value="60">Cada 1m</SelectItem>
                                <SelectItem value="300">Cada 5m</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    {/* Hide delivered switch toggle */}
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setHideDelivered(!hideDelivered)}
                        className={`rounded-lg font-bold text-xs gap-1.5 border-muted/80 shadow-sm h-9 ${tvMode ? 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white' : ''}`}
                    >
                        <Eye className="w-3.5 h-3.5" />
                        {hideDelivered ? 'Mostrar Completos' : 'Filtrar Mermas/En Ruta'}
                    </Button>

                    {/* TV Mode Toggle Button */}
                    <Button
                        variant={tvMode ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setTvMode(!tvMode)}
                        className={`rounded-lg font-bold text-xs gap-1.5 shadow-sm h-9 ${tvMode ? 'bg-blue-600 hover:bg-blue-700 text-white border-none' : 'border-muted/80'}`}
                    >
                        {tvMode ? <Monitor className="w-3.5 h-3.5" /> : <Tv className="w-3.5 h-3.5" />}
                        {tvMode ? 'Modo Escritorio' : 'Modo TV Despacho'}
                    </Button>

                    <Button
                        variant="ghost"
                        size="sm"
                        onClick={silentRefresh}
                        className={`p-2 rounded-lg h-9 ${tvMode ? 'text-slate-400 hover:bg-slate-900 hover:text-white' : 'text-muted-foreground'}`}
                    >
                        <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
                    </Button>
                </div>
            </div>

            {/* Assignments Matrix */}
            {assignments.length === 0 ? (
                <div className={`text-center p-12 border rounded-2xl text-xs font-semibold shadow-sm ${
                    tvMode ? 'bg-slate-900 border-slate-800 text-slate-400' : 'bg-card text-muted-foreground'
                }`}>
                    No hay camiones ni rutas activas el día de hoy. Configure despachos en &quot;Operación y Despacho&quot;.
                </div>
            ) : (
                <div className={`grid grid-cols-1 ${tvMode ? 'md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3' : 'md:grid-cols-2 lg:grid-cols-3'} gap-6`}>
                    {assignments.map((ass) => {
                        const docsForAss = displayedDeliveries.filter(d => d.asignacion_id === ass.id);
                        
                        // Calculate assignment stats
                        const total = docsForAss.length;
                        const complete = docsForAss.filter(d => d.estado === 'completo').length;
                        const incomplete = docsForAss.filter(d => d.estado === 'incompleto').length;
                        const rejected = docsForAss.filter(d => d.estado === 'rechazado').length;
                        const pending = docsForAss.filter(d => d.estado === 'en_ruta' || d.estado === 'pendiente').length;

                        return (
                            <Card 
                                key={ass.id} 
                                className={`border-none shadow-md overflow-hidden relative flex flex-col ${
                                    tvMode ? 'bg-slate-900/60 border border-slate-800' : 'bg-card'
                                }`}
                            >
                                <div className={`p-4 border-b flex items-start justify-between ${
                                    tvMode ? 'bg-slate-950/40 border-slate-800' : 'bg-muted/40 border-b border-muted/50'
                                }`}>
                                    <div className="space-y-1">
                                        <span className={`text-sm font-black flex items-center gap-1.5 ${tvMode ? 'text-indigo-400' : 'text-indigo-600'}`}>
                                            <MapPin className={`w-4 h-4 ${tvMode ? 'text-indigo-400' : 'text-indigo-500'}`} />
                                            {ass.ruta_nombre}
                                        </span>
                                        <div className={`space-y-0.5 text-xs font-bold ${tvMode ? 'text-slate-300' : 'text-foreground/80'}`}>
                                            <div className="flex items-center gap-1">
                                                <User className={`w-3.5 h-3.5 ${tvMode ? 'text-slate-400' : 'text-muted-foreground'}`} />
                                                {ass.chofer_nombre}
                                            </div>
                                            <div className="flex items-center gap-1">
                                                <Truck className={`w-3.5 h-3.5 ${tvMode ? 'text-slate-400' : 'text-muted-foreground'}`} />
                                                {ass.vehiculo_placa}
                                            </div>
                                        </div>
                                    </div>

                                    {/* Stats Badge chips */}
                                    <div className="flex items-center gap-1 shrink-0">
                                        <Badge className="bg-emerald-500/10 text-emerald-500 border-none text-[10px] font-extrabold px-1.5 py-0">{complete}✓</Badge>
                                        <Badge className="bg-amber-500/10 text-amber-500 border-none text-[10px] font-extrabold px-1.5 py-0">{incomplete}⚠</Badge>
                                        <Badge className="bg-red-500/10 text-red-500 border-none text-[10px] font-extrabold px-1.5 py-0">{rejected}✗</Badge>
                                        <Badge className="bg-blue-500/10 text-blue-500 border-none text-[10px] font-extrabold px-1.5 py-0">{pending}🕒</Badge>
                                    </div>
                                </div>

                                <CardContent className="p-4 flex-1 space-y-3.5">
                                    {docsForAss.length === 0 ? (
                                        <div className={`text-center p-6 text-xs font-semibold italic ${tvMode ? 'text-slate-500' : 'text-muted-foreground'}`}>
                                            Sin pedidos asignados el día de hoy.
                                        </div>
                                    ) : (
                                        <div className="space-y-3">
                                            {docsForAss.map((doc) => {
                                                const isLocked = doc.telegram_lock_at && (new Date().getTime() - new Date(doc.telegram_lock_at).getTime() < 5 * 60 * 1000);
                                                return (
                                                    <div 
                                                        key={doc.id}
                                                        className={`p-3 rounded-xl border flex flex-col gap-2.5 transition-all ${
                                                            isLocked 
                                                                ? 'bg-cyan-500/5 border-cyan-500/30 shadow-md shadow-cyan-500/5' 
                                                                : tvMode 
                                                                    ? 'bg-slate-950 border-slate-800' 
                                                                    : 'bg-muted/10 border-muted/50'
                                                        }`}
                                                    >
                                                        {/* Doc header row */}
                                                        <div className="flex justify-between items-start gap-2">
                                                            <div className="min-w-0">
                                                                <span className={`text-xs font-black font-mono tracking-tight leading-none block ${tvMode ? 'text-slate-100' : 'text-foreground'}`}>
                                                                    {doc.documento_numero}
                                                                </span>
                                                                <p className={`text-[10px] font-bold truncate pt-0.5 ${tvMode ? 'text-slate-300' : 'text-foreground/70'}`}>
                                                                    {doc.cliente_nombre}
                                                                </p>
                                                            </div>

                                                            <div className="flex items-center gap-1.5 shrink-0">
                                                                {/* Blinking indicator for Telegram reporting */}
                                                                {isLocked && (
                                                                    <Badge className="bg-cyan-500 text-white font-extrabold text-[9px] px-1.5 py-0 animate-pulse border-none gap-1 flex items-center">
                                                                        <Lock className="w-2.5 h-2.5" />
                                                                        Chofer reportando...
                                                                    </Badge>
                                                                )}

                                                                <Badge className={`text-[8px] font-extrabold uppercase px-1.5 py-0 border-none ${
                                                                    doc.estado === 'completo' ? 'bg-emerald-500/10 text-emerald-500' :
                                                                    doc.estado === 'incompleto' ? 'bg-amber-500/10 text-amber-500' :
                                                                    doc.estado === 'rechazado' ? 'bg-red-500/10 text-red-500' :
                                                                    'bg-blue-500/10 text-blue-500'
                                                                }`}>
                                                                    {doc.estado}
                                                                </Badge>
                                                            </div>
                                                        </div>

                                                        {/* Document comments / logs if exist */}
                                                        {doc.comentario && (
                                                            <p className={`text-[10px] border rounded px-2 py-1 font-medium italic ${
                                                                tvMode 
                                                                    ? 'bg-slate-950 border-slate-800 text-slate-400' 
                                                                    : 'bg-muted/35 dark:bg-slate-900 border-muted/40 text-muted-foreground'
                                                            }`}>
                                                                &quot;{doc.comentario}&quot;
                                                            </p>
                                                        )}

                                                        {/* Contingency report trigger */}
                                                        {doc.estado !== 'completo' && doc.estado !== 'incompleto' && doc.estado !== 'rechazado' && (
                                                            <Button
                                                                variant="outline"
                                                                size="sm"
                                                                onClick={() => handleOpenManualDelivery(doc)}
                                                                className={`rounded-lg h-7 text-[10px] font-extrabold gap-1 border-muted/80 shadow-sm ${
                                                                    tvMode ? 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white' : ''
                                                                }`}
                                                            >
                                                                <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                                                                Entrega Manual
                                                            </Button>
                                                        )}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        );
                    })}
                </div>
            )}

            {/* Contingency Manual Report Dialog Modal */}
            <Dialog open={modalOpen} onOpenChange={setModalOpen}>
                <DialogContent className="max-w-2xl rounded-2xl bg-card">
                    <DialogHeader>
                        <DialogTitle className="text-lg font-extrabold flex items-center gap-2">
                            <ShieldAlert className="w-5 h-5 text-amber-500" />
                            Registrar Reporte Manual Contingencia
                        </DialogTitle>
                        <DialogDescription className="text-xs">
                            Utilice este formulario únicamente si el chofer no tiene señal, celular descargado o para corregir errores.
                        </DialogDescription>
                    </DialogHeader>

                    {selectedDoc && (
                        <div className="space-y-4 pt-2">
                            {/* Doc short overview */}
                            <div className="grid grid-cols-2 gap-4 p-3 bg-muted/20 border border-muted/50 rounded-xl">
                                <div>
                                    <span className="text-[10px] font-extrabold text-muted-foreground uppercase">Documento</span>
                                    <p className="text-xs font-black font-mono">{selectedDoc.documento_numero} ({selectedDoc.tipo_documento})</p>
                                </div>
                                <div>
                                    <span className="text-[10px] font-extrabold text-muted-foreground uppercase">Cliente</span>
                                    <p className="text-xs font-bold truncate">{selectedDoc.cliente_nombre}</p>
                                </div>
                            </div>

                            {/* Mode validation display */}
                            {settings.delivery_mode === 'sencillo' ? (
                                /* Sencillo Mode Inputs */
                                <div className="space-y-4">
                                    <div className="space-y-2">
                                        <Label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Estado de Entrega</Label>
                                        <RadioGroup 
                                            value={manualState} 
                                            onValueChange={(val: any) => setManualState(val)}
                                            className="grid grid-cols-3 gap-3"
                                        >
                                            <div>
                                                <RadioGroupItem value="completo" id="opt-completo" className="peer sr-only" />
                                                <Label 
                                                    htmlFor="opt-completo" 
                                                    className={`flex flex-col items-center justify-center p-3 border rounded-xl hover:bg-muted/10 cursor-pointer transition-all ${
                                                        manualState === 'completo' ? 'border-emerald-500/50 bg-emerald-500/5 text-emerald-600' : 'border-muted'
                                                    }`}
                                                >
                                                    <CheckCircle className="w-5 h-5 mb-1 text-emerald-500" />
                                                    <span className="text-xs font-extrabold">Completo</span>
                                                </Label>
                                            </div>

                                            <div>
                                                <RadioGroupItem value="incompleto" id="opt-incompleto" className="peer sr-only" />
                                                <Label 
                                                    htmlFor="opt-incompleto" 
                                                    className={`flex flex-col items-center justify-center p-3 border rounded-xl hover:bg-muted/10 cursor-pointer transition-all ${
                                                        manualState === 'incompleto' ? 'border-amber-500/50 bg-amber-500/5 text-amber-600' : 'border-muted'
                                                    }`}
                                                >
                                                    <AlertTriangle className="w-5 h-5 mb-1 text-amber-500" />
                                                    <span className="text-xs font-extrabold">Incompleto</span>
                                                </Label>
                                            </div>

                                            <div>
                                                <RadioGroupItem value="rechazado" id="opt-rechazado" className="peer sr-only" />
                                                <Label 
                                                    htmlFor="opt-rechazado" 
                                                    className={`flex flex-col items-center justify-center p-3 border rounded-xl hover:bg-muted/10 cursor-pointer transition-all ${
                                                        manualState === 'rechazado' ? 'border-red-500/50 bg-red-500/5 text-red-600' : 'border-muted'
                                                    }`}
                                                >
                                                    <XCircle className="w-5 h-5 mb-1 text-red-500" />
                                                    <span className="text-xs font-extrabold">Rechazado</span>
                                                </Label>
                                            </div>
                                        </RadioGroup>
                                    </div>
                                </div>
                            ) : (
                                /* Avanzado Mode Detail Lines Input */
                                <div className="space-y-4">
                                    <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider block">
                                        Desglose Físico por Línea de Producto (ERP)
                                    </span>

                                    {modalLoading ? (
                                        <div className="text-center p-6 space-y-2">
                                            <RefreshCw className="w-5 h-5 animate-spin mx-auto text-blue-500" />
                                            <p className="text-xs text-muted-foreground">Recuperando líneas...</p>
                                        </div>
                                    ) : (
                                        <div className="border border-muted rounded-xl overflow-hidden max-h-[220px] overflow-y-auto">
                                            <table className="w-full text-left text-xs border-collapse">
                                                <thead>
                                                    <tr className="bg-muted/50 text-[10px] font-extrabold uppercase text-muted-foreground border-b border-muted">
                                                        <th className="p-2.5">Código / Descripción</th>
                                                        <th className="p-2.5 text-center w-16">Pedida</th>
                                                        <th className="p-2.5 text-center w-24">Entregada</th>
                                                        <th className="p-2.5 text-center w-16">Faltante</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {modalLines.map((line) => {
                                                        const qty = lineQuantities[line.linea] || { entregada: line.cantidad, faltante: 0 };
                                                        return (
                                                            <tr key={line.linea} className="border-b border-muted/30 hover:bg-muted/10">
                                                                <td className="p-2.5">
                                                                    <div className="font-extrabold text-foreground">{line.articulo}</div>
                                                                    <div className="text-[10px] text-muted-foreground truncate max-w-[280px]">{line.descripcion}</div>
                                                                </td>
                                                                <td className="p-2.5 text-center font-bold text-muted-foreground">{line.cantidad}</td>
                                                                <td className="p-2.5 text-center">
                                                                    <Input
                                                                        type="number"
                                                                        value={qty.entregada}
                                                                        min="0"
                                                                        max={line.cantidad}
                                                                        onChange={(e) => handleQtyChange(line.linea, line.cantidad, e.target.value)}
                                                                        className="h-7 w-16 rounded font-bold text-center p-1 mx-auto text-xs"
                                                                    />
                                                                </td>
                                                                <td className={`p-2.5 text-center font-black ${qty.faltante > 0 ? 'text-red-500' : 'text-muted-foreground/30'}`}>
                                                                    {qty.faltante}
                                                                </td>
                                                            </tr>
                                                        );
                                                    })}
                                                </tbody>
                                            </table>
                                        </div>
                                    )}

                                    {/* Verification Release Codes section */}
                                    {settings.release_codes_enabled === 'true' && (
                                        <div className="p-3 bg-purple-600/5 border border-purple-500/10 rounded-xl space-y-2">
                                            <div className="flex justify-between items-center">
                                                <div className="space-y-0.5">
                                                    <span className="text-xs font-black text-purple-600 flex items-center gap-1">
                                                        <Key className="w-3.5 h-3.5" />
                                                        Código de Validación Requerido
                                                    </span>
                                                    <p className="text-[10px] text-muted-foreground font-semibold">
                                                        Se detectan mermas físicas. El despachador debe dictar un código de validación.
                                                    </p>
                                                </div>

                                                <Button
                                                    onClick={handleGenerateCode}
                                                    disabled={generatingCode}
                                                    size="sm"
                                                    className="h-7 text-[10px] bg-purple-600 hover:bg-purple-700 text-white rounded font-extrabold gap-1"
                                                >
                                                    {generatingCode ? 'Generando...' : 'Generar Código'}
                                                </Button>
                                            </div>

                                            {generatedCode && (
                                                <div className="flex items-center justify-between bg-purple-500/10 border border-purple-500/20 p-2 rounded-lg">
                                                    <span className="text-[10px] text-purple-600 font-extrabold uppercase">Código a dictar:</span>
                                                    <span className="text-sm font-black text-purple-700 tracking-widest">{generatedCode}</span>
                                                </div>
                                            )}

                                            <div className="space-y-1 pt-1">
                                                <Label className="text-[10px] font-extrabold text-muted-foreground uppercase">Ingrese el Código para Validar:</Label>
                                                <Input
                                                    placeholder="XXXXXX"
                                                    value={releaseCode}
                                                    onChange={(e) => setReleaseCode(e.target.value)}
                                                    className="rounded-lg text-center font-bold tracking-widest h-8 text-sm max-w-[120px] mx-auto"
                                                />
                                            </div>
                                        </div>
                                    )}
                                </div>
                            )}

                            {/* Observations comments */}
                            <div className="space-y-1.5">
                                <Label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Comentarios y Observaciones</Label>
                                <Input
                                    placeholder="Digite motivo de merma, rechazo u observaciones logísticas..."
                                    value={manualComment}
                                    onChange={(e) => setManualComment(e.target.value)}
                                    className="rounded-lg text-xs font-semibold"
                                />
                            </div>
                        </div>
                    )}

                    <DialogFooter className="bg-muted/10 p-4 border-t border-muted/30 flex gap-2">
                        <Button 
                            variant="ghost" 
                            onClick={() => setModalOpen(false)}
                            className="rounded-lg font-bold text-xs"
                        >
                            Cancelar
                        </Button>
                        <Button 
                            onClick={handleSubmitManualDelivery}
                            disabled={modalLoading || (settings.delivery_mode === 'avanzado' && modalLines.length === 0)}
                            className="rounded-lg font-bold text-xs gap-1.5 bg-blue-600 hover:bg-blue-700 text-white shadow"
                        >
                            <Check className="w-4 h-4" />
                            Confirmar Entrega
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
