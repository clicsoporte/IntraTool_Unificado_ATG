'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Truck, LayoutDashboard, CalendarRange, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function DeliveriesLayout({ children }: { children: React.ReactNode }) {
    const pathname = usePathname();

    const tabs = [
        {
            href: '/dashboard/operations/deliveries',
            label: 'Dashboard Realtime',
            icon: LayoutDashboard,
            active: pathname === '/dashboard/operations/deliveries'
        },
        {
            href: '/dashboard/operations/deliveries/operation',
            label: 'Operación y Despacho',
            icon: CalendarRange,
            active: pathname === '/dashboard/operations/deliveries/operation'
        },
        {
            href: '/dashboard/admin/operations',
            label: 'Configuración',
            icon: Settings,
            active: pathname === '/dashboard/admin/operations'
        }
    ];

    return (
        <main className="flex-1 p-4 md:p-6 lg:p-8 animate-in fade-in duration-500">
            <div className="mx-auto max-w-7xl space-y-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-4 border-b border-muted">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-blue-600 rounded-2xl text-white shadow-lg shadow-blue-100 dark:shadow-none">
                            <Truck className="w-8 h-8" />
                        </div>
                        <div>
                            <h1 className="text-3xl font-extrabold tracking-tight">Monitor de Entregas v2.1</h1>
                            <p className="text-muted-foreground font-medium">Control omnicanal, concurrencia en tiempo real y asignación de rutas.</p>
                        </div>
                    </div>

                    <div className="flex items-center gap-2 bg-muted/50 p-1 rounded-xl">
                        {tabs.map((tab) => (
                            <Link key={tab.href} href={tab.href}>
                                <Button
                                    variant={tab.active ? 'default' : 'ghost'}
                                    className="rounded-lg gap-2 text-xs font-bold transition-all"
                                    size="sm"
                                >
                                    <tab.icon className="w-4 h-4" />
                                    {tab.label}
                                </Button>
                            </Link>
                        ))}
                    </div>
                </div>

                <div className="w-full">
                    {children}
                </div>
            </div>
        </main>
    );
}
