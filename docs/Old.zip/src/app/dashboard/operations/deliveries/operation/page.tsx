'use client';

import React, { useState, useEffect } from 'react';
import { useToast } from '@/modules/core/hooks/use-toast';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { 
    Select, 
    SelectContent, 
    SelectItem, 
    SelectTrigger, 
    SelectValue 
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { 
    RefreshCw, 
    User, 
    Truck, 
    Route, 
    Plus, 
    MapPin, 
    Send, 
    XOctagon, 
    ArrowRightLeft, 
    ChevronRight,
    Users,
    Search
} from 'lucide-react';
import {
    getGeneralQueue,
    getAssignedDeliveriesToday,
    getActiveAssignmentsToday,
    getDrivers,
    getVehicles,
    getDeliveryRoutes,
    createAssignment,
    closeAssignment,
    assignDocumentsToRoute,
    reassignDocument,
    populateDeliveryQueueFromERP,
    autoRouteQueueToday,
    unlockDocumentTelegram
} from '@/modules/operations/lib/actions';

export default function OperationDispatchPage() {
    const { toast } = useToast();
    const [loading, setLoading] = useState(true);
    const [syncingERP, setSyncingERP] = useState(false);
    const [autoRouting, setAutoRouting] = useState(false);
    const [creatingAssignment, setCreatingAssignment] = useState(false);

    // Backend state
    const [queue, setQueue] = useState<any[]>([]);
    const [assignedDocs, setAssignedDocs] = useState<any[]>([]);
    const [assignments, setAssignments] = useState<any[]>([]);
    const [drivers, setDrivers] = useState<any[]>([]);
    const [vehicles, setVehicles] = useState<any[]>([]);
    const [routes, setRoutes] = useState<any[]>([]);

    // Form inputs
    const [selectedRoute, setSelectedRoute] = useState<string>('');
    const [selectedDriver, setSelectedDriver] = useState<string>('');
    const [selectedVehicle, setSelectedVehicle] = useState<string>('');

    // Selection & filter state
    const [selectedDocIds, setSelectedDocIds] = useState<number[]>([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [destinationAssignment, setDestinationAssignment] = useState<string>('');
    const [refreshIntervalSec, setRefreshIntervalSec] = useState<number>(30); // Default 30s
    const [secondsToNextRefresh, setSecondsToNextRefresh] = useState<number>(30);

    // Sync Date Slicing States (v2.3)
    const [syncFilterType, setSyncFilterType] = useState<'none' | 'days' | 'range'>('days');
    const [syncLookbackDays, setSyncLookbackDays] = useState<number>(5);
    const [syncStartDate, setSyncStartDate] = useState<string>('');
    const [syncEndDate, setSyncEndDate] = useState<string>('');
    const [omitCreditNotes, setOmitCreditNotes] = useState<boolean>(true);


    // Silent background refresh
    const backgroundRefresh = React.useCallback(async () => {
        try {
            const [q, ad, a, d, v, r] = await Promise.all([
                getGeneralQueue(),
                getAssignedDeliveriesToday(),
                getActiveAssignmentsToday(),
                getDrivers(),
                getVehicles(),
                getDeliveryRoutes()
            ]);
            setQueue(q);
            setAssignedDocs(ad);
            setAssignments(a);
            setDrivers(d);
            setVehicles(v);
            setRoutes(r.filter(route => route.active === 1));
        } catch (e) {
            console.error('Silent background refresh failed:', e);
        }
    }, []);

    useEffect(() => {
        async function loadData() {
            setLoading(true);
            try {
                await backgroundRefresh();
            } catch (e: any) {
                toast({
                    title: 'Error de carga',
                    description: 'No se pudieron recuperar los datos operativos.',
                    variant: 'destructive'
                });
            } finally {
                setLoading(false);
            }
        }
        loadData();
    }, [toast, backgroundRefresh]);

    // Timer effect for Auto-Refresh countdown
    useEffect(() => {
        if (refreshIntervalSec === 0) return;

        setSecondsToNextRefresh(refreshIntervalSec);

        const countdownTimer = setInterval(() => {
            setSecondsToNextRefresh((prev) => {
                if (prev <= 1) {
                    backgroundRefresh();
                    return refreshIntervalSec;
                }
                return prev - 1;
            });
        }, 1000);

        return () => clearInterval(countdownTimer);
    }, [refreshIntervalSec, backgroundRefresh]);

    async function handleSyncERP() {
        setSyncingERP(true);
        try {
            // Build options based on selected filter type
            let options: any = { excludeCreditNotes: omitCreditNotes };
            if (syncFilterType === 'days') {
                options.daysLookback = syncLookbackDays;
            } else if (syncFilterType === 'range') {
                options.startDate = syncStartDate || null;
                options.endDate = syncEndDate || null;
            }

            const res = await populateDeliveryQueueFromERP(options);
            if (res.success) {
                toast({
                    title: 'ERP Sincronizado',
                    description: `Se han importado ${res.count} nuevos documentos desde el ERP a la cola de entregas.`,
                });
                const [q, ad] = await Promise.all([getGeneralQueue(), getAssignedDeliveriesToday()]);
                setQueue(q);
                setAssignedDocs(ad);
            } else {
                throw new Error(res.error);
            }
        } catch (e: any) {
            toast({
                title: 'Error de sincronización',
                description: e.message,
                variant: 'destructive'
            });
        } finally {
            setSyncingERP(false);
        }
    }

    async function handleAutoRoute() {
        setAutoRouting(true);
        try {
            const res = await autoRouteQueueToday();
            if (res.success) {
                toast({
                    title: 'Auto-Ruteo completado',
                    description: `Se auto-asignaron ${res.count} documentos basándose en la RUTA del ERP.`,
                });
                const [q, ad] = await Promise.all([getGeneralQueue(), getAssignedDeliveriesToday()]);
                setQueue(q);
                setAssignedDocs(ad);
            } else {
                throw new Error(res.error);
            }
        } catch (e: any) {
            toast({
                title: 'Error de Auto-Ruteo',
                description: e.message,
                variant: 'destructive'
            });
        } finally {
            setAutoRouting(false);
        }
    }

    async function handleCreateAssignment(e: React.FormEvent) {
        e.preventDefault();
        if (!selectedRoute || !selectedDriver || !selectedVehicle) {
            toast({
                title: 'Formulario incompleto',
                description: 'Por favor complete la ruta, el chofer y el vehículo.',
                variant: 'warning'
            } as any);
            return;
        }

        setCreatingAssignment(true);
        try {
            const res = await createAssignment(
                Number(selectedRoute),
                Number(selectedDriver),
                Number(selectedVehicle)
            );
            if (res.success) {
                toast({
                    title: 'Asignación creada',
                    description: 'La ruta ya está disponible para asociar entregas.',
                });
                setSelectedRoute('');
                setSelectedDriver('');
                setSelectedVehicle('');
                const [a, d, v] = await Promise.all([
                    getActiveAssignmentsToday(),
                    getDrivers(),
                    getVehicles()
                ]);
                setAssignments(a);
                setDrivers(d);
                setVehicles(v);
            } else {
                throw new Error(res.error);
            }
        } catch (e: any) {
            toast({
                title: 'Error al asignar',
                description: e.message,
                variant: 'destructive'
            });
        } finally {
            setCreatingAssignment(false);
        }
    }

    async function handleCloseAssignment(assignmentId: number) {
        if (!confirm('¿Está seguro de forzar el cierre de esta ruta? Las entregas no gestionadas volverán a la cola general.')) return;
        try {
            const res = await closeAssignment(assignmentId, 'Coordinador Web');
            if (res.success) {
                toast({
                    title: 'Ruta cerrada',
                    description: 'La ruta y camión han sido liberados y las entregas regresaron a cola.',
                });
                const [q, ad, a] = await Promise.all([
                    getGeneralQueue(),
                    getAssignedDeliveriesToday(),
                    getActiveAssignmentsToday()
                ]);
                setQueue(q);
                setAssignedDocs(ad);
                setAssignments(a);
            } else {
                throw new Error(res.error);
            }
        } catch (e: any) {
            toast({
                title: 'Error de cierre',
                description: e.message,
                variant: 'destructive'
            });
        }
    }

    async function handleAssignSelected() {
        if (selectedDocIds.length === 0 || !destinationAssignment) return;

        try {
            const res = await assignDocumentsToRoute(selectedDocIds, Number(destinationAssignment));
            if (res.success) {
                toast({
                    title: 'Entregas asignadas',
                    description: `Se asignaron ${selectedDocIds.length} documentos a la ruta seleccionada.`,
                });
                setSelectedDocIds([]);
                setDestinationAssignment('');
                const [q, ad] = await Promise.all([getGeneralQueue(), getAssignedDeliveriesToday()]);
                setQueue(q);
                setAssignedDocs(ad);
            } else {
                throw new Error(res.error);
            }
        } catch (e: any) {
            toast({
                title: 'Error al asociar',
                description: e.message,
                variant: 'destructive'
            });
        }
    }

    async function handleReassign(docId: number, newAssignmentId: number) {
        try {
            const res = await reassignDocument(docId, newAssignmentId);
            if (res.success) {
                toast({
                    title: 'Pedido reasignado',
                    description: 'Se ha cambiado de ruta el pedido con éxito.',
                });
                const ad = await getAssignedDeliveriesToday();
                setAssignedDocs(ad);
            } else {
                throw new Error(res.error);
            }
        } catch (e: any) {
            toast({
                title: 'Error al reasignar',
                description: e.message,
                variant: 'destructive'
            });
        }
    }

    const filteredQueue = queue.filter(doc => {
        if (omitCreditNotes && doc.tipo_documento_erp === 'D') {
            return false;
        }
        return (
            doc.documento_numero.toLowerCase().includes(searchQuery.toLowerCase()) ||
            doc.cliente_nombre.toLowerCase().includes(searchQuery.toLowerCase()) ||
            doc.cliente_id.toLowerCase().includes(searchQuery.toLowerCase())
        );
    });

    const displayedQueue = filteredQueue.slice(0, 100);

    if (loading) {
        return (
            <div className="flex items-center justify-center p-12 bg-card rounded-2xl border border-muted animate-pulse">
                <div className="text-center space-y-4">
                    <RefreshCw className="w-8 h-8 animate-spin mx-auto text-blue-500" />
                    <p className="text-muted-foreground font-medium">Cargando despacho operativo...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Sync & Automations Panel */}
            <div className="p-5 bg-blue-600/5 dark:bg-blue-500/5 rounded-2xl border border-blue-500/10 space-y-4 shadow-sm">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                        <h3 className="text-sm font-extrabold flex items-center gap-2 text-foreground">
                            <Users className="w-4 h-4 text-blue-600" />
                            Acciones de Sincronización ERP y Cola
                        </h3>
                        <p className="text-xs text-muted-foreground font-medium">
                            Importe pedidos del ERP o ejecute el ruteo automático basado en parámetros del sistema.
                        </p>
                    </div>
                    <div className="flex flex-wrap items-center gap-2.5">
                        {/* Auto-Refresh Control */}
                        <div className="flex items-center gap-2 border border-muted bg-background/50 dark:bg-muted/10 backdrop-blur px-2.5 py-1 rounded-xl text-xs font-bold shadow-sm h-9">
                            <span className="flex items-center gap-1.5 text-muted-foreground">
                                <RefreshCw className={`w-3 h-3 ${refreshIntervalSec > 0 ? 'animate-spin text-emerald-500' : 'text-muted-foreground'}`} style={{ animationDuration: refreshIntervalSec > 0 ? '3s' : undefined }} />
                                {refreshIntervalSec > 0 ? (
                                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-extrabold animate-pulse">🔴 EN VIVO ({secondsToNextRefresh}s)</span>
                                ) : (
                                    <span className="text-[10px] text-muted-foreground font-extrabold">Refresco</span>
                                )}
                            </span>
                            <Select 
                                value={String(refreshIntervalSec)} 
                                onValueChange={(val) => setRefreshIntervalSec(Number(val))}
                            >
                                <SelectTrigger className="h-6 w-20 rounded-lg font-bold text-[10px] bg-transparent border-none shadow-none focus:ring-0 p-0 text-foreground">
                                    <SelectValue placeholder="Intervalo" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="0">Apagado</SelectItem>
                                    <SelectItem value="10">Cada 10s</SelectItem>
                                    <SelectItem value="30">Cada 30s</SelectItem>
                                    <SelectItem value="60">Cada 1m</SelectItem>
                                    <SelectItem value="300">Cada 5m</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <Button
                            variant="outline"
                            size="sm"
                            disabled={syncingERP}
                            onClick={handleSyncERP}
                            className="rounded-lg font-bold gap-2 text-xs border-muted/80 shadow-sm"
                        >
                            <RefreshCw className={`w-3.5 h-3.5 ${syncingERP ? 'animate-spin' : ''}`} />
                            {syncingERP ? 'Sincronizando...' : 'Sincronizar ERP'}
                        </Button>
                        
                        <Button
                            variant="default"
                            size="sm"
                            disabled={autoRouting || assignments.length === 0}
                            onClick={handleAutoRoute}
                            className="rounded-lg font-bold gap-2 text-xs bg-blue-600 hover:bg-blue-700 shadow-md shadow-blue-100 dark:shadow-none"
                        >
                            <Send className="w-3.5 h-3.5" />
                            {autoRouting ? 'Procesando...' : 'Auto-Ruteo ERP'}
                        </Button>
                    </div>
                </div>

                <Separator className="border-blue-500/10" />

                {/* Filter configurations (v2.3) */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center pt-1 text-xs">
                    <div className="md:col-span-3 space-y-1">
                        <span className="font-extrabold text-foreground/90 uppercase tracking-wider text-[10px]">Filtro de Sincronización</span>
                        <Select 
                            value={syncFilterType} 
                            onValueChange={(val: any) => setSyncFilterType(val)}
                        >
                            <SelectTrigger className="h-8 rounded-lg font-bold text-xs bg-background">
                                <SelectValue placeholder="Tipo de Filtro" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="none">Sin filtro (Importar Todo)</SelectItem>
                                <SelectItem value="days">Por días relativos</SelectItem>
                                <SelectItem value="range">Por rango de fechas</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    {syncFilterType === 'days' && (
                        <div className="md:col-span-9 space-y-1">
                            <span className="font-extrabold text-foreground/90 uppercase tracking-wider text-[10px]">Rango de Días Relativos</span>
                            <div className="flex flex-wrap gap-1.5 pt-0.5">
                                {[
                                    { label: 'Solo Hoy', val: 0 },
                                    { label: 'Último 1 día', val: 1 },
                                    { label: 'Últimos 2 días', val: 2 },
                                    { label: 'Últimos 3 días', val: 3 },
                                    { label: 'Últimos 4 días', val: 4 },
                                    { label: 'Últimos 5 días', val: 5 }
                                ].map((opt) => (
                                    <Button
                                        key={opt.val}
                                        type="button"
                                        variant={syncLookbackDays === opt.val ? 'default' : 'outline'}
                                        onClick={() => setSyncLookbackDays(opt.val)}
                                        className={`h-7 px-2.5 rounded-lg text-[10px] font-bold ${
                                            syncLookbackDays === opt.val 
                                                ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                                                : 'bg-background hover:bg-muted/10'
                                        }`}
                                    >
                                        {opt.label}
                                    </Button>
                                ))}
                            </div>
                        </div>
                    )}

                    {syncFilterType === 'range' && (
                        <div className="md:col-span-9 flex flex-col sm:flex-row gap-3 items-end">
                            <div className="flex-1 space-y-1 w-full">
                                <span className="font-extrabold text-foreground/90 uppercase tracking-wider text-[10px]">Fecha Inicio</span>
                                <Input
                                    type="date"
                                    value={syncStartDate}
                                    onChange={(e) => setSyncStartDate(e.target.value)}
                                    className="h-8 rounded-lg font-bold text-xs bg-background w-full"
                                />
                            </div>
                            <div className="flex-1 space-y-1 w-full">
                                <span className="font-extrabold text-foreground/90 uppercase tracking-wider text-[10px]">Fecha Fin</span>
                                <Input
                                    type="date"
                                    value={syncEndDate}
                                    onChange={(e) => setSyncEndDate(e.target.value)}
                                    className="h-8 rounded-lg font-bold text-xs bg-background w-full"
                                />
                            </div>
                        </div>
                    )}

                    {syncFilterType === 'none' && (
                        <div className="md:col-span-9 text-muted-foreground text-xs italic font-medium pt-3 sm:pt-0">
                            💡 Al sincronizar sin filtro, se analizará todo el historial activo del ERP. Esto puede demorar unos minutos y consumir más recursos en bases de datos masivas.
                        </div>
                    )}
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* General Queue Left Column */}
                <div className="lg:col-span-1 space-y-6">
                    <Card className="border-none shadow-md bg-card flex flex-col h-[750px]">
                        <CardHeader className="pb-4">
                            <CardTitle className="text-lg flex items-center justify-between">
                                <span>Cola General de Pendientes</span>
                                <Badge className="bg-muted text-muted-foreground border-none font-bold">
                                    {filteredQueue.length}
                                </Badge>
                            </CardTitle>
                            <CardDescription>
                                Pedidos y facturas importadas del ERP que están a la espera de camión y chofer.
                            </CardDescription>

                            <div className="relative pt-2">
                                <Search className="w-4 h-4 text-muted-foreground absolute left-3 top-5" />
                                <Input
                                    placeholder="Buscar documento o cliente..."
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    className="pl-9 rounded-lg font-bold text-xs"
                                />
                            </div>

                            <div className="flex items-center gap-2 pt-2 px-1">
                                <Checkbox
                                    id="omit-credit-notes"
                                    checked={omitCreditNotes}
                                    onCheckedChange={(checked) => setOmitCreditNotes(!!checked)}
                                />
                                <Label 
                                    htmlFor="omit-credit-notes" 
                                    className="text-[11px] font-extrabold text-muted-foreground cursor-pointer select-none leading-none"
                                >
                                    Omitir Notas de Crédito / Devoluciones (D)
                                </Label>
                            </div>
                        </CardHeader>

                        {/* Queue Documents list */}
                        <CardContent className="flex-1 overflow-y-auto space-y-2.5 pb-4">
                            {filteredQueue.length > 100 && (
                                <div className="p-3 bg-amber-500/10 text-amber-600 rounded-xl text-center text-[10px] font-black border border-amber-500/20 leading-snug mb-1">
                                    ⚠️ Mostrando primeros 100 de {filteredQueue.length} documentos. Utilice la barra de búsqueda para filtrar la lista.
                                </div>
                            )}

                            {displayedQueue.length === 0 ? (
                                <div className="text-center p-8 bg-muted/10 rounded-xl border border-dashed text-xs text-muted-foreground font-semibold">
                                    No hay documentos en la cola.
                                </div>
                            ) : (
                                displayedQueue.map((doc) => {
                                    const isSelected = selectedDocIds.includes(doc.id);
                                    const isReturn = doc.tipo_documento_erp === 'D';
                                    return (
                                        <div 
                                            key={doc.id}
                                            className={`flex items-start gap-3 p-3 border rounded-xl transition-colors ${
                                                isReturn 
                                                    ? 'border-red-200/50 bg-red-500/5 dark:bg-red-950/10 opacity-90' 
                                                    : isSelected 
                                                        ? 'border-blue-500/50 bg-blue-500/5' 
                                                        : 'border-muted/50 hover:bg-muted/30'
                                            }`}
                                        >
                                            <Checkbox
                                                checked={isSelected}
                                                disabled={isReturn}
                                                onCheckedChange={(checked) => {
                                                    if (isReturn) return;
                                                    setSelectedDocIds(prev => 
                                                        checked 
                                                            ? [...prev, doc.id] 
                                                            : prev.filter(id => id !== doc.id)
                                                    );
                                                }}
                                                className="mt-0.5"
                                            />
                                            <div className="flex-1 min-w-0 space-y-1">
                                                <div className="flex items-center justify-between gap-2">
                                                    <span className="text-xs font-black font-mono leading-none tracking-tight">{doc.documento_numero}</span>
                                                    <div className="flex items-center gap-1 shrink-0">
                                                        {isReturn ? (
                                                            <Badge className="text-[9px] font-extrabold px-1.5 py-0 border-none bg-red-500/10 text-red-600 dark:bg-red-500/20">
                                                                Nota de Crédito ↩️
                                                            </Badge>
                                                        ) : (
                                                            <Badge className={`text-[9px] font-extrabold uppercase px-1.5 py-0 border-none ${doc.tipo_documento === 'factura' ? 'bg-indigo-500/10 text-indigo-600' : 'bg-amber-500/10 text-amber-600'}`}>
                                                                {doc.tipo_documento}
                                                            </Badge>
                                                        )}
                                                    </div>
                                                </div>
                                                <p className="text-xs font-bold truncate text-foreground/80">{doc.cliente_nombre}</p>
                                                
                                                {isReturn && doc.factura_original && (
                                                    <div className="pt-0.5">
                                                        <span className="text-[9px] font-extrabold text-red-600 dark:text-red-400 bg-red-500/10 dark:bg-red-500/20 px-2 py-0.5 rounded border border-red-500/20">
                                                            Ref: Fac {doc.factura_original}
                                                        </span>
                                                    </div>
                                                )}

                                                <div className="flex items-center justify-between text-[10px] text-muted-foreground font-bold pt-1">
                                                    <span>ERP: {doc.creado_por}</span>
                                                    <span>{doc.fecha_registro}</span>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })
                            )}
                        </CardContent>

                        {/* Batch assign trigger */}
                        {selectedDocIds.length > 0 && (
                            <div className="p-4 bg-muted/40 border-t border-muted/50 space-y-3 rounded-b-2xl">
                                <div className="flex items-center justify-between">
                                    <span className="text-xs font-black text-blue-600">
                                        {selectedDocIds.length} seleccionados
                                    </span>
                                </div>
                                <div className="flex gap-2">
                                    <Select 
                                        value={destinationAssignment} 
                                        onValueChange={setDestinationAssignment}
                                    >
                                        <SelectTrigger className="rounded-lg font-bold text-xs h-9 flex-1">
                                            <SelectValue placeholder="Asignar a..." />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {assignments.length === 0 ? (
                                                <SelectItem disabled value="none">No hay rutas activas hoy (cree una a la derecha)</SelectItem>
                                            ) : (
                                                assignments.map((ass) => (
                                                    <SelectItem key={ass.id} value={String(ass.id)}>
                                                        {ass.ruta_nombre} - {ass.vehiculo_placa} ({ass.chofer_nombre})
                                                    </SelectItem>
                                                ))
                                            )}
                                        </SelectContent>
                                    </Select>
                                    
                                    <Button
                                        onClick={handleAssignSelected}
                                        disabled={!destinationAssignment}
                                        className="h-9 rounded-lg font-black text-xs px-3 shadow"
                                    >
                                        Asignar
                                    </Button>
                                </div>
                            </div>
                        )}
                    </Card>
                </div>

                {/* Assignments & Dispatch Right Column */}
                <div className="lg:col-span-2 space-y-6">
                    {/* Create Assignment Form */}
                    <Card className="border-none shadow-md bg-card">
                        <CardHeader className="pb-3">
                            <CardTitle className="text-lg flex items-center gap-2">
                                <Plus className="w-5 h-5 text-blue-600" />
                                Nueva Asignación Diaria (Despacho)
                            </CardTitle>
                            <CardDescription>
                                Asocie una ruta logística a un chofer de Telegram y su vehículo para el día de hoy.
                            </CardDescription>
                        </CardHeader>
                        
                        <CardContent>
                            <form onSubmit={handleCreateAssignment} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                                <div className="space-y-1.5">
                                    <Label className="text-xs font-bold text-muted-foreground">Ruta Logística</Label>
                                    <Select value={selectedRoute} onValueChange={setSelectedRoute}>
                                        <SelectTrigger className="rounded-lg font-bold text-xs">
                                            <SelectValue placeholder="Seleccione ruta" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {routes.map(r => (
                                                <SelectItem key={r.id} value={String(r.id)}>{r.name}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>

                                <div className="space-y-1.5">
                                    <Label className="text-xs font-bold text-muted-foreground">Chofer (Telegram)</Label>
                                    <Select value={selectedDriver} onValueChange={setSelectedDriver}>
                                        <SelectTrigger className="rounded-lg font-bold text-xs">
                                            <SelectValue placeholder="Seleccione chofer" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {drivers.map(d => (
                                                <SelectItem key={d.id} value={String(d.id)}>{d.name}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>

                                <div className="space-y-1.5">
                                    <Label className="text-xs font-bold text-muted-foreground">Vehículo (Placa)</Label>
                                    <Select value={selectedVehicle} onValueChange={setSelectedVehicle}>
                                        <SelectTrigger className="rounded-lg font-bold text-xs">
                                            <SelectValue placeholder="Seleccione camión" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {vehicles.map(v => (
                                                <SelectItem key={v.id} value={String(v.id)}>
                                                    {v.plate} ({v.brand} {v.model})
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>

                                <Button 
                                    type="submit" 
                                    disabled={creatingAssignment}
                                    className="rounded-lg font-bold text-xs gap-2 h-10 w-full"
                                >
                                    <Plus className="w-4 h-4" />
                                    Crear Asignación
                                </Button>
                            </form>
                        </CardContent>
                    </Card>

                    {/* Active Daily Assignments and Documents inside them */}
                    <div className="space-y-4">
                        <h3 className="text-md font-extrabold flex items-center gap-2">
                            <Route className="w-5 h-5 text-indigo-600" />
                            Rutas y Asignaciones Activas para Hoy
                        </h3>
                        
                        {assignments.length === 0 ? (
                            <div className="text-center p-12 bg-card border rounded-2xl text-xs text-muted-foreground font-semibold shadow-sm">
                                No se han creado asignaciones para hoy. Registre una arriba para iniciar.
                            </div>
                        ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {assignments.map((ass) => {
                                    const docsForAss = assignedDocs.filter(d => d.asignacion_id === ass.id);
                                    return (
                                        <Card key={ass.id} className="border-none shadow-md bg-card overflow-hidden">
                                            <div className="p-4 bg-muted/40 border-b border-muted/50 flex items-start justify-between">
                                                <div className="space-y-1">
                                                    <span className="text-sm font-black text-indigo-600 flex items-center gap-1.5">
                                                        <MapPin className="w-4 h-4" />
                                                        {ass.ruta_nombre}
                                                    </span>
                                                    <div className="space-y-0.5 text-xs text-foreground/80 font-bold">
                                                        <div className="flex items-center gap-1">
                                                            <User className="w-3.5 h-3.5 text-muted-foreground" />
                                                            {ass.chofer_nombre}
                                                        </div>
                                                        <div className="flex items-center gap-1">
                                                            <Truck className="w-3.5 h-3.5 text-muted-foreground" />
                                                            {ass.vehiculo_placa}
                                                        </div>
                                                    </div>
                                                </div>

                                                <Button
                                                    variant="outline"
                                                    size="sm"
                                                    onClick={() => handleCloseAssignment(ass.id)}
                                                    className="rounded-lg h-7 px-2 text-[10px] font-black border-red-500/20 text-red-600 hover:bg-red-500/10 hover:text-red-700 bg-red-500/5 transition-colors gap-1 shrink-0"
                                                >
                                                    <XOctagon className="w-3.5 h-3.5" />
                                                    Forzar Cierre
                                                </Button>
                                            </div>

                                            <CardContent className="p-4 space-y-2">
                                                <span className="text-[10px] font-extrabold text-muted-foreground uppercase tracking-wider block">
                                                    Entregas en esta Ruta ({docsForAss.length})
                                                </span>

                                                {docsForAss.length === 0 ? (
                                                    <p className="text-xs text-muted-foreground font-semibold italic p-3 text-center bg-muted/10 border border-dashed rounded-xl">
                                                        Sin entregas asignadas aún.
                                                    </p>
                                                ) : (
                                                    <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                                                        {docsForAss.map((doc) => (
                                                            <div 
                                                                key={doc.id}
                                                                className="flex items-center justify-between p-2.5 bg-muted/20 border border-muted/50 rounded-xl hover:bg-muted/30 transition-colors gap-3"
                                                            >
                                                                <div className="min-w-0 flex-1">
                                                                    <div className="flex items-center gap-1.5 flex-wrap">
                                                                        <span className="text-xs font-black font-mono leading-none">{doc.documento_numero}</span>
                                                                        <Badge className={`text-[8px] font-extrabold uppercase px-1 py-0.5 border-none ${
                                                                            doc.estado === 'completo' ? 'bg-emerald-500/10 text-emerald-600' :
                                                                            doc.estado === 'incompleto' ? 'bg-amber-500/10 text-amber-600' :
                                                                            doc.estado === 'rechazado' ? 'bg-red-500/10 text-red-600' :
                                                                            'bg-blue-500/10 text-blue-600'
                                                                        }`}>
                                                                            {doc.estado}
                                                                        </Badge>
                                                                        
                                                                        {doc.telegram_lock_at && (
                                                                            <Badge className="text-[8px] font-extrabold px-1 py-0.5 border-none bg-amber-500/15 text-amber-600 dark:bg-amber-500/25 flex items-center gap-0.5 animate-pulse">
                                                                                🔒 Telegram
                                                                            </Badge>
                                                                        )}
                                                                    </div>
                                                                    <p className="text-[10px] font-bold text-foreground/80 truncate pt-0.5">{doc.cliente_nombre}</p>
                                                                </div>

                                                                <div className="flex items-center gap-1.5 shrink-0">
                                                                    {doc.telegram_lock_at && (
                                                                        <Button
                                                                            size="sm"
                                                                            variant="outline"
                                                                            title="Desbloquear de Telegram"
                                                                            onClick={async () => {
                                                                                if (confirm(`¿Desbloquear pedido ${doc.documento_numero} de Telegram?`)) {
                                                                                    const res = await unlockDocumentTelegram(doc.id);
                                                                                    if (res.success) {
                                                                                        toast({ title: 'Pedido desbloqueado', description: 'El candado de Telegram ha sido removido.' });
                                                                                        const [q, ad] = await Promise.all([getGeneralQueue(), getAssignedDeliveriesToday()]);
                                                                                        setQueue(q);
                                                                                        setAssignedDocs(ad);
                                                                                    } else {
                                                                                        toast({ title: 'Error al desbloquear', description: res.error, variant: 'destructive' });
                                                                                    }
                                                                                }
                                                                            }}
                                                                            className="w-7 h-7 p-0 rounded-lg border-amber-500/20 bg-amber-500/5 hover:bg-amber-500/10 text-amber-600 transition-colors"
                                                                        >
                                                                            🔒
                                                                        </Button>
                                                                    )}

                                                                    {/* Reassign direct dropdown */}
                                                                    <Select 
                                                                        onValueChange={(val) => handleReassign(doc.id, Number(val))}
                                                                    >
                                                                        <SelectTrigger className="w-9 h-7 p-0 rounded-lg border-muted/80 bg-background flex items-center justify-center">
                                                                            <ArrowRightLeft className="w-3.5 h-3.5 text-muted-foreground" />
                                                                        </SelectTrigger>
                                                                        <SelectContent>
                                                                            {assignments.filter(a => a.id !== ass.id).map((otherAss) => (
                                                                                <SelectItem key={otherAss.id} value={String(otherAss.id)}>
                                                                                    Mover a {otherAss.ruta_nombre}
                                                                                </SelectItem>
                                                                            ))}
                                                                        </SelectContent>
                                                                    </Select>
                                                                </div>
                                                            </div>
                                                        ))}
                                                    </div>
                                                )}
                                            </CardContent>
                                        </Card>
                                    );
                                })}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
