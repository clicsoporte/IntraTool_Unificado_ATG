import { getAllVehiclesAction } from "@/modules/fleet/lib/actions";
import VehicleList from "@/modules/fleet/components/VehicleList";
import { authorizeAction } from "@/modules/core/lib/auth-guard";
import Link from "next/link";
import { Truck, Fuel, Wrench, ShieldAlert, FileBarChart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default async function FleetDashboardPage() {
    await authorizeAction('fleet:access');
    const vehicles = await getAllVehiclesAction();

    // Summary stats
    const totalVehicles = vehicles.length;
    const inTaller = vehicles.filter((v: any) => v.status !== 'active').length;
    const needsOilChange = vehicles.filter((v: any) => v.currentMileage >= v.lastOilChangeMileage + v.oilChangeInterval).length;
    const expiringRtv = vehicles.filter((v: any) => {
        if (!v.rtvExpiration) return false;
        const rtvDate = new Date(v.rtvExpiration);
        return (rtvDate.getTime() - new Date().getTime() < 30 * 24 * 60 * 60 * 1000);
    }).length;

    return (
        <div className="p-6 space-y-8 animate-in fade-in duration-500">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                    <div className="p-3 bg-blue-600 rounded-2xl text-white shadow-lg shadow-blue-200">
                        <Truck className="w-8 h-8" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-extrabold tracking-tight">Gestión de Flota</h1>
                        <p className="text-muted-foreground font-medium">Control unificado de activos, combustible y mantenimiento.</p>
                    </div>
                </div>
                <div className="flex gap-2">
                    <Link href="/dashboard/operations/fleet/reports">
                        <Button className="bg-slate-800 hover:bg-slate-900 text-white shadow-lg">
                            <FileBarChart className="w-4 h-4 mr-2" /> Reporte de Consumos
                        </Button>
                    </Link>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card className="border-l-4 border-l-blue-500 shadow-sm">
                    <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
                        <CardTitle className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Flota Total</CardTitle>
                        <Truck className="w-4 h-4 text-blue-500" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-3xl font-bold">{totalVehicles}</div>
                        <p className="text-xs text-muted-foreground mt-1">Unidades registradas</p>
                    </CardContent>
                </Card>

                <Card className="border-l-4 border-l-amber-500 shadow-sm">
                    <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
                        <CardTitle className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Fuera de Servicio</CardTitle>
                        <Wrench className="w-4 h-4 text-amber-500" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-3xl font-bold">{inTaller}</div>
                        <p className="text-xs text-muted-foreground mt-1">En mantenimiento</p>
                    </CardContent>
                </Card>

                <Card className="border-l-4 border-l-rose-500 shadow-sm">
                    <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
                        <CardTitle className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Alertas Mecánicas</CardTitle>
                        <ShieldAlert className="w-4 h-4 text-rose-500" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-3xl font-bold">{needsOilChange}</div>
                        <p className="text-xs text-muted-foreground mt-1">Requieren cambio de aceite</p>
                    </CardContent>
                </Card>

                <Card className="border-l-4 border-l-purple-500 shadow-sm">
                    <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
                        <CardTitle className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Alertas Legales</CardTitle>
                        <ShieldAlert className="w-4 h-4 text-purple-500" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-3xl font-bold">{expiringRtv}</div>
                        <p className="text-xs text-muted-foreground mt-1">Vencimientos próximos</p>
                    </CardContent>
                </Card>
            </div>

            <VehicleList vehicles={vehicles} />
        </div>
    );
}
